import { createRouter, createWebHistory } from 'vue-router'
import { useAuthStore } from '@/store/auth'
import { ElMessage } from 'element-plus'

const router = createRouter({
  history: createWebHistory(),
  routes: [
    {
      path: '/login',
      name: 'Login',
      component: () => import('@/views/login/LoginView.vue'),
      meta: { public: true, title: '登录' },
    },
    {
      path: '/',
      component: () => import('@/views/layout/LayoutView.vue'),
      redirect: '/dashboard',
      children: [
        {
          path: 'dashboard',
          name: 'Dashboard',
          component: () => import('@/views/dashboard/DashboardView.vue'),
          meta: { title: '仪表盘' },
        },
        {
          path: 'users',
          name: 'Users',
          component: () => import('@/views/users/UserListView.vue'),
          meta: { title: '用户管理' },
        },
        {
          path: 'shops',
          name: 'Shops',
          component: () => import('@/views/shops/ShopListView.vue'),
          meta: { title: '店铺管理' },
        },
        {
          path: 'orders',
          name: 'Orders',
          component: () => import('@/views/orders/OrderListView.vue'),
          meta: { title: '订单管理' },
        },
        {
          path: 'stats',
          name: 'Stats',
          component: () => import('@/views/stats/StatsView.vue'),
          meta: { title: '数据统计' },
        },
        {
          path: 'settings',
          name: 'Settings',
          component: () => import('@/views/settings/SettingsView.vue'),
          meta: { title: '系统设置' },
        },
      ],
    },
  ],
})

router.beforeEach((to) => {
  const authStore = useAuthStore()
  if (to.meta.public) {
    return true
  }

  if (!authStore.isLoggedIn) {
    ElMessage.warning('请先登录')
    return '/login'
  }
  return true
})

export default router
