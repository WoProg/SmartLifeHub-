import { defineStore } from 'pinia'
import { storage } from '@/utils/storage'
import type { LoginResponse } from '@/types/auth'

interface AuthState {
  token: string
  user: LoginResponse | null
  loginFailCount: number
}

export const useAuthStore = defineStore('auth', {
  state: (): AuthState => ({
    token: storage.getToken(),
    user: storage.getUser(),
    loginFailCount: 0,
  }),
  getters: {
    isLoggedIn: (state) => Boolean(state.token),
  },
  actions: {
    setAuth(payload: LoginResponse) {
      this.token = payload.token
      this.user = payload
      this.loginFailCount = 0
      storage.setToken(payload.token)
      storage.setUser(payload)
    },
    recordLoginFail() {
      this.loginFailCount += 1
    },
    logout() {
      this.token = ''
      this.user = null
      storage.removeToken()
      storage.removeUser()
    },
  },
})
