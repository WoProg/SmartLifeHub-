<script setup lang="ts">
import { computed } from 'vue'
import { useRoute, useRouter } from 'vue-router'
import { Bell, Expand, Fold } from '@element-plus/icons-vue'
import { useAuthStore } from '@/store/auth'

const props = defineProps<{ collapse: boolean }>()
const emit = defineEmits<{ (e: 'toggle'): void }>()
const route = useRoute()
const router = useRouter()
const authStore = useAuthStore()

const breadcrumbs = computed(() => [
  { title: '首页', path: '/' },
  { title: String(route.meta.title || '页面') },
])

function logout() {
  authStore.logout()
  router.push('/login')
}
</script>

<template>
  <div class="header">
    <div class="left">
      <el-button text @click="emit('toggle')">
        <el-icon><component :is="props.collapse ? Expand : Fold" /></el-icon>
      </el-button>
      <el-breadcrumb separator="/">
        <el-breadcrumb-item v-for="item in breadcrumbs" :key="item.title">{{
          item.title
        }}</el-breadcrumb-item>
      </el-breadcrumb>
    </div>
    <div class="right">
      <el-badge :value="3" class="mx">
        <el-button text
          ><el-icon><Bell /></el-icon
        ></el-button>
      </el-badge>
      <el-dropdown>
        <span class="user">
          <el-avatar :size="30">{{ authStore.user?.username?.slice(0, 1) || 'A' }}</el-avatar>
          <span>{{ authStore.user?.username || 'Admin' }}</span>
        </span>
        <template #dropdown>
          <el-dropdown-menu>
            <el-dropdown-item @click="logout">退出登录</el-dropdown-item>
          </el-dropdown-menu>
        </template>
      </el-dropdown>
    </div>
  </div>
</template>

<style scoped>
.header {
  height: 56px;
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 0 16px;
  background: #fff;
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.06);
}
.left,
.right,
.user {
  display: flex;
  align-items: center;
  gap: 10px;
}
</style>
