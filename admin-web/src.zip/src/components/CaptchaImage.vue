<script setup lang="ts">
import { onMounted, ref } from 'vue'

const code = ref('')

function randomCode() {
  const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789'
  code.value = Array.from(
    { length: 4 },
    () => chars[Math.floor(Math.random() * chars.length)],
  ).join('')
}

onMounted(randomCode)
defineExpose({ refresh: randomCode, getCode: () => code.value })
</script>

<template>
  <div class="captcha" @click="randomCode" :title="'点击刷新验证码'">{{ code }}</div>
</template>

<style scoped>
.captcha {
  width: 120px;
  height: 40px;
  border: 1px solid #dcdfe6;
  border-radius: 6px;
  display: flex;
  align-items: center;
  justify-content: center;
  cursor: pointer;
  user-select: none;
  font-weight: 700;
  letter-spacing: 3px;
  background: linear-gradient(135deg, #eef3ff, #f8faff);
}
</style>
