<script setup lang="ts">
import { useRoute } from 'vue-router'
import {
  DataLine,
  DishDot,
  HomeFilled,
  Setting,
  Shop,
  Tickets,
  User,
} from '@element-plus/icons-vue'

defineProps<{ collapse: boolean }>()

const route = useRoute()
const menuList = [
  { path: '/dashboard', title: '仪表盘', icon: HomeFilled },
  { path: '/users', title: '用户管理', icon: User },
  { path: '/shops', title: '店铺管理', icon: Shop },
  { path: '/orders', title: '订单管理', icon: Tickets },
  { path: '/stats', title: '数据统计', icon: DataLine },
  { path: '/settings', title: '系统设置', icon: Setting },
  { path: '/marketing', title: '营销管理', icon: DishDot, disabled: true },
]
</script>

<template>
  <div class="sidebar">
    <div class="logo">SmartFood Admin</div>
    <el-menu
      :default-active="route.path"
      :collapse="collapse"
      background-color="#001529"
      text-color="#fff"
      active-text-color="#409EFF"
      router
    >
      <el-menu-item
        v-for="item in menuList"
        :key="item.path"
        :index="item.path"
        :disabled="item.disabled"
      >
        <el-icon><component :is="item.icon" /></el-icon>
        <template #title>{{ item.title }}</template>
      </el-menu-item>
    </el-menu>
  </div>
</template>

<style scoped>
.sidebar {
  height: 100%;
  background: #001529;
}
.logo {
  height: 56px;
  display: flex;
  align-items: center;
  justify-content: center;
  color: #fff;
  font-weight: 700;
  border-bottom: 1px solid rgba(255, 255, 255, 0.08);
}
</style>
