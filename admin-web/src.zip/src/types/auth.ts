export interface LoginForm {
  username: string
  password: string
  captcha: string
  remember: boolean
}

export interface LoginResponse {
  token: string
  username: string
  avatar?: string
  roles: string[]
}
