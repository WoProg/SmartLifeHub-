const TOKEN_KEY = 'admin_token'
const USER_KEY = 'admin_user'

export const storage = {
  getToken: () => localStorage.getItem(TOKEN_KEY) || '',
  setToken: (token: string) => localStorage.setItem(TOKEN_KEY, token),
  removeToken: () => localStorage.removeItem(TOKEN_KEY),
  setUser: (user: unknown) => localStorage.setItem(USER_KEY, JSON.stringify(user)),
  getUser: () => {
    const raw = localStorage.getItem(USER_KEY)
    return raw ? JSON.parse(raw) : null
  },
  removeUser: () => localStorage.removeItem(USER_KEY),
}
