import http from './http'
import type { PageResult } from '@/types/common'

export interface UserItem {
  id: number
  nickname: string
  phone: string
  status: 'NORMAL' | 'BANNED'
  level: number
  createTime: string
  lastLogin: string
}

export interface ShopItem {
  id: number
  name: string
  address: string
  score: number
  orderCount: number
  status: string
}

export interface OrderItem {
  orderNo: string
  userId: number
  shopId: number
  amount: number
  status: string
  time: string
}

export interface Overview {
  totalUsers: number
  totalShops: number
  totalOrders: number
  gmv: number
}

export function getUsers(params: { page: number; size: number; keyword?: string; status?: string }) {
  return http.get<unknown, PageResult<UserItem>>('/admin/users', { params })
}

export function toggleUserStatus(id: number) {
  return http.post(`/admin/users/${id}/toggle-status`)
}

export function getShops(params: { page: number; size: number; keyword?: string }) {
  return http.get<unknown, PageResult<ShopItem>>('/admin/shops', { params })
}

export function getOrders(params: { page: number; size: number; status?: string }) {
  return http.get<unknown, PageResult<OrderItem>>('/admin/orders', { params })
}

export function getOverview() {
  return http.get<unknown, Overview>('/admin/stats/overview')
}
