import http from './http'

export interface ReviewItem {
  id: number
  orderNo: number
  userId: number
  shopId: number
  rating: number
  content: string
  images?: string
  likeCount: number
  createTime: string
}

export interface ReportItem {
  id: number
  reporterUserId: number
  targetType: string
  targetId: number
  reason: string
  createTime: string
}

export interface NoticeItem {
  id: number
  title: string
  content: string
  type: string
  enabled: number
  updateTime: string
}

export function getPendingReviews(limit = 100) {
  return http.get<unknown, ReviewItem[]>('/admin/ops/reviews/pending', { params: { limit } })
}

export function approveReview(id: number) {
  return http.post(`/admin/ops/reviews/${id}/approve`)
}

export function rejectReview(id: number) {
  return http.post(`/admin/ops/reviews/${id}/reject`)
}

export function getPendingReports(limit = 100) {
  return http.get<unknown, ReportItem[]>('/admin/ops/reports/pending', { params: { limit } })
}

export function resolveReport(id: number) {
  return http.post(`/admin/ops/reports/${id}/resolve`)
}

export function createNotice(data: { title: string; content: string; type: 'NOTICE' | 'BANNER'; enabled: boolean }) {
  return http.post('/admin/ops/notices', data)
}

export function getNotices(type: 'NOTICE' | 'BANNER') {
  return http.get<unknown, NoticeItem[]>('/admin/ops/notices', { params: { type } })
}
