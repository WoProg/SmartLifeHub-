import type { LoginForm, LoginResponse } from '@/types/auth'
import http from './http'

export function adminLogin(data: LoginForm) {
  return http.post<unknown, LoginResponse>('/admin/login', data)
}
