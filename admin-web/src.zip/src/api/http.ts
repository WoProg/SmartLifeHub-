import axios from 'axios'
import { ElMessage } from 'element-plus'
import { storage } from '@/utils/storage'
import type { ApiResult } from '@/types/common'

const http = axios.create({
  baseURL: '/api',
  timeout: 15000,
})

http.interceptors.request.use((config) => {
  const token = storage.getToken()
  if (token) {
    config.headers.Authorization = `Bearer ${token}`
  }
  return config
})

http.interceptors.response.use(
  (response) => {
    const payload = response.data as ApiResult<unknown>
    if (payload && typeof payload.code === 'number') {
      if (payload.code !== 0) {
        const message = payload.message || '请求失败'
        ElMessage.error(message)
        return Promise.reject(new Error(message))
      }
      return payload.data
    }
    return response.data
  },
  (error) => {
    const status = error?.response?.status
    const message = error?.response?.data?.message || error.message || '请求失败'
    if (status === 401) {
      storage.removeToken()
      storage.removeUser()
      if (location.pathname !== '/login') {
        location.href = '/login'
      }
    }
    ElMessage.error(message)
    return Promise.reject(error)
  },
)

export default http
