<script setup lang="ts">
import { ref } from 'vue'
import { getOrders, type OrderItem } from '@/api/admin'

const active = ref('全部订单')
const tabs = ['全部订单', '待付款', '待接单', '制作中', '配送中', '已完成', '已取消']
const drawer = ref(false)
const current = ref<Record<string, unknown>>({})
const loading = ref(false)

const rows = ref<
  (OrderItem & { user: string; shop: string; items: string })[]
>([])

async function load() {
  loading.value = true
  try {
    const status = active.value === '全部订单' ? undefined : active.value
    const data = await getOrders({ page: 1, size: 50, status })
    rows.value = (data.records || []).map((item) => ({
      ...item,
      user: `用户ID:${item.userId}`,
      shop: `店铺ID:${item.shopId}`,
      items: '详见订单明细',
    }))
  } finally {
    loading.value = false
  }
}
load()

function openDetail(row: Record<string, unknown>) {
  current.value = row
  drawer.value = true
}
</script>

<template>
  <el-card>
    <el-tabs v-model="active" @tab-change="load">
      <el-tab-pane v-for="item in tabs" :key="item" :name="item" :label="item" />
    </el-tabs>
    <el-table :data="rows" v-loading="loading">
      <el-table-column prop="orderNo" label="订单号" width="180" />
      <el-table-column prop="user" label="用户信息" />
      <el-table-column prop="shop" label="店铺信息" />
      <el-table-column prop="items" label="商品清单" show-overflow-tooltip />
      <el-table-column prop="amount" label="实付金额" />
      <el-table-column prop="status" label="订单状态">
        <template #default="{ row }"
          ><el-tag>{{ row.status }}</el-tag></template
        >
      </el-table-column>
      <el-table-column prop="time" label="下单时间" />
      <el-table-column label="操作"
        ><template #default="{ row }"
          ><el-button link type="primary" @click="openDetail(row)">详情</el-button></template
        ></el-table-column
      >
    </el-table>
  </el-card>

  <el-drawer v-model="drawer" title="订单详情" size="45%">
    <el-descriptions :column="1" border>
      <el-descriptions-item label="订单号">{{ current.orderNo }}</el-descriptions-item>
      <el-descriptions-item label="用户">{{ current.user }}</el-descriptions-item>
      <el-descriptions-item label="店铺">{{ current.shop }}</el-descriptions-item>
      <el-descriptions-item label="商品">{{ current.items }}</el-descriptions-item>
      <el-descriptions-item label="金额">¥{{ current.amount }}</el-descriptions-item>
      <el-descriptions-item label="状态">{{ current.status }}</el-descriptions-item>
    </el-descriptions>
    <div style="margin-top: 16px">
      <el-button type="primary">接单</el-button>
      <el-button type="success">出餐完成</el-button>
      <el-button>配送完成</el-button>
      <el-button type="danger">取消订单</el-button>
    </div>
  </el-drawer>
</template>
