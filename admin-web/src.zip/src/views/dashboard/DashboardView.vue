<script setup lang="ts">
import { onMounted, onUnmounted, ref } from 'vue'
import * as echarts from 'echarts'
import { ElMessage } from 'element-plus'

const loading = ref(false)
const trendRef = ref<HTMLDivElement>()
const topDishRef = ref<HTMLDivElement>()
const shopPieRef = ref<HTMLDivElement>()
let timer: number | undefined

const cards = ref([
  { title: '今日订单数', value: 1268, rate: '+8.4%' },
  { title: '今日营业额', value: '¥ 92,560', rate: '+5.1%' },
  { title: '活跃用户数', value: 3920, rate: '+2.6%' },
  { title: '新增用户数', value: 188, rate: '+3.8%' },
])

const orders = ref(
  Array.from({ length: 10 }, (_, i) => ({
    orderNo: `SO20260321${1000 + i}`,
    user: `用户${i + 1}`,
    amount: (40 + i * 3).toFixed(2),
    status: ['待付款', '制作中', '配送中', '已完成'][i % 4],
    time: `2026-03-21 2${i}:1${i}`,
  })),
)

function renderCharts() {
  const trend = echarts.init(trendRef.value!)
  trend.setOption({
    color: ['#409EFF'],
    tooltip: { trigger: 'axis' },
    xAxis: { type: 'category', data: ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'] },
    yAxis: { type: 'value' },
    series: [{ type: 'line', smooth: true, data: [420, 480, 530, 600, 680, 720, 760] }],
  })

  const topDish = echarts.init(topDishRef.value!)
  topDish.setOption({
    color: ['#67C23A'],
    xAxis: { type: 'value' },
    yAxis: { type: 'category', data: ['宫保鸡丁', '鱼香肉丝', '麻辣香锅', '番茄牛腩', '酸菜鱼'] },
    series: [{ type: 'bar', data: [1200, 1080, 980, 860, 820] }],
  })

  const shopPie = echarts.init(shopPieRef.value!)
  shopPie.setOption({
    tooltip: { trigger: 'item' },
    series: [
      {
        type: 'pie',
        radius: '65%',
        data: [
          { value: 35, name: '中餐' },
          { value: 22, name: '快餐' },
          { value: 18, name: '饮品' },
          { value: 25, name: '小吃' },
        ],
      },
    ],
  })
}

function refreshData() {
  loading.value = true
  setTimeout(() => {
    loading.value = false
    ElMessage.success('数据已刷新')
  }, 800)
}

onMounted(() => {
  renderCharts()
  timer = window.setInterval(refreshData, 300000)
})
onUnmounted(() => {
  if (timer) window.clearInterval(timer)
})
</script>

<template>
  <div>
    <el-row :gutter="16">
      <el-col v-for="item in cards" :key="item.title" :xs="24" :sm="12" :md="6">
        <el-card shadow="hover" class="card">
          <div class="title">{{ item.title }}</div>
          <div class="value">{{ item.value }}</div>
          <div class="rate">{{ item.rate }}</div>
        </el-card>
      </el-col>
    </el-row>

    <el-row :gutter="16" class="mt">
      <el-col :xs="24" :lg="14">
        <el-card
          ><template #header>订单趋势</template>
          <div ref="trendRef" class="chart"
        /></el-card>
      </el-col>
      <el-col :xs="24" :lg="10">
        <el-card class="mb"
          ><template #header>热门菜品 TOP5</template>
          <div ref="topDishRef" class="chart small"
        /></el-card>
        <el-card
          ><template #header>店铺分布</template>
          <div ref="shopPieRef" class="chart small"
        /></el-card>
      </el-col>
    </el-row>

    <el-row :gutter="16" class="mt">
      <el-col :xs="24" :lg="16">
        <el-card>
          <template #header>最新订单</template>
          <el-table :data="orders" stripe>
            <el-table-column prop="orderNo" label="订单号" />
            <el-table-column prop="user" label="用户" />
            <el-table-column prop="amount" label="金额" />
            <el-table-column prop="status" label="状态" />
            <el-table-column prop="time" label="下单时间" />
          </el-table>
        </el-card>
      </el-col>
      <el-col :xs="24" :lg="8">
        <el-card>
          <template #header>
            系统待办
            <el-button type="primary" text @click="refreshData" :loading="loading"
              >手动刷新</el-button
            >
          </template>
          <el-descriptions :column="1" border>
            <el-descriptions-item label="待处理订单">23</el-descriptions-item>
            <el-descriptions-item label="待审核店铺">7</el-descriptions-item>
            <el-descriptions-item label="系统公告">周日凌晨 2:00 维护</el-descriptions-item>
          </el-descriptions>
        </el-card>
      </el-col>
    </el-row>
  </div>
</template>

<style scoped>
.mt {
  margin-top: 16px;
}
.mb {
  margin-bottom: 16px;
}
.card .title {
  color: #909399;
}
.card .value {
  margin: 8px 0;
  font-size: 28px;
  font-weight: 700;
}
.card .rate {
  color: #67c23a;
}
.chart {
  height: 320px;
}
.chart.small {
  height: 220px;
}
</style>
