<script setup lang="ts">
import { reactive, ref } from 'vue'
import { getShops, type ShopItem } from '@/api/admin'

const loading = ref(false)
const query = reactive({ name: '', type: '', status: '', audit: '' })
const dialogVisible = ref(false)
const rows = ref<(ShopItem & { type?: string; audit?: string })[]>([])

async function search() {
  loading.value = true
  try {
    const data = await getShops({ page: 1, size: 50, keyword: query.name || undefined })
    rows.value = (data.records || []).map((item) => ({
      ...item,
      type: '餐饮',
      audit: '已通过',
    }))
  } finally {
    loading.value = false
  }
}
search()
</script>

<template>
  <el-card>
    <el-form :inline="true" class="mb12">
      <el-form-item label="店铺名称"><el-input v-model="query.name" /></el-form-item>
      <el-form-item label="店铺类型"
        ><el-select v-model="query.type" style="width: 120px"
      /></el-form-item>
      <el-form-item label="营业状态"
        ><el-select v-model="query.status" style="width: 120px"
      /></el-form-item>
      <el-form-item label="审核状态"
        ><el-select v-model="query.audit" style="width: 120px"
      /></el-form-item>
      <el-form-item><el-button type="primary" @click="search">搜索</el-button></el-form-item>
    </el-form>
    <div class="mb12">
      <el-button type="primary" @click="dialogVisible = true">新增店铺</el-button>
      <el-button>批量审核通过</el-button>
      <el-button>批量上架/下架</el-button>
      <el-button>导出店铺数据</el-button>
    </div>
    <el-table :data="rows" v-loading="loading">
      <el-table-column type="selection" width="50" />
      <el-table-column prop="id" label="店铺ID" width="100" />
      <el-table-column label="Logo" width="80"
        ><template #default><el-avatar shape="square">S</el-avatar></template></el-table-column
      >
      <el-table-column prop="name" label="名称" />
      <el-table-column prop="type" label="类型" />
      <el-table-column prop="address" label="地址" show-overflow-tooltip />
      <el-table-column label="评分"
        ><template #default="{ row }"><el-rate :model-value="row.score" disabled /></template
      ></el-table-column>
      <el-table-column prop="orderCount" label="订单数" />
      <el-table-column prop="status" label="营业状态" />
      <el-table-column prop="audit" label="审核状态" />
      <el-table-column label="操作" width="240">
        <template #default
          ><el-button link type="primary">详情</el-button
          ><el-button link type="warning">审核</el-button
          ><el-button link type="success">上下架</el-button></template
        >
      </el-table-column>
    </el-table>
  </el-card>

  <el-dialog v-model="dialogVisible" title="新增/编辑店铺" width="720px">
    <el-form label-width="100px">
      <el-form-item label="名称"><el-input /></el-form-item>
      <el-form-item label="类型"><el-select /></el-form-item>
      <el-form-item label="联系电话"><el-input /></el-form-item>
      <el-form-item label="详细地址"><el-input /></el-form-item>
      <el-form-item label="营业时间"><el-time-picker is-range /></el-form-item>
      <el-form-item label="店铺描述"><el-input type="textarea" :rows="3" /></el-form-item>
    </el-form>
  </el-dialog>
</template>

<style scoped>
.mb12 {
  margin-bottom: 12px;
}
</style>
