<script setup lang="ts">
import { onMounted, onUnmounted, ref } from 'vue'
import AppHeader from '@/components/AppHeader.vue'
import AppSidebar from '@/components/AppSidebar.vue'

const isMobile = ref(window.innerWidth < 768)
const collapse = ref(window.innerWidth < 1200)

function onResize() {
  isMobile.value = window.innerWidth < 768
  if (isMobile.value) collapse.value = true
}

onMounted(() => window.addEventListener('resize', onResize))
onUnmounted(() => window.removeEventListener('resize', onResize))
</script>

<template>
  <div class="layout">
    <aside v-show="!isMobile" class="aside" :style="{ width: collapse ? '64px' : '200px' }">
      <AppSidebar :collapse="collapse" />
    </aside>
    <main class="main">
      <AppHeader :collapse="collapse" @toggle="collapse = !collapse" />
      <section class="content">
        <RouterView />
      </section>
    </main>
  </div>
</template>

<style scoped>
.layout {
  height: 100vh;
  display: flex;
  overflow: hidden;
}
.aside {
  transition: width 0.2s;
}
.main {
  flex: 1;
  min-width: 0;
  display: flex;
  flex-direction: column;
}
.content {
  flex: 1;
  overflow: auto;
  padding: 16px;
  background: #f5f7fa;
}
</style>
