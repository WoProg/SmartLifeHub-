<script setup lang="ts">
import { onMounted, reactive, ref } from 'vue'
import { ElMessage } from 'element-plus'
import {
  approveReview,
  createNotice,
  getNotices,
  getPendingReports,
  getPendingReviews,
  rejectReview,
  resolveReport,
  type NoticeItem,
  type ReportItem,
  type ReviewItem,
} from '@/api/ops'

const active = ref('basic')
const reviews = ref<ReviewItem[]>([])
const reports = ref<ReportItem[]>([])
const notices = ref<NoticeItem[]>([])
const loading = ref(false)
const noticeForm = reactive({
  title: '',
  content: '',
  type: 'NOTICE' as 'NOTICE' | 'BANNER',
  enabled: true,
})

async function loadOps() {
  loading.value = true
  try {
    const [rv, rp, nt] = await Promise.all([
      getPendingReviews(50),
      getPendingReports(50),
      getNotices('NOTICE'),
    ])
    reviews.value = rv
    reports.value = rp
    notices.value = nt
  } finally {
    loading.value = false
  }
}

async function doApprove(id: number) {
  await approveReview(id)
  ElMessage.success('审核通过')
  await loadOps()
}

async function doReject(id: number) {
  await rejectReview(id)
  ElMessage.success('已驳回')
  await loadOps()
}

async function doResolve(id: number) {
  await resolveReport(id)
  ElMessage.success('举报已处理')
  await loadOps()
}

async function submitNotice() {
  if (!noticeForm.title || !noticeForm.content) {
    ElMessage.warning('请填写公告标题和内容')
    return
  }
  await createNotice(noticeForm)
  ElMessage.success('公告已发布')
  noticeForm.title = ''
  noticeForm.content = ''
  await loadOps()
}

onMounted(loadOps)
</script>

<template>
  <el-card>
    <el-tabs v-model="active" tab-position="left">
      <el-tab-pane label="基础设置" name="basic">
        <el-form label-width="120px">
          <el-form-item label="网站名称"><el-input model-value="智能外卖点评系统" /></el-form-item>
          <el-form-item label="客服电话"><el-input model-value="400-000-0000" /></el-form-item>
          <el-form-item label="营业时间"><el-time-picker is-range /></el-form-item>
          <el-form-item
            ><el-button type="primary">保存</el-button><el-button>取消</el-button></el-form-item
          >
        </el-form>
      </el-tab-pane>
      <el-tab-pane label="支付设置" name="payment"
        ><el-alert title="配置微信/支付宝参数" type="info"
      /></el-tab-pane>
      <el-tab-pane label="短信配置" name="sms"
        ><el-alert title="配置阿里云/腾讯云短信" type="info"
      /></el-tab-pane>
      <el-tab-pane label="内容审核" name="review">
        <el-table :data="reviews" v-loading="loading">
          <el-table-column prop="id" label="ID" width="80" />
          <el-table-column prop="orderNo" label="订单号" width="180" />
          <el-table-column prop="rating" label="评分" width="80" />
          <el-table-column prop="content" label="内容" />
          <el-table-column label="操作" width="160">
            <template #default="{ row }">
              <el-button link type="success" @click="doApprove(row.id)">通过</el-button>
              <el-button link type="danger" @click="doReject(row.id)">驳回</el-button>
            </template>
          </el-table-column>
        </el-table>
      </el-tab-pane>
      <el-tab-pane label="举报处理" name="report">
        <el-table :data="reports" v-loading="loading">
          <el-table-column prop="id" label="ID" width="80" />
          <el-table-column prop="targetType" label="对象类型" width="120" />
          <el-table-column prop="targetId" label="对象ID" width="120" />
          <el-table-column prop="reason" label="举报原因" />
          <el-table-column label="操作" width="120">
            <template #default="{ row }">
              <el-button link type="primary" @click="doResolve(row.id)">处理完成</el-button>
            </template>
          </el-table-column>
        </el-table>
      </el-tab-pane>
      <el-tab-pane label="公告配置" name="notice">
        <el-form label-width="90px">
          <el-form-item label="标题"><el-input v-model="noticeForm.title" /></el-form-item>
          <el-form-item label="内容"><el-input v-model="noticeForm.content" type="textarea" /></el-form-item>
          <el-form-item label="类型">
            <el-select v-model="noticeForm.type" style="width: 180px">
              <el-option label="系统公告" value="NOTICE" />
              <el-option label="首页轮播" value="BANNER" />
            </el-select>
          </el-form-item>
          <el-form-item label="启用"><el-switch v-model="noticeForm.enabled" /></el-form-item>
          <el-form-item><el-button type="primary" @click="submitNotice">发布</el-button></el-form-item>
        </el-form>
        <el-divider />
        <el-table :data="notices">
          <el-table-column prop="id" label="ID" width="80" />
          <el-table-column prop="title" label="标题" />
          <el-table-column prop="type" label="类型" width="120" />
          <el-table-column prop="updateTime" label="更新时间" width="180" />
        </el-table>
      </el-tab-pane>
      <el-tab-pane label="系统监控" name="monitor"
        ><el-alert title="CPU/内存/QPS 实时监控" type="info"
      /></el-tab-pane>
    </el-tabs>
  </el-card>
</template>
