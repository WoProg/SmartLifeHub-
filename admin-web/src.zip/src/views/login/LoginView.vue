<script setup lang="ts">
import { reactive, ref } from 'vue'
import { useRouter } from 'vue-router'
import type { FormInstance, FormRules } from 'element-plus'
import { ElMessage } from 'element-plus'
import { Food } from '@element-plus/icons-vue'
import { adminLogin } from '@/api/auth'
import { useAuthStore } from '@/store/auth'
import type { LoginForm } from '@/types/auth'
import CaptchaImage from '@/components/CaptchaImage.vue'

const router = useRouter()
const authStore = useAuthStore()
const formRef = ref<FormInstance>()
const captchaRef = ref<InstanceType<typeof CaptchaImage>>()
const loading = ref(false)

const form = reactive<LoginForm>({
  username: '',
  password: '',
  captcha: '',
  remember: true,
})

const rules: FormRules<LoginForm> = {
  username: [
    { required: true, message: '请输入用户名或手机号', trigger: 'blur' },
    { pattern: /^(\d{11}|[\w.@-]{3,30})$/, message: '请输入正确用户名或手机号', trigger: 'blur' },
  ],
  password: [
    { required: true, message: '请输入密码', trigger: 'blur' },
    { min: 6, max: 32, message: '密码长度为6-32位', trigger: 'blur' },
  ],
  captcha: [{ required: true, message: '请输入验证码', trigger: 'blur' }],
}

async function handleLogin() {
  if (!formRef.value || loading.value) return
  await formRef.value.validate()

  if (authStore.loginFailCount >= 5) {
    ElMessage.error('登录失败次数过多，请稍后再试')
    return
  }

  if (form.captcha.toUpperCase() !== captchaRef.value?.getCode()) {
    ElMessage.error('验证码错误')
    authStore.recordLoginFail()
    captchaRef.value?.refresh()
    return
  }

  try {
    loading.value = true
    const data = await adminLogin(form)
    authStore.setAuth(data)
    ElMessage.success('登录成功')
    router.push('/dashboard')
  } catch {
    authStore.recordLoginFail()
  } finally {
    loading.value = false
    captchaRef.value?.refresh()
  }
}
</script>

<template>
  <div class="login-page">
    <el-card class="login-card">
      <div class="header">
        <el-icon size="30" color="#409EFF"><Food /></el-icon>
        <h2>智能外卖点评系统-管理后台</h2>
      </div>
      <el-form ref="formRef" :model="form" :rules="rules" label-position="top">
        <el-form-item label="用户名/手机号" prop="username">
          <el-input v-model="form.username" placeholder="请输入用户名或手机号" clearable />
        </el-form-item>
        <el-form-item label="密码" prop="password">
          <el-input
            v-model="form.password"
            type="password"
            show-password
            placeholder="请输入密码"
            clearable
          />
        </el-form-item>
        <el-form-item label="验证码" prop="captcha">
          <div class="captcha-row">
            <el-input v-model="form.captcha" placeholder="输入验证码" clearable />
            <CaptchaImage ref="captchaRef" />
          </div>
        </el-form-item>
        <el-form-item>
          <el-checkbox v-model="form.remember">记住密码</el-checkbox>
        </el-form-item>
        <el-button type="primary" :loading="loading" class="full-btn" @click="handleLogin"
          >登录</el-button
        >
      </el-form>
    </el-card>
  </div>
</template>

<style scoped>
.login-page {
  height: 100vh;
  display: flex;
  align-items: center;
  justify-content: center;
  background: linear-gradient(135deg, #f5f7fa, #e4e7ed);
}
.login-card {
  width: 400px;
  border-radius: 6px;
}
.header {
  text-align: center;
  margin-bottom: 16px;
}
.header h2 {
  margin: 8px 0 0;
  font-size: 18px;
  color: #303133;
}
.captcha-row {
  display: flex;
  gap: 8px;
  width: 100%;
}
.full-btn {
  width: 100%;
}
</style>
