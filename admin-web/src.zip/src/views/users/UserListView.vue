<script setup lang="ts">
import { onMounted, reactive, ref } from 'vue'
import { ElMessage } from 'element-plus'
import { getUsers, toggleUserStatus, type UserItem } from '@/api/admin'

const query = reactive({ keyword: '', status: '', level: '', page: 1, size: 20 })
const tableLoading = ref(false)
const list = ref<UserItem[]>([])
const total = ref(0)
const formDialog = ref(false)
const detailDialog = ref(false)
const current = ref<UserItem | null>(null)

async function fetchList() {
  tableLoading.value = true
  try {
    const data = await getUsers({
      page: query.page,
      size: query.size,
      keyword: query.keyword || undefined,
      status: query.status || undefined,
    })
    list.value = data.records || []
    total.value = data.total || 0
  } finally {
    tableLoading.value = false
  }
}
function reset() {
  query.keyword = ''
  query.status = ''
  query.level = ''
  fetchList()
}
function openDetail(row: UserItem) {
  current.value = row
  detailDialog.value = true
}
async function toggleStatus(row: UserItem) {
  await toggleUserStatus(row.id)
  await fetchList()
  ElMessage.success('状态更新成功')
}
onMounted(fetchList)
</script>

<template>
  <el-card>
    <el-form :inline="true" class="mb12">
      <el-form-item label="手机号/昵称"
        ><el-input v-model="query.keyword" placeholder="模糊搜索"
      /></el-form-item>
      <el-form-item label="状态">
        <el-select v-model="query.status" clearable style="width: 120px">
          <el-option label="正常" value="NORMAL" />
          <el-option label="封禁" value="BANNED" />
        </el-select>
      </el-form-item>
      <el-form-item
        ><el-button type="primary" @click="fetchList">搜索</el-button
        ><el-button @click="reset">重置</el-button></el-form-item
      >
    </el-form>
    <div class="mb12">
      <el-button type="primary" @click="formDialog = true">新增用户</el-button>
      <el-button>批量导出</el-button>
      <el-button>批量封禁/解封</el-button>
    </div>
    <el-table :data="list" v-loading="tableLoading">
      <el-table-column type="selection" width="50" />
      <el-table-column prop="id" label="用户ID" width="100" />
      <el-table-column label="头像" width="80"
        ><template #default><el-avatar :size="28">U</el-avatar></template></el-table-column
      >
      <el-table-column prop="nickname" label="昵称" />
      <el-table-column prop="phone" label="手机号" />
      <el-table-column prop="createTime" label="注册时间" sortable />
      <el-table-column prop="lastLogin" label="最近登录" sortable />
      <el-table-column label="状态">
        <template #default="{ row }"
          ><el-tag :type="row.status === 'NORMAL' ? 'success' : 'danger'">{{
            row.status === 'NORMAL' ? '正常' : '封禁'
          }}</el-tag></template
        >
      </el-table-column>
      <el-table-column label="操作" width="260">
        <template #default="{ row }">
          <el-button link type="primary" @click="openDetail(row)">详情</el-button>
          <el-button link type="primary" @click="formDialog = true">编辑</el-button>
          <el-button link type="warning" @click="toggleStatus(row)">{{
            row.status === 'NORMAL' ? '封禁' : '解封'
          }}</el-button>
          <el-button link type="danger">重置密码</el-button>
        </template>
      </el-table-column>
    </el-table>
    <el-pagination
      class="pager"
      :total="total"
      :current-page="query.page"
      :page-size="query.size"
      layout="total, prev, pager, next"
      @current-change="
        (p) => {
          query.page = p
          fetchList()
        }
      "
    />
  </el-card>

  <el-dialog v-model="detailDialog" title="用户详情" width="700px">
    <el-descriptions :column="2" border>
      <el-descriptions-item label="用户ID">{{ current?.id }}</el-descriptions-item>
      <el-descriptions-item label="昵称">{{ current?.nickname }}</el-descriptions-item>
      <el-descriptions-item label="手机号">{{ current?.phone }}</el-descriptions-item>
      <el-descriptions-item label="状态">{{ current?.status }}</el-descriptions-item>
      <el-descriptions-item label="订单统计">总订单 56 / 总消费 ¥3,260</el-descriptions-item>
      <el-descriptions-item label="封禁记录">暂无</el-descriptions-item>
    </el-descriptions>
  </el-dialog>

  <el-dialog v-model="formDialog" title="新增/编辑用户" width="560px">
    <el-form label-width="90px">
      <el-form-item label="手机号"><el-input /></el-form-item>
      <el-form-item label="密码"><el-input type="password" /></el-form-item>
      <el-form-item label="昵称"><el-input /></el-form-item>
      <el-form-item label="头像"
        ><el-upload action="#" :auto-upload="false"
          ><el-button>上传头像</el-button></el-upload
        ></el-form-item
      >
      <el-form-item label="备注"><el-input type="textarea" /></el-form-item>
    </el-form>
  </el-dialog>
</template>

<style scoped>
.mb12 {
  margin-bottom: 12px;
}
.pager {
  margin-top: 12px;
  justify-content: flex-end;
}
</style>
