<script setup lang="ts">
import { onMounted, ref } from 'vue'
import * as echarts from 'echarts'
import { getOverview } from '@/api/admin'

const lineRef = ref<HTMLDivElement>()
const overview = ref({
  totalUsers: 0,
  totalShops: 0,
  totalOrders: 0,
  gmv: 0,
})

onMounted(() => {
  const chart = echarts.init(lineRef.value!)
  chart.setOption({
    tooltip: { trigger: 'axis' },
    legend: { data: ['订单数', '营业额', '用户增长'] },
    xAxis: { type: 'category', data: ['1', '2', '3', '4', '5', '6', '7'] },
    yAxis: { type: 'value' },
    series: [
      { name: '订单数', type: 'line', smooth: true, data: [120, 132, 140, 170, 180, 190, 210] },
      { name: '营业额', type: 'line', smooth: true, data: [320, 382, 401, 490, 510, 560, 610] },
      { name: '用户增长', type: 'line', smooth: true, data: [45, 52, 60, 65, 72, 80, 86] },
    ],
  })
  getOverview().then((res) => {
    overview.value = res
  })
})
</script>

<template>
  <el-card>
    <el-space wrap>
      <el-button>今日</el-button>
      <el-button>本周</el-button>
      <el-button type="primary">本月</el-button>
      <el-date-picker type="daterange" />
      <el-select placeholder="统计粒度" style="width: 140px">
        <el-option label="按天" value="day" />
        <el-option label="按周" value="week" />
        <el-option label="按月" value="month" />
      </el-select>
    </el-space>
    <el-row :gutter="16" style="margin: 16px 0">
      <el-col :span="6"><el-statistic title="总订单数" :value="overview.totalOrders" /></el-col>
      <el-col :span="6"><el-statistic title="总营业额" :value="overview.gmv" prefix="¥" /></el-col>
      <el-col :span="6"><el-statistic title="总用户数" :value="overview.totalUsers" /></el-col>
      <el-col :span="6"><el-statistic title="总店铺数" :value="overview.totalShops" /></el-col>
    </el-row>
    <div ref="lineRef" style="height: 360px" />
  </el-card>
</template>
