package com.smartfood.auth;

import com.smartfood.exception.BizException;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.data.redis.core.ValueOperations;

import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class SmsCodeServiceTest {

    @Mock
    private StringRedisTemplate stringRedisTemplate;
    @Mock
    private ValueOperations<String, String> valueOps;

    @InjectMocks
    private SmsCodeService smsCodeService;

    @Test
    void sendCode_shouldThrow429_whenSentWithin60s() {
        when(stringRedisTemplate.opsForValue()).thenReturn(valueOps);
        when(valueOps.setIfAbsent(anyString(), anyString(), any())).thenReturn(false);

        BizException ex = Assertions.assertThrows(BizException.class, () -> smsCodeService.sendCode("13812345678"));
        Assertions.assertEquals(429, ex.getCode());
    }

    @Test
    void verifyCode_shouldThrow401_whenCodeWrongAndNotLocked() {
        when(stringRedisTemplate.opsForValue()).thenReturn(valueOps);
        when(valueOps.get("login:code:lock:13812345678")).thenReturn(null);
        when(valueOps.get("login:code:13812345678")).thenReturn("654321");
        when(valueOps.increment("login:code:fail:13812345678")).thenReturn(1L);

        BizException ex = Assertions.assertThrows(BizException.class,
                () -> smsCodeService.verifyCode("13812345678", "123456"));
        Assertions.assertEquals(401, ex.getCode());
    }
}

