package com.smartfood.service.impl;

import com.smartfood.auth.SmsCodeService;
import com.smartfood.dto.LoginRequest;
import com.smartfood.dto.LoginResponse;
import com.smartfood.dto.RegisterRequest;
import com.smartfood.dto.SmsLoginRequest;
import com.smartfood.entity.Gender;
import com.smartfood.entity.User;
import com.smartfood.entity.UserStatus;
import com.smartfood.exception.BizException;
import com.smartfood.mapper.UserMapper;
import com.smartfood.security.JwtUtil;
import com.smartfood.security.session.RedisLoginSessionService;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class UserServiceImplTest {

    @Mock
    private UserMapper userMapper;
    @Mock
    private JwtUtil jwtUtil;
    @Mock
    private SmsCodeService smsCodeService;
    @Mock
    private RedisLoginSessionService redisLoginSessionService;

    @InjectMocks
    private UserServiceImpl userService;

    @Test
    void register_shouldInsertUser_whenPhoneNotExists() {
        RegisterRequest req = new RegisterRequest();
        req.setPhone("13812345678");
        req.setPassword("123456");
        req.setGender(0);
        req.setNickname("u1");

        when(userMapper.selectByPhone(req.getPhone())).thenReturn(null);
        doAnswer(invocation -> {
            User u = invocation.getArgument(0);
            u.setId(1L);
            return 1;
        }).when(userMapper).insert(any(User.class));

        var resp = userService.register(req);

        Assertions.assertEquals(1L, resp.getId());
        Assertions.assertEquals("13812345678", resp.getPhone());
        verify(userMapper, times(1)).insert(any(User.class));
    }

    @Test
    void login_shouldThrow401_whenPasswordWrong() {
        LoginRequest req = new LoginRequest();
        req.setPhone("13812345678");
        req.setPassword("wrong");

        BCryptPasswordEncoder encoder = new BCryptPasswordEncoder();
        User user = User.builder()
                .id(1L)
                .phone(req.getPhone())
                .password(encoder.encode("correctPwd"))
                .status(UserStatus.NORMAL)
                .gender(Gender.UNKNOWN)
                .userLevel(0)
                .build();
        when(userMapper.selectByPhone(req.getPhone())).thenReturn(user);

        BizException ex = Assertions.assertThrows(BizException.class, () -> userService.login(req));
        Assertions.assertEquals(401, ex.getCode());
        verify(redisLoginSessionService, never()).saveSession(anyString(), any(User.class));
    }

    @Test
    void login_shouldReturnTokenAndSaveSession_whenPasswordCorrect() {
        LoginRequest req = new LoginRequest();
        req.setPhone("13812345678");
        req.setPassword("123456");

        BCryptPasswordEncoder encoder = new BCryptPasswordEncoder();
        User user = User.builder()
                .id(1L)
                .phone(req.getPhone())
                .password(encoder.encode(req.getPassword()))
                .status(UserStatus.NORMAL)
                .gender(Gender.UNKNOWN)
                .userLevel(0)
                .build();

        when(userMapper.selectByPhone(req.getPhone())).thenReturn(user);
        when(jwtUtil.generateToken(1L, req.getPhone())).thenReturn("t1");

        LoginResponse resp = userService.login(req);
        Assertions.assertEquals("t1", resp.getToken());
        verify(redisLoginSessionService, times(1)).saveSession("t1", user);
        verify(userMapper, times(1)).updateById(user);
    }

    @Test
    void loginBySmsCode_shouldVerifyAndSaveSession() {
        SmsLoginRequest req = new SmsLoginRequest();
        req.setPhone("13812345678");
        req.setCode("123456");

        User user = User.builder()
                .id(2L)
                .phone(req.getPhone())
                .password("hashed")
                .status(UserStatus.NORMAL)
                .gender(Gender.UNKNOWN)
                .userLevel(0)
                .build();

        when(userMapper.selectByPhone(req.getPhone())).thenReturn(user);
        when(jwtUtil.generateToken(2L, req.getPhone())).thenReturn("sms-token");

        var resp = userService.loginBySmsCode(req);

        Assertions.assertEquals("sms-token", resp.getToken());
        verify(smsCodeService, times(1)).verifyCode(req.getPhone(), req.getCode());
        verify(redisLoginSessionService, times(1)).saveSession("sms-token", user);
        verify(userMapper, times(1)).updateById(user);
    }
}

