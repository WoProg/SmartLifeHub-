package com.smartfood.service.impl;

import com.smartfood.config.properties.OrderCancelTimeoutProperties;
import com.smartfood.entity.*;
import com.smartfood.exception.BizException;
import com.smartfood.id.SnowflakeIdWorker;
import com.smartfood.lock.RedisLockService;
import com.smartfood.mapper.CartMapper;
import com.smartfood.mapper.DishMapper;
import com.smartfood.mapper.OrderDetailMapper;
import com.smartfood.mapper.OrderMapper;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.data.redis.core.HashOperations;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.data.redis.core.ZSetOperations;

import java.math.BigDecimal;
import java.time.Duration;
import java.util.List;

import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class OrderServiceImplTest {

    @Mock
    private OrderMapper orderMapper;
    @Mock
    private OrderDetailMapper orderDetailMapper;
    @Mock
    private CartMapper cartMapper;
    @Mock
    private DishMapper dishMapper;
    @Mock
    private SnowflakeIdWorker snowflakeIdWorker;
    @Mock
    private RedisLockService redisLockService;
    @Mock
    private StringRedisTemplate stringRedisTemplate;
    @Mock
    private ZSetOperations<String, String> zSetOperations;
    @Mock
    private HashOperations<String, Object, Object> hashOperations;
    @Mock
    private OrderCancelTimeoutProperties orderCancelTimeoutProperties;

    @InjectMocks
    private OrderServiceImpl orderService;

    @Test
    void createOrderFromCart_shouldThrow429_whenLockFailed() {
        when(redisLockService.tryLock(anyString(), anyString(), any(Duration.class))).thenReturn(false);

        BizException ex = Assertions.assertThrows(BizException.class, () -> orderService.createOrderFromCart(1L));
        Assertions.assertEquals(429, ex.getCode());
        verify(cartMapper, never()).selectSelectedByUserId(anyLong());
    }

    @Test
    void createOrderFromCart_shouldThrow400_whenCartEmpty() {
        when(redisLockService.tryLock(anyString(), anyString(), any(Duration.class))).thenReturn(true);
        when(cartMapper.selectSelectedByUserId(1L)).thenReturn(List.of());

        BizException ex = Assertions.assertThrows(BizException.class, () -> orderService.createOrderFromCart(1L));
        Assertions.assertEquals(400, ex.getCode());
        verify(redisLockService, times(1)).unlock(anyString(), anyString());
    }

    @Test
    void createOrderFromCart_shouldCreateOrder_whenInputValid() {
        when(redisLockService.tryLock(anyString(), anyString(), any(Duration.class))).thenReturn(true);
        when(orderCancelTimeoutProperties.getMinutes()).thenReturn(15L);
        when(snowflakeIdWorker.nextId()).thenReturn(123456L);

        CartItem item = CartItem.builder()
                .dishId(10L)
                .quantity(2)
                .specJson("{\"size\":\"M\"}")
                .build();
        when(cartMapper.selectSelectedByUserId(1L)).thenReturn(List.of(item));

        Dish dish = Dish.builder()
                .id(10L)
                .shopId(99L)
                .status(DishStatus.ON_SALE)
                .price(new BigDecimal("12.50"))
                .build();
        when(dishMapper.selectByIds(List.of(10L))).thenReturn(List.of(dish));
        when(dishMapper.deductStock(10L, 2, DishStatus.ON_SALE.ordinal())).thenReturn(1);

        when(stringRedisTemplate.opsForZSet()).thenReturn(zSetOperations);
        when(stringRedisTemplate.opsForHash()).thenReturn(hashOperations);

        long orderNo = orderService.createOrderFromCart(1L);
        Assertions.assertEquals(123456L, orderNo);

        verify(orderMapper, times(1)).insert(any(Order.class));
        verify(orderDetailMapper, times(1)).insert(any(OrderDetail.class));
        verify(cartMapper, times(1)).clearSelectedByUserId(1L);
        verify(zSetOperations, times(1)).add(eq("orders:cancel:due"), eq("123456"), anyDouble());
        verify(hashOperations, times(1)).put(eq("orders:cancel:meta"), eq("123456"), anyString());
        verify(redisLockService, times(1)).unlock(anyString(), anyString());
    }
}

