package com.smartfood.security.session;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.smartfood.dto.UserResponse;
import com.smartfood.entity.Gender;
import com.smartfood.entity.User;
import com.smartfood.entity.UserStatus;
import com.smartfood.exception.BizException;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Spy;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.data.redis.core.ValueOperations;

import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class RedisLoginSessionServiceTest {

    @Mock
    private StringRedisTemplate stringRedisTemplate;
    @Mock
    private ValueOperations<String, String> valueOps;

    @Spy
    private ObjectMapper objectMapper = new ObjectMapper();

    @InjectMocks
    private RedisLoginSessionService redisLoginSessionService;

    @Test
    void saveSession_shouldWriteJsonToRedis() {
        when(stringRedisTemplate.opsForValue()).thenReturn(valueOps);

        User user = User.builder()
                .id(1L)
                .phone("13812345678")
                .nickname("u1")
                .status(UserStatus.NORMAL)
                .gender(Gender.UNKNOWN)
                .userLevel(0)
                .build();

        redisLoginSessionService.saveSession("token-1", user);
        verify(valueOps, times(1)).set(eq("login:user:token-1"), anyString(), any());
    }

    @Test
    void requireSession_shouldThrow401_whenMissing() {
        when(stringRedisTemplate.opsForValue()).thenReturn(valueOps);
        when(valueOps.get("login:user:t")).thenReturn(null);

        BizException ex = Assertions.assertThrows(BizException.class, () -> redisLoginSessionService.requireSession("t"));
        Assertions.assertEquals(401, ex.getCode());
    }
}

