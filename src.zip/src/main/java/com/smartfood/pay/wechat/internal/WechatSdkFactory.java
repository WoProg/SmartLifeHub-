package com.smartfood.pay.wechat.internal;

import com.smartfood.config.properties.WxPayProperties;
import com.smartfood.exception.BizException;
import com.wechat.pay.java.core.Config;
import com.wechat.pay.java.core.RSAAutoCertificateConfig;
import com.wechat.pay.java.service.payments.app.AppServiceExtension;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;

/**
 * 微信支付 SDK 工厂（用于创建 AppServiceExtension）。
 *
 * 说明：
 * - Day1：mock 模式下不会调用
 * - real 模式下：构建 RSAAutoCertificateConfig 并创建 AppServiceExtension
 */
@Component
@RequiredArgsConstructor
public class WechatSdkFactory {

    private final WxPayProperties wxPayProperties;

    public AppServiceExtension appService() {
        // 仅在 real 模式下允许调用
        String mode = wxPayProperties.getMode();
        if (mode == null || !"real".equalsIgnoreCase(mode)) {
            throw new BizException(400, "当前 wxpay.mode 不是 real，无法创建真实微信 SDK 客户端");
        }

        Config config = new RSAAutoCertificateConfig.Builder()
                .merchantId(wxPayProperties.getMchid())
                .privateKeyFromPath(wxPayProperties.getPrivateKeyPath())
                .merchantSerialNumber(wxPayProperties.getMerchantSerialNumber())
                .apiV3Key(wxPayProperties.getApiV3Key())
                .build();

        return new AppServiceExtension.Builder()
                .config(config)
                .build();
    }
}

