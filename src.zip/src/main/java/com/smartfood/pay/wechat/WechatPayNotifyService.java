package com.smartfood.pay.wechat;

import com.smartfood.entity.OrderStatus;
import com.smartfood.entity.PayStatus;
import com.smartfood.exception.BizException;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;

/**
 * 微信支付通知处理核心逻辑。
 *
 * 说明：
 * - 幂等：wechat_payment_notification.wechat_notification_id 唯一约束
 * - 状态同步：仅当订单仍处于允许状态时做 conditional update
 * - 操作日志：order_operation_log(order_no,event_type) 唯一约束保证幂等
 */
@Slf4j
@Service
@RequiredArgsConstructor
public class WechatPayNotifyService {

    private final JdbcTemplate jdbcTemplate;

    public void handleNotification(Long orderNo, String tradeState, String transactionId, String rawBody) {
        if (orderNo == null) {
            throw new BizException(400, "orderNo 为空");
        }
        if (transactionId == null || transactionId.isEmpty()) {
            throw new BizException(400, "transactionId 为空，无法做幂等");
        }
        if (tradeState == null || tradeState.isEmpty()) {
            tradeState = "UNKNOWN";
        }

        // 1) 幂等：插入通知记录（INSERT IGNORE 命中重复则返回 0）
        int inserted = jdbcTemplate.update(
                "INSERT IGNORE INTO wechat_payment_notification(" +
                        "order_no, wechat_notification_id, trade_state, success_time, transaction_id, raw_body, create_time, update_time" +
                        ") VALUES (?,?,?,?,?,?,NOW(),NOW())",
                orderNo,
                transactionId,
                tradeState,
                null,
                transactionId,
                rawBody
        );

        if (inserted == 0) {
            log.info("wechat notify幂等命中：orderNo={}, transactionId={}", orderNo, transactionId);
            return;
        }

        LocalDateTime now = LocalDateTime.now();

        boolean success = "SUCCESS".equalsIgnoreCase(tradeState);
        if (success) {
            // 待付款 -> 待接单；pay_status=PAID
            int updated = jdbcTemplate.update(
                    "UPDATE `order` " +
                            "SET pay_status = ?, status = ?, pay_at = ?, update_time = ? " +
                            "WHERE order_no = ? AND status = ? AND pay_status = ?",
                    PayStatus.PAID.ordinal(),
                    OrderStatus.PENDING_ACCEPT.ordinal(),
                    now,
                    now,
                    orderNo,
                    OrderStatus.PENDING_PAYMENT.ordinal(),
                    PayStatus.NOT_PAID.ordinal()
            );

            log.info("PAY_SUCCESS 同步订单：orderNo={}, updated={}", orderNo, updated);

            jdbcTemplate.update(
                    "INSERT INTO order_operation_log(" +
                            "order_no, event_type, operator_role, operator_id, from_status, to_status, remark, create_time, update_time" +
                            ") VALUES (?,?,?,?,?,?,?,NOW(),NOW()) " +
                            "ON DUPLICATE KEY UPDATE update_time = update_time",
                    orderNo,
                    "PAY_SUCCESS",
                    0,
                    null,
                    OrderStatus.PENDING_PAYMENT.ordinal(),
                    OrderStatus.PENDING_ACCEPT.ordinal(),
                    "微信支付成功（回调）"
            );
        } else {
            // 支付失败：pending_payment -> cancelled，pay_status=FAILED
            int updated = jdbcTemplate.update(
                    "UPDATE `order` " +
                            "SET pay_status = ?, status = ?, cancelled_at = ?, update_time = ? " +
                            "WHERE order_no = ? AND status = ? AND pay_status = ?",
                    PayStatus.FAILED.ordinal(),
                    OrderStatus.CANCELLED.ordinal(),
                    now,
                    now,
                    orderNo,
                    OrderStatus.PENDING_PAYMENT.ordinal(),
                    PayStatus.NOT_PAID.ordinal()
            );

            log.info("PAY_FAIL 同步订单：orderNo={}, updated={}", orderNo, updated);

            jdbcTemplate.update(
                    "INSERT INTO order_operation_log(" +
                            "order_no, event_type, operator_role, operator_id, from_status, to_status, remark, create_time, update_time" +
                            ") VALUES (?,?,?,?,?,?,?,NOW(),NOW()) " +
                            "ON DUPLICATE KEY UPDATE update_time = update_time",
                    orderNo,
                    "PAY_FAIL",
                    0,
                    null,
                    OrderStatus.PENDING_PAYMENT.ordinal(),
                    OrderStatus.CANCELLED.ordinal(),
                    "微信支付失败/关闭（回调）"
            );
        }
    }
}

