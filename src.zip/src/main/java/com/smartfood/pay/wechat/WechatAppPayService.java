package com.smartfood.pay.wechat;

import com.smartfood.dto.WechatAppPrepayResponse;
import com.smartfood.entity.*;
import com.smartfood.exception.BizException;
import com.smartfood.mapper.OrderMapper;
import com.smartfood.config.properties.WxPayProperties;
import com.smartfood.pay.wechat.internal.WechatSdkFactory;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import java.math.BigDecimal;

import com.wechat.pay.java.service.payments.app.AppServiceExtension;
import com.wechat.pay.java.service.payments.app.model.PrepayRequest;
import com.wechat.pay.java.service.payments.app.model.PrepayWithRequestPaymentResponse;
import com.wechat.pay.java.service.payments.app.model.Amount;

/**
 * 微信支付：APP 统一下单（prepay）。
 *
 * Day1 目标：
 * - 支持 mock/real 两种模式
 * - mock 模式：不调用微信 SDK，但会落库 order.wechat_prepay_id，并返回可用于前端调起支付的参数（mock）
 * - real 模式：调用 wechatpay-java 的 AppServiceExtension.prepayWithRequestPayment 生成真实参数
 */
@Slf4j
@Service
@RequiredArgsConstructor
public class WechatAppPayService {

    private final OrderMapper orderMapper;
    private final WxPayProperties wxPayProperties;
    private final WechatSdkFactory wechatSdkFactory;

    /**
     * APP 统一下单：生成预支付参数并落库。
     *
     * @param orderNo 订单号
     * @return 前端可调起支付的参数
     */
    @Transactional
    public WechatAppPrepayResponse unifiedOrderApp(Long orderNo) {
        if (orderNo == null || orderNo <= 0) {
            throw new BizException(400, "orderNo 非法");
        }

        Order order = orderMapper.selectById(orderNo);
        if (order == null) {
            throw new BizException(404, "订单不存在");
        }

        // 只有待付款且未支付的订单允许发起预支付
        if (order.getStatus() != OrderStatus.PENDING_PAYMENT || order.getPayStatus() != PayStatus.NOT_PAID) {
            throw new BizException(409, "订单状态不允许发起预支付");
        }

        String mode = wxPayProperties.getMode();
        if (mode == null || !"real".equalsIgnoreCase(mode)) {
            return unifiedOrderMock(order);
        }
        return unifiedOrderReal(order);
    }

    private WechatAppPrepayResponse unifiedOrderMock(Order order) {
        // 幂等：如果已经生成过 prepay_id，直接返回相同结果
        String prepayId = order.getWechatPrepayId();
        if (!StringUtils.hasText(prepayId)) {
            prepayId = "wx_mock_prepay_" + order.getOrderNo();
            order.setWechatPrepayId(prepayId);
            order.setWechatOutTradeNo(String.valueOf(order.getOrderNo()));
            orderMapper.updateById(order);
            log.info("mock unified order 落库：orderNo={}, prepayId={}", order.getOrderNo(), prepayId);
        }

        return WechatAppPrepayResponse.builder()
                .prepayId(prepayId)
                .appid(wxPayProperties.getAppid() == null ? "wx_mock_appid" : wxPayProperties.getAppid())
                .partnerId(wxPayProperties.getMchid() == null ? "wx_mock_mchid" : wxPayProperties.getMchid())
                .packageValue("Sign=WXPay")
                .nonceStr("mock_nonce_" + order.getOrderNo())
                .timeStamp(String.valueOf(System.currentTimeMillis() / 1000))
                .sign("mock_sign")
                .build();
    }

    private WechatAppPrepayResponse unifiedOrderReal(Order order) {
        // 真实模式：调用 SDK 生成 prepay 参数
        AppServiceExtension appService = wechatSdkFactory.appService();

        String orderNoStr = String.valueOf(order.getOrderNo());
        // out_trade_no：通常与 order_no 绑定（允许 6-32 位字符，这里 order_no 为数字串，满足要求）
        if (orderNoStr.length() < 6 || orderNoStr.length() > 32) {
            throw new BizException(400, "orderNo 不满足微信 out_trade_no 长度要求");
        }

        PrepayRequest request = new PrepayRequest();
        request.setAppid(wxPayProperties.getAppid());
        request.setMchid(wxPayProperties.getMchid());
        request.setDescription(wxPayProperties.getDescription());
        request.setNotifyUrl(wxPayProperties.getNotifyUrl());
        request.setOutTradeNo(orderNoStr);

        // 金额：微信单位为“分”。SDK Amount.total 为 Integer（分）。
        Amount amount = new Amount();
        BigDecimal total = order.getTotalAmount();
        int totalFen = total.movePointRight(2).intValueExact();
        amount.setTotal(totalFen);
        amount.setCurrency("CNY");
        request.setAmount(amount);

        // 预支付：返回 APP 调起支付参数（SDK 负责签名计算）
        PrepayWithRequestPaymentResponse response = appService.prepayWithRequestPayment(request);

        // 落库
        order.setWechatPrepayId(response.getPrepayId());
        order.setWechatOutTradeNo(orderNoStr);
        order.setUpdateTime(java.time.LocalDateTime.now());
        orderMapper.updateById(order);

        return WechatAppPrepayResponse.builder()
                .prepayId(response.getPrepayId())
                .appid(response.getAppid())
                .partnerId(response.getPartnerId())
                .packageValue(response.getPackageVal())
                .nonceStr(response.getNonceStr())
                .timeStamp(response.getTimestamp())
                .sign(response.getSign())
                .build();
    }
}

