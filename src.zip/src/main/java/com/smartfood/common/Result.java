package com.smartfood.common;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.Instant;

/**
 * 统一返回结果封装类（建议前后端约定一致的响应格式）。
 *
 * Day1 目标：
 * - 让后续所有 Controller 统一返回 `Result`，减少重复的返回结构处理
 * - 让异常处理器可以直接把错误信息包装成统一格式
 *
 * 约定字段：
 * - code：业务状态码（0 表示成功，其他表示失败）
 * - message：提示信息（成功/失败的说明）
 * - data：成功时携带的数据（失败时可为空）
 * - timestamp：响应时间戳（便于排查问题）
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class Result<T> {

    /**
     * 成功业务码。
     * 注：这里先用 0 表示成功，后续你可以按项目规范改成更丰富的 code 枚举。
     */
    private Integer code;

    /**
     * 提示信息。
     */
    private String message;

    /**
     * 响应数据。
     */
    private T data;

    /**
     * 响应时间戳（毫秒）。
     */
    private Long timestamp;

    private static final Integer SUCCESS_CODE = 0;
    private static final Integer ERROR_CODE = 500;
    private static final Integer VALIDATION_ERROR_CODE = 400;

    /**
     * 成功但不返回 data 的便捷方法。
     */
    public static <T> Result<T> success() {
        return new Result<>(SUCCESS_CODE, "操作成功", null, Instant.now().toEpochMilli());
    }

    /**
     * 成功并返回 data 的便捷方法。
     */
    public static <T> Result<T> success(T data) {
        return new Result<>(SUCCESS_CODE, "操作成功", data, Instant.now().toEpochMilli());
    }

    /**
     * 失败的便捷方法（默认错误码 500）。
     */
    public static <T> Result<T> fail(String message) {
        return fail(ERROR_CODE, message);
    }

    /**
     * 失败的便捷方法（自定义错误码）。
     */
    public static <T> Result<T> fail(Integer code, String message) {
        return new Result<>(code, message, null, Instant.now().toEpochMilli());
    }

    /**
     * 参数校验失败的便捷方法（默认错误码 400）。
     */
    public static <T> Result<T> validationFail(String message) {
        return fail(VALIDATION_ERROR_CODE, message);
    }
}

