package com.smartfood.exception;

import com.smartfood.common.Result;
import com.smartfood.exception.BizException;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import org.springframework.web.HttpRequestMethodNotSupportedException;
import org.springframework.http.converter.HttpMessageNotReadableException;

import javax.validation.ConstraintViolationException;
import java.util.List;

/**
 * 全局异常处理器。
 *
 * Day1 目标：
 * - 所有异常都能被统一封装为 `Result` 返回给前端
 * - 对常见异常（参数校验、JSON 反序列化失败等）给出更友好的 message
 *
 * 说明：
 * - 这里先覆盖常见情况，后续业务模块会继续补充更细粒度的异常处理逻辑。
 */
@Slf4j
@RestControllerAdvice
public class GlobalExceptionHandler {

    /**
     * 处理 Bean Validation 校验失败异常（@Valid / @Validated）。
     */
    @ExceptionHandler(MethodArgumentNotValidException.class)
    public ResponseEntity<Result<Void>> handleMethodArgumentNotValid(MethodArgumentNotValidException ex) {
        // 取第一个字段错误信息作为提示（也可以改为汇总所有错误）
        List<FieldError> fieldErrors = ex.getBindingResult().getFieldErrors();
        String message = "参数校验失败";
        if (fieldErrors != null && !fieldErrors.isEmpty()) {
            FieldError first = fieldErrors.get(0);
            message = String.format("参数校验失败：%s %s", first.getField(), first.getDefaultMessage());
        }

        log.warn("参数校验失败: {}", message, ex);
        return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                .body(Result.validationFail(message));
    }

    /**
     * 处理 ConstraintViolationException（当你直接使用 Validator 或方法级校验时可能出现）。
     */
    @ExceptionHandler(ConstraintViolationException.class)
    public ResponseEntity<Result<Void>> handleConstraintViolation(ConstraintViolationException ex) {
        String message = "参数校验失败：" + ex.getMessage();
        log.warn("ConstraintViolationException: {}", message, ex);
        return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                .body(Result.validationFail(message));
    }

    /**
     * 处理请求体 JSON 反序列化失败（例如字段类型不匹配、JSON 格式错误等）。
     */
    @ExceptionHandler(HttpMessageNotReadableException.class)
    public ResponseEntity<Result<Void>> handleHttpMessageNotReadable(HttpMessageNotReadableException ex) {
        String message = "请求参数格式错误：" + ex.getMostSpecificCause().getMessage();
        log.warn("HttpMessageNotReadableException: {}", message, ex);
        return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                .body(Result.fail(HttpStatus.BAD_REQUEST.value(), message));
    }

    /**
     * 处理不支持的请求方法异常（例如只支持 POST 却发了 GET）。
     */
    @ExceptionHandler(HttpRequestMethodNotSupportedException.class)
    public ResponseEntity<Result<Void>> handleMethodNotSupported(HttpRequestMethodNotSupportedException ex) {
        String message = "请求方法不支持：" + ex.getMethod();
        log.warn("HttpRequestMethodNotSupportedException: {}", message, ex);
        return ResponseEntity.status(HttpStatus.METHOD_NOT_ALLOWED)
                .body(Result.fail(HttpStatus.METHOD_NOT_ALLOWED.value(), message));
    }

    /**
     * 兜底处理：任何未被明确捕获的异常都返回统一格式。
     */
    @ExceptionHandler(Exception.class)
    public ResponseEntity<Result<Void>> handleException(Exception ex) {
        // 不把堆栈/敏感信息返回前端，只记录日志。
        String message = "系统异常，请稍后重试";
        log.error("Unhandled exception occurred.", ex);
        return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                .body(Result.fail(HttpStatus.INTERNAL_SERVER_ERROR.value(), message));
    }

    /**
     * 处理业务异常：将 BizException 的 code/message 返回到统一的 Result 格式中。
     */
    @ExceptionHandler(BizException.class)
    public ResponseEntity<Result<Void>> handleBizException(BizException ex) {
        // 业务异常一般不需要返回堆栈信息，避免泄露内部实现细节
        log.warn("BizException: code={}, message={}", ex.getCode(), ex.getMessage(), ex);

        // 这里的 code 与 HTTP 状态码可能不一致，所以直接用 code 作为 Result.code，
        // HTTP 状态码用默认 200/4xx/5xx 也可以更精细化（后续你可再扩展）。
        int httpStatus = HttpStatus.OK.value();
        // 常见约定：401/403/404/409/400 用作 HTTP 状态更直观；不满足则兜底为 200 + 错误码
        if (ex.getCode() != null) {
            if (ex.getCode() == HttpStatus.BAD_REQUEST.value()
                    || ex.getCode() == HttpStatus.UNAUTHORIZED.value()
                    || ex.getCode() == HttpStatus.FORBIDDEN.value()
                    || ex.getCode() == HttpStatus.NOT_FOUND.value()
                    || ex.getCode() == HttpStatus.CONFLICT.value()
                    || ex.getCode() == HttpStatus.METHOD_NOT_ALLOWED.value()) {
                httpStatus = ex.getCode();
            }
        }

        return ResponseEntity.status(httpStatus)
                .body(Result.fail(ex.getCode(), ex.getMessage()));
    }
}

