package com.smartfood.exception;

import lombok.Getter;

/**
 * 业务异常：用于表达“可预期的业务失败”。
 *
 * 与系统异常（NullPointerException、数据库异常等）区分：
 * - 业务异常：通常需要返回明确的业务提示给前端（如手机号已注册、密码错误等）
 * - 系统异常：一般返回统一的“系统异常，请稍后重试”
 */
@Getter
public class BizException extends RuntimeException {

    /**
     * 业务错误码。建议约定：0 成功，其他为失败（此处为了简单直接复用 HTTP 状态码或自定义业务码）。
     */
    private final Integer code;

    /**
     * 提示信息。
     */
    private final String message;

    public BizException(Integer code, String message) {
        super(message);
        this.code = code;
        this.message = message;
    }
}

