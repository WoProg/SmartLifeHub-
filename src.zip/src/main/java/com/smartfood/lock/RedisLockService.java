package com.smartfood.lock;

import lombok.RequiredArgsConstructor;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.data.redis.core.script.DefaultRedisScript;
import org.springframework.stereotype.Service;

import java.time.Duration;
import java.util.Collections;

/**
 * Redis 分布式锁（纯 SETNX + PX + Lua 释放）。
 *
 * 设计要点：
 * - 使用 value(token) 区分“谁持有锁”，释放时必须校验 token，避免误删他人锁
 * - tryLock 采用 SET key value NX PX ttlMillis 的语义（Spring 封装为 setIfAbsent + TTL）
 * - unlock 用 Lua 做原子校验：if redis.call('get',key)==value then del end
 */
@Service
@RequiredArgsConstructor
public class RedisLockService {

    private final StringRedisTemplate stringRedisTemplate;

    /**
     * SETNX + PX 获取锁（带过期时间，避免死锁）。
     *
     * @param lockKey 锁 key
     * @param token   锁持有标识（建议用 UUID）
     * @param ttl      锁过期时间（避免死锁）
     * @return true：获取成功；false：获取失败
     */
    public boolean tryLock(String lockKey, String token, Duration ttl) {
        Boolean success = stringRedisTemplate.opsForValue()
                .setIfAbsent(lockKey, token, ttl);
        return Boolean.TRUE.equals(success);
    }

    /**
     * 释放锁：只有当 Redis 中的值与 token 相等时才删除。
     *
     * @param lockKey 锁 key
     * @param token   锁持有标识
     * @return true：删除成功；false：token 不一致或未命中
     */
    public boolean unlock(String lockKey, String token) {
        // Lua 脚本：原子校验 + 删除
        String lua = "if redis.call('get', KEYS[1]) == ARGV[1] then " +
                "  return redis.call('del', KEYS[1]) " +
                "else " +
                "  return 0 " +
                "end";

        DefaultRedisScript<Long> script = new DefaultRedisScript<>(lua, Long.class);
        Long result = stringRedisTemplate.execute(
                script,
                Collections.singletonList(lockKey),
                token
        );

        return result != null && result > 0;
    }
}

