package com.smartfood.id;

import com.smartfood.config.properties.SnowflakeProperties;
import org.springframework.stereotype.Component;

/**
 * 雪花算法实现：生成全局唯一的 long 类型 ID。
 *
 * 满足：
 * - 可配置 workerId / datacenterId / epochMillis
 * - 线程安全（使用 synchronized 保证同一时刻 sequence 的正确性）
 * - 时钟回拨处理：当系统时间 < 上一次时间，会等待到 lastTimestamp 之后继续
 *
 * 典型位分配（默认方案）：
 * - timestamp：41 bits（毫秒）
 * - datacenterId：5 bits
 * - workerId：5 bits
 * - sequence：12 bits
 */
@Component
public class SnowflakeIdWorker {

    /**
     * 序列号占用位数。
     */
    private static final long SEQUENCE_BITS = 12L;

    /**
     * workerId 占用位数。
     */
    private static final long WORKER_ID_BITS = 5L;

    /**
     * datacenterId 占用位数。
     */
    private static final long DATACENTER_ID_BITS = 5L;

    /**
     * 最大 sequence 值。
     */
    private static final long SEQUENCE_MASK = (1L << SEQUENCE_BITS) - 1L;

    /**
     * workerId 最大值（5 bits）。
     */
    private static final long MAX_WORKER_ID = (1L << WORKER_ID_BITS) - 1L;

    /**
     * datacenterId 最大值（5 bits）。
     */
    private static final long MAX_DATACENTER_ID = (1L << DATACENTER_ID_BITS) - 1L;

    /**
     * 时间左移位数：datacenterIdBits + workerIdBits + sequenceBits
     */
    private static final long TIMESTAMP_LEFT_SHIFT = DATACENTER_ID_BITS + WORKER_ID_BITS + SEQUENCE_BITS;

    /**
     * datacenterId 左移位数：workerIdBits + sequenceBits
     */
    private static final long DATACENTER_ID_SHIFT = WORKER_ID_BITS + SEQUENCE_BITS;

    /**
     * workerId 左移位数：sequenceBits
     */
    private static final long WORKER_ID_SHIFT = SEQUENCE_BITS;

    private final long workerId;
    private final long datacenterId;
    private final long epochMillis;

    /**
     * 上一次生成 ID 的时间戳（毫秒）。
     */
    private long lastTimestamp = -1L;

    /**
     * 同一毫秒内的序列号。
     */
    private long sequence = 0L;

    public SnowflakeIdWorker(SnowflakeProperties properties) {
        if (properties.getWorkerId() < 0 || properties.getWorkerId() > MAX_WORKER_ID) {
            throw new IllegalArgumentException("workerId 超出范围：0~" + MAX_WORKER_ID);
        }
        if (properties.getDatacenterId() < 0 || properties.getDatacenterId() > MAX_DATACENTER_ID) {
            throw new IllegalArgumentException("datacenterId 超出范围：0~" + MAX_DATACENTER_ID);
        }
        this.workerId = properties.getWorkerId();
        this.datacenterId = properties.getDatacenterId();
        this.epochMillis = properties.getEpochMillis();
    }

    /**
     * 生成下一个唯一 ID。
     *
     * @return 雪花 ID（long）
     */
    public synchronized long nextId() {
        long timestamp = currentTime();

        // 时钟回拨处理：等待到 lastTimestamp 之后
        if (timestamp < lastTimestamp) {
            timestamp = waitUntil(lastTimestamp);
        }

        if (timestamp == lastTimestamp) {
            // 同一毫秒内：sequence 自增，并取掩码避免溢出
            sequence = (sequence + 1) & SEQUENCE_MASK;
            if (sequence == 0L) {
                // sequence 用尽：等待下一毫秒
                timestamp = waitNextMillis(lastTimestamp);
            }
        } else {
            // 新毫秒：重置 sequence
            sequence = 0L;
        }

        lastTimestamp = timestamp;

        // 组装最终 ID
        return ((timestamp - epochMillis) << TIMESTAMP_LEFT_SHIFT)
                | (datacenterId << DATACENTER_ID_SHIFT)
                | (workerId << WORKER_ID_SHIFT)
                | sequence;
    }

    /**
     * 获取当前系统时间戳（毫秒）。
     */
    private long currentTime() {
        return System.currentTimeMillis();
    }

    /**
     * 等待到指定时间戳（毫秒）之后。
     */
    private long waitUntil(long targetTimestamp) {
        long ts = currentTime();
        while (ts < targetTimestamp) {
            try {
                Thread.sleep(1L);
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
                throw new RuntimeException("等待雪花时间回拨恢复被中断", e);
            }
            ts = currentTime();
        }
        return ts;
    }

    /**
     * 等待下一毫秒，以确保 sequence 不会在同一毫秒内再次溢出。
     */
    private long waitNextMillis(long currentLastTimestamp) {
        long ts = currentTime();
        while (ts <= currentLastTimestamp) {
            ts = currentTime();
        }
        return ts;
    }
}

