package com.smartfood;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.mybatis.spring.annotation.MapperScan;
import org.springframework.scheduling.annotation.EnableScheduling;

/**
 * 智能餐饮平台后端 Spring Boot 启动类。
 *
 * Day1 主要作用：
 * - 启动 Spring 容器
 * - 扫描 `com.smartfood` 下的组件（Controller / Service / Config 等）
 */
@SpringBootApplication
@MapperScan("com.smartfood.mapper")
@EnableScheduling
public class SmartFoodPlatformApplication {

    /**
     * 应用入口。
     *
     * @param args 命令行参数（可用于后续扩展，如指定 profile）
     */
    public static void main(String[] args) {
        SpringApplication.run(SmartFoodPlatformApplication.class, args);
    }
}

