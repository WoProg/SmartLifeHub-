package com.smartfood.seckill.worker;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.smartfood.seckill.CouponSeckillResult;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.dao.DataAccessException;
import org.springframework.data.redis.RedisConnectionFailureException;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.data.redis.core.ListOperations;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import java.time.Duration;
import java.util.ArrayList;
import java.util.List;

/**
 * 秒杀订单异步落库 Worker（Redis 队列 -> DB -> 回写结果）。
 *
 * 当前 Milestone：
 * - 支持 Redis 异步处理骨架
 * - DB 表结构需要你后续补齐（coupon_order）
 */
@Slf4j
@Component
@RequiredArgsConstructor
public class CouponOrderWorker {

    private static final String QUEUE_KEY = "coupon:order:queue";
    private static final String RESULT_KEY_PREFIX = "coupon:result:";
    private static final String PROCESSED_KEY_PREFIX = "coupon:order:processed:";

    private static final int BATCH_SIZE = 50;
    private static final Duration PROCESSED_TTL = Duration.ofDays(1);
    private volatile boolean redisUnavailableLogged;

    private final StringRedisTemplate stringRedisTemplate;
    private final JdbcTemplate jdbcTemplate;
    private final ObjectMapper objectMapper;

    @Scheduled(fixedDelayString = "${app.seckill.order-worker.fixed-delay-ms:1000}")
    public void tick() {
        try {
            List<String> messages = rpopBatch(BATCH_SIZE);
            if (messages.isEmpty()) {
                return;
            }

            for (String msg : messages) {
                processMessage(msg);
            }
        } catch (RedisConnectionFailureException e) {
            // Redis 不可用时降级跳过，避免定时任务持续刷 error 干扰验收日志。
            if (!redisUnavailableLogged) {
                log.warn("CouponOrderWorker skipped: Redis unavailable");
                redisUnavailableLogged = true;
            }
        } catch (Exception e) {
            log.error("CouponOrderWorker tick error", e);
        }
    }

    private void processMessage(String msg) {
        if (msg == null || msg.isBlank()) {
            return;
        }

        // msg: orderNo:userId:couponId
        String[] parts = msg.split(":");
        if (parts.length != 3) {
            log.warn("CouponOrderWorker invalid msg: {}", msg);
            return;
        }

        long orderNo;
        long userId;
        long couponId;
        try {
            orderNo = Long.parseLong(parts[0]);
            userId = Long.parseLong(parts[1]);
            couponId = Long.parseLong(parts[2]);
        } catch (Exception e) {
            log.warn("CouponOrderWorker parse msg failed: {}", msg, e);
            return;
        }

        String processedKey = PROCESSED_KEY_PREFIX + orderNo;
        try {
            if (Boolean.TRUE.equals(stringRedisTemplate.hasKey(processedKey))) {
                return; // 幂等：已处理
            }

            // TODO：补齐 DB 表字段映射/唯一约束（couponId+userId），这里仅作为骨架示例
            jdbcTemplate.update(
                    "INSERT INTO coupon_order(order_no, user_id, coupon_id, create_time) VALUES (?,?,?,NOW())",
                    orderNo, userId, couponId
            );

            CouponSeckillResult ok = CouponSeckillResult.builder()
                    .status("SUCCESS")
                    .orderNo(orderNo)
                    .reason(null)
                    .build();
            writeResult(couponId, userId, ok);
        } catch (DataAccessException e) {
            log.warn("CouponOrderWorker db insert failed: msg={}", msg, e);

            CouponSeckillResult fail = CouponSeckillResult.builder()
                    .status("FAIL")
                    .orderNo(orderNo)
                    .reason("DB_INSERT_FAILED")
                    .build();
            writeResult(couponId, userId, fail);
        } finally {
            // 即使失败也标记为已处理，避免 worker 因异常反复消费同一条
            try {
                stringRedisTemplate.opsForValue().set(processedKey, "1", PROCESSED_TTL);
            } catch (Exception ignored) {
            }
        }
    }

    private List<String> rpopBatch(int batchSize) {
        ListOperations<String, String> ops = stringRedisTemplate.opsForList();
        List<String> out = new ArrayList<>(batchSize);
        for (int i = 0; i < batchSize; i++) {
            String v = ops.rightPop(QUEUE_KEY);
            if (v == null) {
                break;
            }
            out.add(v);
        }
        return out;
    }

    private void writeResult(long couponId, long userId, CouponSeckillResult result) {
        try {
            String key = RESULT_KEY_PREFIX + couponId + ":" + userId;
            String json = objectMapper.writeValueAsString(result);
            stringRedisTemplate.opsForValue().set(key, json, Duration.ofDays(1));
        } catch (Exception e) {
            log.warn("CouponOrderWorker writeResult failed", e);
        }
    }
}

