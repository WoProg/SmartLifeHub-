package com.smartfood.seckill;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.smartfood.exception.BizException;
import com.smartfood.id.SnowflakeIdWorker;
import com.smartfood.security.session.RedisLoginSessionService;
import lombok.RequiredArgsConstructor;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.data.redis.core.script.DefaultRedisScript;
import org.springframework.stereotype.Service;

import java.time.Duration;
import java.util.List;

/**
 * 优惠券秒杀核心：Redis 库存 + Lua 原子扣减 + 异步落库队列。
 */
@Service
@RequiredArgsConstructor
public class CouponSeckillService {

    // Redis Keys
    private static final String STOCK_KEY_PREFIX = "coupon:stock:";
    private static final String USER_SET_KEY_PREFIX = "coupon:user:";
    private static final String QUEUE_KEY = "coupon:order:queue";
    private static final String RESULT_KEY_PREFIX = "coupon:result:";

    // TTL：结果保留一段时间，便于前端异步轮询
    private static final Duration RESULT_TTL = Duration.ofDays(1);

    private final StringRedisTemplate stringRedisTemplate;
    private final SnowflakeIdWorker snowflakeIdWorker;
    private final RedisLoginSessionService redisLoginSessionService;
    private final ObjectMapper objectMapper;

    private final DefaultRedisScript<Long> seckillLuaScript = new DefaultRedisScript<>(
            // 返回值：0=成功，1=库存不足，2=一人一券
            "" +
                    "local stockKey = KEYS[1] \n" +
                    "local userSetKey = KEYS[2] \n" +
                    "local userId = ARGV[1] \n" +
                    "local stock = tonumber(redis.call('get', stockKey) or '0') \n" +
                    "if stock <= 0 then return 1 end \n" +
                    "if redis.call('sismember', userSetKey, userId) == 1 then return 2 end \n" +
                    "redis.call('decr', stockKey) \n" +
                    "redis.call('sadd', userSetKey, userId) \n" +
                    "return 0",
            Long.class
    );

    public void preloadStock(Long couponId, int stock) {
        if (couponId == null || couponId <= 0) {
            throw new BizException(400, "couponId非法");
        }
        if (stock < 0) {
            throw new BizException(400, "stock非法");
        }

        String stockKey = stockKey(couponId);
        String userSetKey = userSetKey(couponId);

        stringRedisTemplate.opsForValue().set(stockKey, String.valueOf(stock));
        // 每次预热重新清空已抢集合（演示/初始化用）
        stringRedisTemplate.delete(userSetKey);
    }

    /**
     * 执行秒杀：Lua 原子扣减库存 + 一人一券。
     * 成功后写入 Redis 队列，返回 PROCESSING；最终结果由 Worker 回写。
     */
    public CouponSeckillResult seckill(Long couponId, String authorization) {
        if (couponId == null || couponId <= 0) {
            throw new BizException(400, "couponId非法");
        }
        if (authorization == null || authorization.trim().isEmpty()) {
            throw new BizException(401, "缺少 Authorization header");
        }

        String token = authorization.trim();
        if (token.toLowerCase().startsWith("bearer ")) {
            token = token.substring(7).trim();
        }

        // 分布式 Session 校验 + 滑动续期
        Long userId = redisLoginSessionService.requireSession(token).getId();

        String stockKey = stockKey(couponId);
        String userSetKey = userSetKey(couponId);

        Long luaResult = stringRedisTemplate.execute(
                seckillLuaScript,
                List.of(stockKey, userSetKey),
                userId.toString()
        );

        if (luaResult == null) {
            throw new BizException(500, "秒杀失败，请稍后重试");
        }

        // 构建结果 key：coupon:result:{couponId}:{userId}
        String resultKey = resultKey(couponId, userId);

        if (luaResult == 1L) {
            setResult(resultKey, CouponSeckillResult.builder()
                    .status("FAIL")
                    .orderNo(null)
                    .reason("OUT_OF_STOCK")
                    .build());
            return getResult(resultKey);
        }

        if (luaResult == 2L) {
            setResult(resultKey, CouponSeckillResult.builder()
                    .status("FAIL")
                    .orderNo(null)
                    .reason("REPEATED")
                    .build());
            return getResult(resultKey);
        }

        // 成功：生成 orderNo 入队，前端异步轮询结果
        long orderNo = snowflakeIdWorker.nextId();

        CouponSeckillResult processing = CouponSeckillResult.builder()
                .status("PROCESSING")
                .orderNo(orderNo)
                .reason(null)
                .build();
        setResult(resultKey, processing);

        try {
            // 队列消息格式：orderNo:userId:couponId
            String msg = orderNo + ":" + userId + ":" + couponId;
            // 使用右出队（Worker RPOP）避免阻塞
            stringRedisTemplate.opsForList().rightPush(QUEUE_KEY, msg);
        } catch (Exception e) {
            // 队列入失败：回滚 Redis 结果并提示重试（库存已经扣了，真实系统需要补偿策略）
            throw new BizException(500, "队列写入失败，请稍后重试");
        }

        return processing;
    }

    public CouponSeckillResult getResult(Long couponId, Long userId) {
        if (couponId == null || couponId <= 0 || userId == null || userId <= 0) {
            throw new BizException(400, "参数非法");
        }
        return getResult(resultKey(couponId, userId));
    }

    public void pushResultToCache(Long couponId, Long userId, CouponSeckillResult result) {
        String resultKey = resultKey(couponId, userId);
        setResult(resultKey, result);
    }

    private void setResult(String key, CouponSeckillResult result) {
        try {
            String json = objectMapper.writeValueAsString(result);
            stringRedisTemplate.opsForValue().set(key, json, RESULT_TTL);
        } catch (Exception e) {
            // 写入失败不抛异常，避免阻断秒杀主流程
        }
    }

    private CouponSeckillResult getResult(String key) {
        try {
            String json = stringRedisTemplate.opsForValue().get(key);
            if (json == null) {
                return null;
            }
            return objectMapper.readValue(json, CouponSeckillResult.class);
        } catch (Exception e) {
            throw new BizException(500, "结果解析失败");
        }
    }

    private String stockKey(Long couponId) {
        return STOCK_KEY_PREFIX + couponId;
    }

    private String userSetKey(Long couponId) {
        return USER_SET_KEY_PREFIX + couponId;
    }

    private String resultKey(Long couponId, Long userId) {
        return RESULT_KEY_PREFIX + couponId + ":" + userId;
    }
}

