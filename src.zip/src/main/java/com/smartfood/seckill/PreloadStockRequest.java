package com.smartfood.seckill;

import lombok.Data;

import javax.validation.constraints.Min;

import io.swagger.v3.oas.annotations.media.Schema;

/**
 * 秒杀预热库存请求参数（用于测试/演示）。
 */
@Data
@Schema(description = "秒杀预热库存请求参数")
public class PreloadStockRequest {

    @Min(value = 0, message = "stock 不能为负数")
    private Integer stock;
}

