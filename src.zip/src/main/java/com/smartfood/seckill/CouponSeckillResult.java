package com.smartfood.seckill;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * 秒杀结果（用于异步结果查询）。
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class CouponSeckillResult {
    /**
     * PROCESSING / SUCCESS / FAIL
     */
    private String status;

    private Long orderNo;

    /**
     * 失败原因（当 status=FAIL 时）
     */
    private String reason;
}

