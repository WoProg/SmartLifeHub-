package com.smartfood.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

import javax.persistence.*;
import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.List;

/**
 * 订单主表实体：`order`
 *
 * Day1/Day2 核心字段：
 * - `orderNo`：雪花算法生成的订单号（业务主键）
 * - `status`：订单状态
 * - `payStatus`：支付状态
 * - `cancelAt`：超时取消时间点（用于 Redis 延迟队列触发）
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "`order`")
@TableName("`order`")
public class Order extends BaseEntity {

    /**
     * 业务主键：雪花订单号
     */
    @Id
    @TableId(value = "order_no", type = IdType.INPUT)
    @Column(name = "order_no", nullable = false)
    private Long orderNo;

    /**
     * 用户 id
     */
    @TableField("user_id")
    @Column(name = "user_id", nullable = false)
    private Long userId;

    /**
     * 店铺 id
     */
    @TableField("shop_id")
    @Column(name = "shop_id", nullable = false)
    private Long shopId;

    /**
     * 订单总金额
     */
    @TableField("total_amount")
    @Column(name = "total_amount", nullable = false, precision = 10, scale = 2)
    private BigDecimal totalAmount;

    /**
     * 订单状态
     */
    @Enumerated(EnumType.ORDINAL)
    @TableField("status")
    @Column(name = "status", nullable = false)
    private OrderStatus status;

    /**
     * 支付方式
     */
    @Enumerated(EnumType.ORDINAL)
    @TableField("pay_method")
    @Column(name = "pay_method", nullable = false)
    private PayMethod payMethod;

    /**
     * 支付状态
     */
    @Enumerated(EnumType.ORDINAL)
    @TableField("pay_status")
    @Column(name = "pay_status", nullable = false)
    private PayStatus payStatus;

    /**
     * 微信 prepay_id（用于前端调起支付，mock/real 都会落库）
     */
    @TableField("wechat_prepay_id")
    @Column(name = "wechat_prepay_id", length = 64)
    private String wechatPrepayId;

    /**
     * 微信 trade_no
     */
    @TableField("wechat_trade_no")
    @Column(name = "wechat_trade_no", length = 64)
    private String wechatTradeNo;

    /**
     * 微信 out_trade_no（通常和 orderNo 对应）
     */
    @TableField("wechat_out_trade_no")
    @Column(name = "wechat_out_trade_no", length = 64)
    private String wechatOutTradeNo;

    /**
     * 支付回调入参摘要（JSON 字符串）
     */
    @TableField("pay_callback_params")
    @Column(name = "pay_callback_params", columnDefinition = "json")
    private String payCallbackParams;

    /**
     * 超时取消触发点（延迟队列根据此字段计算 cancelAt）
     */
    @TableField("cancel_at")
    @Column(name = "cancel_at", nullable = false)
    private LocalDateTime cancelAt;

    /**
     * 取消完成时间
     */
    @TableField("cancelled_at")
    @Column(name = "cancelled_at")
    private LocalDateTime cancelledAt;

    /**
     * 支付完成时间
     */
    @TableField("pay_at")
    @Column(name = "pay_at")
    private LocalDateTime payAt;

    /**
     * 订单完成时间
     */
    @TableField("finish_at")
    @Column(name = "finish_at")
    private LocalDateTime finishAt;

    /**
     * 明细列表（JPA 关系）
     */
    @OneToMany(mappedBy = "order", cascade = CascadeType.ALL)
    @ToString.Exclude
    private List<OrderDetail> orderDetails;
}

