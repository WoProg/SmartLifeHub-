package com.smartfood.entity;

/**
 * 订单状态枚举（用于 order.status）。
 *
 * 存储方式：
 * - 数据库使用 TINYINT
 * - Java 使用 ordinal 对应数据库值（因此枚举顺序必须稳定）
 *
 * 状态含义：
 * - 待付款：用户已创建但尚未支付
 * - 待接单：商家已收到待接单订单
 * - 制作中：商家开始制作
 * - 待配送：制作完成后等待骑手接单
 * - 配送中：骑手已开始配送
 * - 已完成：配送完成
 * - 已取消：超时或用户取消（仅限待付款未支付）
 */
public enum OrderStatus {

    /**
     * 待付款
     */
    PENDING_PAYMENT(0),

    /**
     * 待接单
     */
    PENDING_ACCEPT(1),

    /**
     * 制作中
     */
    MAKING(2),

    /**
     * 待配送
     */
    PENDING_DELIVERY(3),

    /**
     * 配送中
     */
    DELIVERING(4),

    /**
     * 已完成
     */
    COMPLETED(5),

    /**
     * 已取消
     */
    CANCELLED(6);

    private final int code;

    OrderStatus(int code) {
        this.code = code;
    }

    public int getCode() {
        return code;
    }
}

