package com.smartfood.entity;

import lombok.Data;

import javax.persistence.Column;
import javax.persistence.MappedSuperclass;
import javax.persistence.PrePersist;
import javax.persistence.PreUpdate;
import java.time.LocalDateTime;

/**
 * BaseEntity：所有业务实体的公共字段基类。
 *
 * Day1 要求：
 * - 包含 `createTime`：创建时间
 * - 包含 `updateTime`：更新时间
 * - 自动填充（通过 JPA 生命周期回调）
 */
@Data
@MappedSuperclass
public class BaseEntity {

    /**
     * 创建时间。
     */
    @Column(name = "create_time", nullable = false, updatable = false)
    private LocalDateTime createTime;

    /**
     * 更新时间。
     */
    @Column(name = "update_time", nullable = false)
    private LocalDateTime updateTime;

    /**
     * 在第一次持久化时自动填充创建时间与更新时间。
     */
    @PrePersist
    public void prePersist() {
        LocalDateTime now = LocalDateTime.now();
        this.createTime = now;
        this.updateTime = now;
    }

    /**
     * 在更新时自动填充更新时间。
     */
    @PreUpdate
    public void preUpdate() {
        this.updateTime = LocalDateTime.now();
    }
}

