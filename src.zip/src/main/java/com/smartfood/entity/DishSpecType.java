package com.smartfood.entity;

/**
 * 菜品规格类型：用于描述菜品是否启用多规格。
 *
 * 数据库存储：使用 ordinal（0/1）。
 */
public enum DishSpecType {
    /**
     * 不支持规格（单一价格/单一口味）。
     */
    SINGLE(0),
    /**
     * 支持多规格（例如：套餐/口味/尺码等）。
     */
    MULTI(1);

    private final int code;

    DishSpecType(int code) {
        this.code = code;
    }

    public int getCode() {
        return code;
    }
}

