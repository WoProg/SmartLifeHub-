package com.smartfood.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

import javax.persistence.*;
import java.math.BigDecimal;
import java.time.LocalDateTime;

/**
 * 订单明细表实体：order_detail
 *
 * Day1/Day2 设计目标：
 * - 保存每个订单中每个菜品的数量/单价/规格快照
 * - 支持多规格：spec_json 以 JSON 快照形式固化
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Entity
@TableName("order_detail")
@Table(name = "order_detail")
public class OrderDetail extends BaseEntity {

    /**
     * 主键（自增）。
     */
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @TableId(value = "id", type = IdType.AUTO)
    private Long id;

    /**
     * 订单号（外键到 order.order_no）。
     */
    @TableField("order_no")
    @Column(name = "order_no", nullable = false)
    private Long orderNo;

    /**
     * 菜品 id（外键到 dish.id）。
     */
    @TableField("dish_id")
    @Column(name = "dish_id", nullable = false)
    private Long dishId;

    /**
     * 购买数量。
     */
    @TableField("quantity")
    @Column(name = "quantity", nullable = false)
    private Integer quantity;

    /**
     * 下单时菜品单价（快照）。
     */
    @TableField("unit_price")
    @Column(name = "unit_price", nullable = false, precision = 10, scale = 2)
    private BigDecimal unitPrice;

    /**
     * 规格快照 JSON。
     */
    @TableField("spec_json")
    @Column(name = "spec_json", columnDefinition = "json")
    private String specJson;

    /**
     * JPA 订单关系（insert/update 时以字段 orderNo 为准）。
     */
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "order_no", referencedColumnName = "order_no", insertable = false, updatable = false)
    @ToString.Exclude
    private Order order;

    /**
     * JPA 菜品关系（insert/update 时以字段 dishId 为准）。
     */
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "dish_id", referencedColumnName = "id", insertable = false, updatable = false)
    @ToString.Exclude
    private Dish dish;

    // createTime/updateTime 继承自 BaseEntity
}

