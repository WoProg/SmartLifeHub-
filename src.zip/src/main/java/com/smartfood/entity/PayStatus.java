package com.smartfood.entity;

/**
 * 支付状态枚举（用于 order.pay_status）。
 *
 * 存储方式：
 * - 数据库使用 TINYINT
 * - Java 使用 ordinal 对应数据库值，因此枚举顺序必须稳定
 */
public enum PayStatus {

    /**
     * 未支付
     */
    NOT_PAID(0),

    /**
     * 已支付
     */
    PAID(1),

    /**
     * 支付失败
     */
    FAILED(2),

    /**
     * 退款中（预留）
     */
    REFUNDING(3),

    /**
     * 已退款（预留）
     */
    REFUNDED(4);

    private final int code;

    PayStatus(int code) {
        this.code = code;
    }

    public int getCode() {
        return code;
    }
}

