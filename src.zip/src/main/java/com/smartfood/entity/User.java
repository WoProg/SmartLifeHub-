package com.smartfood.entity;

import com.baomidou.mybatisplus.annotation.TableName;
import com.baomidou.mybatisplus.annotation.TableField;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

import javax.persistence.*;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;

/**
 * 用户表实体：`user`
 *
 * Day1 用户基础信息：
 * - 通过手机号注册与登录
 * - 存储基础昵称、头像、性别、生日等
 * - 存储用户状态（正常/禁用）与最后登录时间
 *
 * 与地址表的关系：
 * - 一个用户可以拥有多个收货地址
 * - 地址表通过 `address.user_id` 外键关联到用户
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "user")
@TableName("`user`")
public class User extends BaseEntity {

    /**
     * 主键：用户 id。
     */
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    /**
     * 手机号：唯一键，用于注册与登录。
     */
    @Column(name = "phone", nullable = false, unique = true, length = 20)
    private String phone;

    /**
     * 密码：建议存储 BCrypt 哈希值（而非明文）。
     */
    @Column(name = "password", nullable = false, length = 255)
    private String password;

    /**
     * 昵称：展示给好友/前端用户。
     */
    @Column(name = "nickname", length = 50)
    private String nickname;

    /**
     * 头像图片地址（URL 或 OSS 地址）。
     */
    @Column(name = "avatar", length = 255)
    private String avatar;

    /**
     * 性别：UNKNOWN/MALE/FEMALE。
     * 使用 ordinal 存储到数据库（见 {@link Gender}）。
     */
    @Enumerated(EnumType.ORDINAL)
    @Column(name = "gender", nullable = false)
    private Gender gender;

    /**
     * 生日：可用于营销/积分生日特权等（也可扩展为农历/星座等）。
     */
    @Column(name = "birth_day")
    private LocalDate birthDay;

    /**
     * 用户状态：正常或禁用。
     * 使用 ordinal 存储到数据库（见 {@link UserStatus}）。
     */
    @Enumerated(EnumType.ORDINAL)
    @Column(name = "status", nullable = false)
    private UserStatus status;

    /**
     * 用户等级：用于签到、成长值或平台会员等级。
     * 初始可为 0，后续结合“积分/成长”模块扩展。
     */
    @Column(name = "user_level", nullable = false)
    private Integer userLevel;

    /**
     * 最后登录时间：用于安全审计、展示“最近在线”等功能。
     */
    @Column(name = "last_login_time")
    private LocalDateTime lastLoginTime;

    /**
     * 地址列表：一个用户多个地址（是否默认由 address.is_default 管理）。
     */
    @OneToMany(mappedBy = "user", cascade = CascadeType.ALL, orphanRemoval = false)
    @TableField(exist = false)
    @ToString.Exclude
    private List<Address> addresses;
}

