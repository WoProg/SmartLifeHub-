package com.smartfood.entity;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

import javax.persistence.*;

/**
 * 菜品分类表实体：`category`
 *
 * Day1 目标：
 * - 每个店铺可以有多个分类
 * - 分类按 sort 排序展示
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "category")
public class Category extends BaseEntity {

    /**
     * 主键：分类 id。
     */
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    /**
     * 店铺外键关联：category.shop_id -> shop.id。
     */
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "shop_id", nullable = false)
    @ToString.Exclude
    private Shop shop;

    /**
     * 分类名称：前端展示（如：主食/饮品/热菜等）。
     */
    @Column(name = "category_name", nullable = false, length = 100)
    private String categoryName;

    /**
     * 排序字段：越小越靠前。
     */
    @Column(name = "sort", nullable = false)
    private Integer sort;
}

