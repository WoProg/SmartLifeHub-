package com.smartfood.entity;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

import javax.persistence.*;
import java.math.BigDecimal;
import java.util.List;

/**
 * 店铺表实体：`shop`
 *
 * Day1 目标：
 * - 支持根据坐标（经纬度）进行附近店铺检索
 * - 存储店铺营业状态、基础评分等信息
 * - 为后续菜品、分类、订单等模块提供外键关联
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "shop")
public class Shop extends BaseEntity {

    /**
     * 主键：店铺 id。
     */
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    /**
     * 店铺名称：用于前端展示。
     */
    @Column(name = "name", nullable = false, length = 100)
    private String name;

    /**
     * 店铺类型：用于分类筛选（如快餐、餐饮等）。
     * 使用 ordinal 存储到数据库（见 {@link ShopType}）。
     */
    @Enumerated(EnumType.ORDINAL)
    @Column(name = "shop_type", nullable = false)
    private ShopType shopType;

    /**
     * 店铺地址：用于“门店信息”展示。
     */
    @Column(name = "address", nullable = false, length = 255)
    private String address;

    /**
     * 经度：用于地理位置检索（附近店铺）。
     */
    @Column(name = "longitude", nullable = false, precision = 10, scale = 6)
    private BigDecimal longitude;

    /**
     * 纬度：用于地理位置检索（附近店铺）。
     */
    @Column(name = "latitude", nullable = false, precision = 10, scale = 6)
    private BigDecimal latitude;

    /**
     * 营业状态：OPEN/CLOSED，影响能否下单。
     */
    @Enumerated(EnumType.ORDINAL)
    @Column(name = "business_status", nullable = false)
    private ShopStatus businessStatus;

    /**
     * 店铺评分：用于热门榜/筛选展示。
     */
    @Column(name = "rating", nullable = false, precision = 3, scale = 2)
    private BigDecimal rating;

    /**
     * 配送费：用于订单金额计算。
     */
    @Column(name = "delivery_fee", nullable = false, precision = 10, scale = 2)
    private BigDecimal deliveryFee;

    /**
     * 最低起送价：用于限制订单金额。
     */
    @Column(name = "min_order_amount", nullable = false, precision = 10, scale = 2)
    private BigDecimal minOrderAmount;

    /**
     * 开始营业时间（字符串形式便于展示，比如“09:00”）。
     */
    @Column(name = "open_time", length = 10)
    private String openTime;

    /**
     * 结束营业时间（字符串形式便于展示，比如“21:30”）。
     */
    @Column(name = "close_time", length = 10)
    private String closeTime;

    /**
     * 销量统计：用于热门榜单排序。
     */
    @Column(name = "sales_count", nullable = false)
    private Integer salesCount;

    /**
     * 菜品列表：一个店铺多个菜品。
     */
    @OneToMany(mappedBy = "shop", cascade = CascadeType.ALL, orphanRemoval = false)
    @ToString.Exclude
    private List<Dish> dishes;

    /**
     * 分类列表：一个店铺多个分类。
     */
    @OneToMany(mappedBy = "shop", cascade = CascadeType.ALL, orphanRemoval = false)
    @ToString.Exclude
    private List<Category> categories;
}

