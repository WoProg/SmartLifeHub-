package com.smartfood.entity;

/**
 * 店铺类型枚举。
 *
 * 数据库存储：使用 ordinal（0/1/2...）。
 * 说明：
 * - 你可以后续扩展为更多品类（比如：餐饮/快餐/奶茶/烧烤等）
 */
public enum ShopType {
    /**
     * 未知类型
     */
    UNKNOWN(0),
    /**
     * 餐饮（综合）
     */
    RESTAURANT(1),
    /**
     * 快餐
     */
    FAST_FOOD(2);

    private final int code;

    ShopType(int code) {
        this.code = code;
    }

    public int getCode() {
        return code;
    }
}

