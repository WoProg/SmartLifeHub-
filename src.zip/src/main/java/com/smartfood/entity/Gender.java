package com.smartfood.entity;

/**
 * 性别枚举：用于用户基础信息。
 *
 * 数据库存储：使用 ordinal（0/1/2）。
 * 建议保持枚举顺序稳定，避免已有数据语义变化。
 */
public enum Gender {
    /**
     * 未知/未填写
     */
    UNKNOWN(0),
    /**
     * 男
     */
    MALE(1),
    /**
     * 女
     */
    FEMALE(2);

    private final int code;

    Gender(int code) {
        this.code = code;
    }

    public int getCode() {
        return code;
    }
}

