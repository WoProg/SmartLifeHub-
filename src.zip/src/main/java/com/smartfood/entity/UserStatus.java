package com.smartfood.entity;

/**
 * 用户状态枚举。
 *
 * 数据库存储：使用 ordinal（0/1）。
 * - 0：正常
 * - 1：禁用
 */
public enum UserStatus {
    /**
     * 正常用户
     */
    NORMAL(0),
    /**
     * 禁用用户（可用于风控/封号）
     */
    DISABLED(1);

    private final int code;

    UserStatus(int code) {
        this.code = code;
    }

    public int getCode() {
        return code;
    }
}

