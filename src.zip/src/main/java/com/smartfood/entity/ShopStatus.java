package com.smartfood.entity;

/**
 * 店铺营业状态枚举。
 *
 * 数据库存储：使用 ordinal（0/1）。
 * - 0：营业中
 * - 1：停业/休息（不可下单）
 */
public enum ShopStatus {
    /**
     * 营业中
     */
    OPEN(0),
    /**
     * 停业
     */
    CLOSED(1);

    private final int code;

    ShopStatus(int code) {
        this.code = code;
    }

    public int getCode() {
        return code;
    }
}

