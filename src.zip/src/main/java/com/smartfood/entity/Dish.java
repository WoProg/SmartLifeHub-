package com.smartfood.entity;

import com.baomidou.mybatisplus.annotation.TableField;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

import javax.persistence.*;
import java.math.BigDecimal;
import java.util.List;

/**
 * 菜品表实体：`dish`
 *
 * Day1 目标：
 * - 一个店铺多个菜品
 * - 支持多规格（通过 spec_data(JSON) + spec_type）
 * - 支持上架/下架状态
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "dish")
public class Dish extends BaseEntity {

    /**
     * 主键：菜品 id。
     */
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    /**
     * 店铺外键关联：dish.shop_id -> shop.id。
     */
    @TableField("shop_id")
    @Column(name = "shop_id", nullable = false)
    private Long shopId;

    /**
     * 店铺关系对象（JPA 导航用）。
     * 说明：MyBatis-Plus 在 Day1/Day2 的使用中以 shopId 字段为准，避免把 shop_id 映射为 Shop 对象导致查询复杂度。
     */
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "shop_id", nullable = false, insertable = false, updatable = false)
    @ToString.Exclude
    private Shop shop;

    /**
     * 菜品名称：前端展示。
     */
    @Column(name = "name", nullable = false, length = 100)
    private String name;

    /**
     * 基础价格：如果是单规格可直接使用该价格。
     */
    @Column(name = "price", nullable = false, precision = 10, scale = 2)
    private BigDecimal price;

    /**
     * 菜品主图（图片地址）。
     */
    @Column(name = "image", length = 255)
    private String image;

    /**
     * 菜品描述：用于详情页展示（可扩展为富文本）。
     */
    @Column(name = "description", columnDefinition = "TEXT")
    private String description;

    /**
     * 菜品状态：ON_SALE/OFF_SALE。
     */
    @Enumerated(EnumType.ORDINAL)
    @Column(name = "status", nullable = false)
    private DishStatus status;

    /**
     * 库存数量：用于“售罄”控制（也可以后续按规格维度扩展）。
     */
    @Column(name = "stock_quantity", nullable = false)
    private Integer stockQuantity;

    /**
     * 销量统计：用于店铺热门榜排序/推荐。
     */
    @Column(name = "sales_volume", nullable = false)
    private Integer salesVolume;

    /**
     * 规格类型：SINGLE/MULTI。
     * 当 MULTI 时，spec_data 里将存储规格选项和对应价格。
     */
    @Enumerated(EnumType.ORDINAL)
    @Column(name = "spec_type", nullable = false)
    private DishSpecType specType;

    /**
     * 规格数据 JSON：
     * - 示例：{"sizes":[{"name":"M","priceDelta":0},{"name":"L","priceDelta":2.5}]}
     * - 说明：Day1 用 String 存储，后续可结合 DTO/VO 解析为结构化对象。
     */
    @Column(name = "spec_data", columnDefinition = "json")
    private String specData;

    /**
     * 菜品标签：如“招牌/辣度/低脂/新品”等，用于筛选与推荐。
     */
    @Column(name = "tags", length = 255)
    private String tags;

    /**
     * 多规格的“真实 SKU”通常会拆到独立表（如 dish_sku）。
     * Day1 暂不建表，因此这里预留关系。
     */
    @Transient
    private List<Object> skuList;
}

