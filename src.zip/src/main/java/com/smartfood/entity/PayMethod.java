package com.smartfood.entity;

/**
 * 支付方式枚举（用于 order.pay_method）。
 *
 * 存储方式：
 * - 数据库使用 TINYINT
 * - Java 使用 ordinal 对应数据库值，因此枚举顺序必须稳定
 */
public enum PayMethod {

    /**
     * 微信 APP 支付
     */
    WECHAT_APP(0),

    /**
     * 预留：其他支付方式
     */
    OTHER(1);

    private final int code;

    PayMethod(int code) {
        this.code = code;
    }

    public int getCode() {
        return code;
    }
}

