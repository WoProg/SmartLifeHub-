package com.smartfood.entity;

/**
 * 菜品状态枚举。
 *
 * 数据库存储：使用 ordinal（0/1）。
 * - 0：上架
 * - 1：下架（不可在前端购买）
 */
public enum DishStatus {
    /**
     * 上架
     */
    ON_SALE(0),
    /**
     * 下架
     */
    OFF_SALE(1);

    private final int code;

    DishStatus(int code) {
        this.code = code;
    }

    public int getCode() {
        return code;
    }
}

