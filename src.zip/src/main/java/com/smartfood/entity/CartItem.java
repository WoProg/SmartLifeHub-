package com.smartfood.entity;

import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

import javax.persistence.*;
import java.util.List;

/**
 * 购物车明细实体：`cart`
 *
 * Day1 目标：
 * - 支持一个用户将多个菜品放入购物车
 * - 支持多规格：通过 spec_json 快照 + spec_key 去重
 * - 下单时只读取 is_selected=1 的条目
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "cart")
@TableName("cart")
public class CartItem extends BaseEntity {

    /**
     * 主键。
     */
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    /**
     * 用户 id。
     */
    @TableField("user_id")
    @Column(name = "user_id", nullable = false)
    private Long userId;

    /**
     * 菜品 id。
     */
    @TableField("dish_id")
    @Column(name = "dish_id", nullable = false)
    private Long dishId;

    /**
     * 数量。
     */
    @TableField("quantity")
    @Column(name = "quantity", nullable = false)
    private Integer quantity;

    /**
     * 规格去重键（用于保证同一用户同一 dish+规格 只出现一条）。
     */
    @TableField("spec_key")
    @Column(name = "spec_key", nullable = false, length = 64)
    private String specKey;

    /**
     * 规格快照 JSON。
     */
    @TableField("spec_json")
    @Column(name = "spec_json", columnDefinition = "json")
    private String specJson;

    /**
     * 是否选中：1-选中加入下单；0-未选中。
     */
    @TableField("is_selected")
    @Column(name = "is_selected", nullable = false)
    private Integer isSelected;

    /**
     * JPA 关系（用于对象导航；实际下单/查询可以只用 userId/dishId）
     */
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "user_id", referencedColumnName = "id", insertable = false, updatable = false)
    @ToString.Exclude
    private User user;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "dish_id", referencedColumnName = "id", insertable = false, updatable = false)
    @ToString.Exclude
    private Dish dish;
}

