package com.smartfood.entity;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

import javax.persistence.*;

/**
 * 地址表实体：`address`
 *
 * Day1 目标：
 * - 支持默认收货地址管理（address.is_default）
 * - 一个用户拥有多个收货地址
 * - 订单收货信息可从默认地址复制后固化（后续实现）
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "address")
public class Address extends BaseEntity {

    /**
     * 主键：地址 id。
     */
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    /**
     * 用户外键关联：address.user_id -> user.id。
     */
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "user_id", nullable = false)
    @ToString.Exclude
    private User user;

    /**
     * 收货人姓名。
     */
    @Column(name = "receiver", nullable = false, length = 50)
    private String receiver;

    /**
     * 收货人电话：用于配送联系。
     */
    @Column(name = "receiver_phone", nullable = false, length = 20)
    private String receiverPhone;

    /**
     * 省份。
     */
    @Column(name = "province", length = 50)
    private String province;

    /**
     * 城市。
     */
    @Column(name = "city", length = 50)
    private String city;

    /**
     * 详细地址（街道/门牌号等）。
     */
    @Column(name = "detail_address", nullable = false, length = 255)
    private String detailAddress;

    /**
     * 是否默认地址：1 表示默认，0 表示非默认。
     * SQL 层面可加唯一索引（user_id, is_default）以保证每个用户最多一个默认地址。
     */
    @Column(name = "is_default", nullable = false)
    private Integer isDefault;
}

