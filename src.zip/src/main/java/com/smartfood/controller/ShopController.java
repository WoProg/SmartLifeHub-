package com.smartfood.controller;

import com.smartfood.common.Result;
import com.smartfood.dto.ShopResponse;
import com.smartfood.dto.UpdateShopRequest;
import com.smartfood.dto.NearbyShopResponse;
import com.smartfood.geo.ShopGeoService;
import com.smartfood.service.ShopService;
import com.smartfood.exception.BizException;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;
import java.util.List;
import java.math.BigDecimal;

/**
 * 店铺接口（触发 Redis 缓存）。
 */
@Tag(name = "店铺", description = "店铺信息查询与 Redis 缓存")
@RestController
@RequestMapping("/shop")
@Validated
@RequiredArgsConstructor
public class ShopController {

    private final ShopService shopService;
    private final ShopGeoService shopGeoService;

    @Operation(summary = "获取店铺信息", description = "优先读 Redis（空对象+互斥锁+30分钟TTL），Redis 不可用则降级查库。")
    @ApiResponses({
            @ApiResponse(responseCode = "200", description = "查询成功"),
            @ApiResponse(responseCode = "400", description = "参数非法"),
            @ApiResponse(responseCode = "503", description = "Redis 异常（仅降级场景可能出现）")
    })
    @GetMapping("/{id}")
    public Result<ShopResponse> getById(
            @Parameter(description = "店铺 id", example = "1")
            @PathVariable("id") @NotNull Long id) {
        return Result.success(shopService.getById(id));
    }

    @Operation(summary = "更新店铺信息", description = "更新店铺后删除 Redis 缓存（用于缓存一致性演示）。")
    @ApiResponses({
            @ApiResponse(responseCode = "200", description = "更新成功"),
            @ApiResponse(responseCode = "400", description = "参数非法"),
            @ApiResponse(responseCode = "404", description = "店铺不存在")
    })
    @PutMapping("/{id}")
    public Result<Void> updateShop(
            @Parameter(description = "店铺 id", example = "1")
            @PathVariable("id") @NotNull Long id,
            @Valid @RequestBody UpdateShopRequest request) {
        shopService.updateShop(id, request);
        return Result.success();
    }

    @Operation(summary = "附近店铺搜索", description = "基于 Redis GEO：距离排序返回，并支持分页（服务端切片）。")
    @ApiResponses({
            @ApiResponse(responseCode = "200", description = "查询成功"),
            @ApiResponse(responseCode = "400", description = "参数非法")
    })
    @GetMapping("/nearby")
    public Result<List<NearbyShopResponse>> nearby(
            @RequestParam("longitude") @NotNull BigDecimal longitude,
            @RequestParam("latitude") @NotNull BigDecimal latitude,
            @RequestParam(name = "radiusKm", defaultValue = "5") double radiusKm,
            @RequestParam(name = "page", defaultValue = "1") int page,
            @RequestParam(name = "size", defaultValue = "10") int size) {
        if (page <= 0 || size <= 0) {
            throw new BizException(400, "page/size 非法");
        }
        if (radiusKm <= 0) {
            throw new BizException(400, "radiusKm 必须大于 0");
        }

        int fromIndex = (page - 1) * size;
        int toIndex = fromIndex + size;

        // GEO radius 不易天然 offset，这里取到 toIndex 再切片
        List<NearbyShopResponse> all = shopGeoService.searchNearby(longitude, latitude, radiusKm, toIndex);
        if (all == null || all.isEmpty()) {
            return Result.success(List.of());
        }

        int safeFrom = Math.min(fromIndex, all.size());
        int safeTo = Math.min(toIndex, all.size());
        List<NearbyShopResponse> pageList = all.subList(safeFrom, safeTo);

        // 补齐店铺详情（命中 Shop 缓存/Redis），减少回源 DB 的概率
        for (NearbyShopResponse item : pageList) {
            if (item.getShopId() != null) {
                item.setShop(shopService.getById(item.getShopId()));
            }
        }

        return Result.success(pageList);
    }
}

