package com.smartfood.controller;

import com.smartfood.common.Result;
import com.smartfood.dto.WechatAppPrepayResponse;
import com.smartfood.pay.wechat.WechatAppPayService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

/**
 * 微信支付：APP 统一下单接口。
 */
@Slf4j
@Tag(name = "微信支付", description = "微信支付 v3（APP trade type）")
@RestController
@RequestMapping("/pay/wechat/app")
@Validated
@RequiredArgsConstructor
public class WechatAppPayController {

    private final WechatAppPayService wechatAppPayService;

    @Operation(summary = "APP 统一下单（prepay）", description = "为指定订单生成微信支付 prepay 参数（mock/real 模式均支持）。")
    @PostMapping("/prepay/{orderNo}")
    public Result<WechatAppPrepayResponse> unifiedOrder(
            @Parameter(description = "订单号（雪花生成，建议直接使用 long）", example = "1217752501201407033233368018")
            @PathVariable("orderNo") Long orderNo) {
        WechatAppPrepayResponse response = wechatAppPayService.unifiedOrderApp(orderNo);
        return Result.success(response);
    }
}

