package com.smartfood.controller;

import com.smartfood.common.Result;
import com.smartfood.exception.BizException;
import com.smartfood.seckill.CouponSeckillResult;
import com.smartfood.seckill.CouponSeckillService;
import com.smartfood.seckill.PreloadStockRequest;
import com.smartfood.security.session.RedisLoginSessionService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;

/**
 * 优惠券秒杀接口（Redis Lua 原子扣减 + 异步 Worker 入库）。
 *
 * 说明：
 * - 本 Milestone 先把 Redis/异步骨架落地，DB 入库需要你补齐 coupon_order 表结构与字段映射。
 */
@Tag(name = "优惠券秒杀", description = "Redis Lua 原子秒杀 + 异步结果查询")
@RestController
@RequestMapping("/coupon/seckill")
@Validated
@RequiredArgsConstructor
public class CouponSeckillController {

    private final CouponSeckillService couponSeckillService;
    private final RedisLoginSessionService redisLoginSessionService;

    @Operation(summary = "秒杀库存预热", description = "演示用：直接把 stock 写入 Redis。真实场景应从数据库活动配置预热。")
    @ApiResponses({
            @ApiResponse(responseCode = "200", description = "预热成功"),
            @ApiResponse(responseCode = "400", description = "参数非法")
    })
    @PostMapping("/preload/{couponId}")
    public Result<Void> preload(
            @PathVariable("couponId") @NotNull Long couponId,
            @Valid @RequestBody PreloadStockRequest request) {
        couponSeckillService.preloadStock(couponId, request.getStock());
        return Result.success();
    }

    @Operation(summary = "执行秒杀", description = "Lua 原子扣减库存 + 一人一券；成功后返回 PROCESSING，结果由 Worker 异步回写。")
    @ApiResponses({
            @ApiResponse(responseCode = "200", description = "已受理"),
            @ApiResponse(responseCode = "401", description = "缺少/非法 token（Redis session 校验失败）"),
            @ApiResponse(responseCode = "409", description = "库存不足或重复秒杀")
    })
    @PostMapping("/{couponId}")
    public Result<CouponSeckillResult> seckill(
            @PathVariable("couponId") @NotNull Long couponId,
            @RequestHeader("Authorization") String authorization) {
        // 错误码由 BizException 统一处理；这里只负责透传
        return Result.success(couponSeckillService.seckill(couponId, authorization));
    }

    @Operation(summary = "查询秒杀结果", description = "轮询该接口获取异步结果（SUCCESS/FAIL）。")
    @ApiResponses({
            @ApiResponse(responseCode = "200", description = "查询成功"),
            @ApiResponse(responseCode = "401", description = "缺少/非法 token")
    })
    @GetMapping("/result/{couponId}")
    public Result<CouponSeckillResult> result(
            @PathVariable("couponId") @NotNull Long couponId,
            @RequestHeader("Authorization") String authorization) {
        String token = authorization == null ? null : authorization.trim();
        if (token == null || token.isEmpty()) {
            throw new BizException(401, "缺少 Authorization header");
        }
        if (token.toLowerCase().startsWith("bearer ")) {
            token = token.substring(7).trim();
        }

        Long userId = redisLoginSessionService.requireSession(token).getId();
        CouponSeckillResult r = couponSeckillService.getResult(couponId, userId);
        return Result.success(r);
    }
}

