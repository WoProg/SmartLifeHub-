package com.smartfood.controller;

import com.smartfood.common.Result;
import com.smartfood.dto.IntegralRankResponse;
import com.smartfood.dto.SignMonthResponse;
import com.smartfood.dto.SignResponse;
import com.smartfood.exception.BizException;
import com.smartfood.service.SignService;
import com.smartfood.security.session.RedisLoginSessionService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import javax.validation.constraints.NotNull;

/**
 * 签到与积分（Redis）接口。
 */
@Tag(name = "签到积分", description = "签到、积分与排行榜")
@Validated
@RestController
@RequiredArgsConstructor
public class SignController {

    private final SignService signService;
    private final RedisLoginSessionService redisLoginSessionService;

    @Operation(summary = "每日签到", description = "签到并发放积分（第一天1分，连续递增）。")
    @PostMapping("/user/sign")
    public Result<SignResponse> sign(
            @RequestHeader("Authorization") String authorization) {
        Long userId = currentUserId(authorization);
        SignResponse r = signService.sign(userId);
        return Result.success(r);
    }

    @Operation(summary = "本月签到情况", description = "返回本月已签到日期与连续签到天数。")
    @GetMapping("/user/sign")
    public Result<SignMonthResponse> signMonth(
            @RequestHeader("Authorization") String authorization) {
        Long userId = currentUserId(authorization);
        return Result.success(signService.getMonthSign(userId));
    }

    @Operation(summary = "积分排行榜", description = "按积分从高到低返回用户排行榜。")
    @GetMapping("/integral/rank")
    public Result<IntegralRankResponse> integralRank(
            @RequestParam(name = "limit", defaultValue = "10") @NotNull Integer limit) {
        return Result.success(signService.getIntegralRank(limit));
    }

    private Long currentUserId(String authorization) {
        if (authorization == null || authorization.trim().isEmpty()) {
            throw new BizException(401, "缺少 Authorization header");
        }
        String token = authorization.trim();
        if (token.toLowerCase().startsWith("bearer ")) {
            token = token.substring(7).trim();
        }
        return redisLoginSessionService.requireSession(token).getId();
    }
}

