package com.smartfood.controller;

import com.smartfood.common.Result;
import com.smartfood.entity.Notice;
import com.smartfood.entity.ReportRecord;
import com.smartfood.entity.Review;
import com.smartfood.exception.BizException;
import com.smartfood.mapper.NoticeMapper;
import com.smartfood.mapper.ReportRecordMapper;
import com.smartfood.mapper.ReviewMapper;
import com.smartfood.security.JwtUtil;
import com.smartfood.security.session.RedisLoginSessionService;
import io.jsonwebtoken.Claims;
import lombok.Data;
import lombok.RequiredArgsConstructor;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Locale;

@RestController
@RequestMapping("/admin/ops")
@RequiredArgsConstructor
public class AdminOpsController {
    private final RedisLoginSessionService redisLoginSessionService;
    private final JwtUtil jwtUtil;
    private final ReviewMapper reviewMapper;
    private final ReportRecordMapper reportRecordMapper;
    private final NoticeMapper noticeMapper;

    @GetMapping("/reviews/pending")
    public Result<List<Review>> pendingReviews(@RequestHeader("Authorization") String authorization,
                                               @RequestParam(name = "limit", defaultValue = "100") Integer limit) {
        requireAdmin(authorization);
        return Result.success(reviewMapper.listByStatus(0, Math.max(1, Math.min(limit, 500))));
    }

    @PostMapping("/reviews/{id}/approve")
    public Result<Void> approveReview(@RequestHeader("Authorization") String authorization, @PathVariable("id") Long id) {
        requireAdmin(authorization);
        reviewMapper.updateStatus(id, 1);
        return Result.success();
    }

    @PostMapping("/reviews/{id}/reject")
    public Result<Void> rejectReview(@RequestHeader("Authorization") String authorization, @PathVariable("id") Long id) {
        requireAdmin(authorization);
        reviewMapper.updateStatus(id, 2);
        return Result.success();
    }

    @GetMapping("/reports/pending")
    public Result<List<ReportRecord>> pendingReports(@RequestHeader("Authorization") String authorization,
                                                     @RequestParam(name = "limit", defaultValue = "100") Integer limit) {
        requireAdmin(authorization);
        return Result.success(reportRecordMapper.listByStatus(0, Math.max(1, Math.min(limit, 500))));
    }

    @PostMapping("/reports/{id}/resolve")
    public Result<Void> resolveReport(@RequestHeader("Authorization") String authorization, @PathVariable("id") Long id) {
        requireAdmin(authorization);
        reportRecordMapper.updateStatus(id, 1);
        return Result.success();
    }

    @PostMapping("/notices")
    public Result<Long> createNotice(@RequestHeader("Authorization") String authorization, @RequestBody NoticeCreateRequest request) {
        requireAdmin(authorization);
        if (request == null || !StringUtils.hasText(request.title) || !StringUtils.hasText(request.content) || !StringUtils.hasText(request.type)) {
            throw new BizException(400, "参数非法");
        }
        Notice notice = Notice.builder()
                .title(request.title.trim())
                .content(request.content.trim())
                .type(request.type.toUpperCase(Locale.ROOT))
                .enabled(request.enabled != null && request.enabled ? 1 : 0)
                .build();
        notice.setCreateTime(LocalDateTime.now());
        notice.setUpdateTime(LocalDateTime.now());
        noticeMapper.insert(notice);
        return Result.success(notice.getId());
    }

    @GetMapping("/notices")
    public Result<List<Notice>> listNotices(@RequestParam(name = "type", defaultValue = "NOTICE") String type) {
        return Result.success(noticeMapper.listEnabledByType(type.toUpperCase(Locale.ROOT), 20));
    }

    private void requireAdmin(String authorization) {
        if (!StringUtils.hasText(authorization)) throw new BizException(401, "缺少 Authorization header");
        String token = authorization.trim();
        if (token.toLowerCase(Locale.ROOT).startsWith("bearer ")) token = token.substring(7).trim();
        redisLoginSessionService.requireSession(token);
        Claims claims = jwtUtil.parseClaims(token);
        String role = claims.get("role", String.class);
        if (!"ADMIN".equalsIgnoreCase(role)) throw new BizException(403, "角色无权限");
    }

    @Data
    public static class NoticeCreateRequest {
        public String title;
        public String content;
        public String type;
        public Boolean enabled;
    }
}
