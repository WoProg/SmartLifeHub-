package com.smartfood.controller;

import com.smartfood.common.Result;
import com.smartfood.dto.*;
import com.smartfood.service.UserService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.tags.Tag;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import lombok.RequiredArgsConstructor;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;

/**
 * 用户 Controller：提供注册、登录、查询、更新、退出登录接口。
 *
 * Day1 目标：保证“注册登录流程”可以用 Postman 逐个调用并返回可用的响应结构。
 */
@Tag(name = "用户模块", description = "注册登录、用户信息管理、退出登录")
@RestController
@RequestMapping("/user")
@Validated
@RequiredArgsConstructor
public class UserController {

    private final UserService userService;

    /**
     * 用户注册。
     *
     * @param request 注册请求
     * @return 新用户信息（脱敏）
     */
    @Operation(summary = "用户注册", description = "根据手机号+密码+昵称完成注册，返回用户信息（不返回密码）。")
    @ApiResponses({
            @ApiResponse(responseCode = "200", description = "注册成功"),
            @ApiResponse(responseCode = "409", description = "手机号已注册"),
            @ApiResponse(responseCode = "400", description = "参数校验失败")
    })
    @PostMapping("/register")
    public Result<UserResponse> register(@Valid @RequestBody RegisterRequest request) {
        return Result.success(userService.register(request));
    }

    /**
     * 用户登录（手机号+密码）。
     *
     * @param request 登录请求参数
     * @return token + 用户信息
     */
    @Operation(summary = "用户登录", description = "手机号密码登录成功后签发 JWT token，并返回用户信息。")
    @PostMapping("/login")
    public Result<LoginResponse> login(@Valid @RequestBody LoginRequest request) {
        return Result.success(userService.login(request));
    }

    /**
     * 短信验证码发送。
     */
    @Operation(summary = "短信验证码发送", description = "根据手机号请求发送 6 位验证码（Redis 防轰炸/限错）。")
    @PostMapping("/sms/send")
    public Result<Void> sendSmsCode(@Valid @RequestBody SmsSendCodeRequest request) {
        userService.sendSmsCode(request.getPhone());
        return Result.success();
    }

    /**
     * 短信验证码登录。
     */
    @Operation(summary = "短信验证码登录", description = "提交手机号+验证码，校验通过后签发 token 并写入 Redis 会话。")
    @PostMapping("/sms/login")
    public Result<LoginResponse> loginBySmsCode(@Valid @RequestBody SmsLoginRequest request) {
        return Result.success(userService.loginBySmsCode(request));
    }

    /**
     * 获取用户信息。
     *
     * @param id 用户 id
     * @return 用户信息（脱敏）
     */
    @Operation(summary = "获取用户信息", description = "通过用户 id 获取用户信息（不返回密码）。")
    @GetMapping("/{id}")
    public Result<UserResponse> getById(
            @Parameter(description = "用户 id", example = "1")
            @PathVariable("id") Long id) {
        return Result.success(userService.getById(id));
    }

    /**
     * 更新用户信息（不支持修改手机号/密码）。
     *
     * @param request 更新参数
     * @return 更新后的用户信息（脱敏）
     */
    @Operation(summary = "更新用户信息", description = "更新昵称、头像、性别、生日等非敏感信息。")
    @PutMapping("/update")
    public Result<UserResponse> updateUser(@Valid @RequestBody UpdateUserRequest request) {
        return Result.success(userService.updateUser(request));
    }

    /**
     * 用户退出登录。
     *
     * Day1 说明：
     * - 这里会校验 token 是否有效
     * - 暂不做“真正失效”处理（后续接入 Redis 黑名单 + 鉴权过滤器）
     *
     * @param request 退出登录请求，携带 token
     * @return 退出成功结果
     */
    @Operation(summary = "退出登录", description = "校验 token 有效性并返回退出成功。")
    @PostMapping("/logout")
    public Result<Void> logout(@Valid @RequestBody LogoutRequest request) {
        userService.logout(request.getToken());
        return Result.success();
    }
}

