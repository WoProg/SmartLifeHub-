package com.smartfood.controller;

import com.smartfood.common.Result;
import com.smartfood.config.properties.WxPayProperties;
import com.smartfood.exception.BizException;
import com.smartfood.pay.wechat.WechatPayNotifyService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.*;

/**
 * mock 支付接口：用于联调 Payment -> 回调通知 -> 幂等与状态同步。
 *
 * 使用方式（mock 模式下）：
 * - `POST /pay/mock/{orderNo}?result=success&transactionId=xxx`
 * - `POST /pay/mock/{orderNo}?result=fail&transactionId=xxx`
 *
 * transactionId 用于幂等测试：相同 transactionId 重复调用应无二次更新。
 */
@Slf4j
@Tag(name = "支付 Mock", description = "仅用于 app.wxpay.mode=mock 的支付回调模拟")
@RestController
@RequestMapping("/pay/mock")
@RequiredArgsConstructor
public class WechatPayMockController {

    private final WxPayProperties wxPayProperties;
    private final WechatPayNotifyService notifyService;

    @Operation(summary = "mock 支付成功/失败（触发回调逻辑）", description = "调用后会走同一套回调幂等/订单状态同步逻辑。")
    @PostMapping("/{orderNo}")
    public Result<Void> mockPay(
            @PathVariable("orderNo") Long orderNo,
            @RequestParam("result") String result,
            @RequestParam(value = "transactionId", required = false)
            @Parameter(description = "用于幂等测试：同一个 transactionId 重复调用不应重复写入/更新")
                    String transactionId
    ) {
        String mode = wxPayProperties.getMode();
        if (mode == null || !"mock".equalsIgnoreCase(mode)) {
            throw new BizException(400, "当前 wxpay.mode 不是 mock，不能使用 mock 支付接口");
        }
        if (orderNo == null || orderNo <= 0) {
            throw new BizException(400, "orderNo 非法");
        }

        String tradeState;
        if ("success".equalsIgnoreCase(result)) {
            tradeState = "SUCCESS";
        } else if ("fail".equalsIgnoreCase(result) || "failed".equalsIgnoreCase(result)) {
            tradeState = "FAIL";
        } else {
            throw new BizException(400, "result 只允许 success|fail");
        }

        if (transactionId == null || transactionId.isBlank()) {
            transactionId = "mock_tx_" + orderNo + "_" + System.currentTimeMillis();
        }

        String rawBody = "{\"orderNo\":" + orderNo + ",\"tradeState\":\"" + tradeState + "\",\"transactionId\":\"" + transactionId + "\"}";
        notifyService.handleNotification(orderNo, tradeState, transactionId, rawBody);
        return Result.success();
    }
}

