package com.smartfood.controller;

import com.smartfood.common.Result;
import com.smartfood.dto.echarts.EChartsDataResponse;
import com.smartfood.dto.stats.ShopRatingDistributionResponse;
import com.smartfood.dto.stats.TopDishResponse;
import com.smartfood.statistics.StatisticsRange;
import com.smartfood.service.StatisticsService;
import com.smartfood.security.session.RedisLoginSessionService;
import com.smartfood.exception.BizException;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import javax.validation.constraints.NotNull;
import java.util.Locale;

/**
 * 后台数据统计报表接口：
 * - 营业额统计
 * - 用户统计
 * - 订单统计
 * - 热门菜品 TOP10
 * - 店铺评分分布
 */
@Tag(name = "数据统计", description = "营业额/用户/订单/热门菜品/店铺评分分布统计")
@RestController
@RequestMapping("/stats")
@Validated
@RequiredArgsConstructor
public class StatisticsController {

    private final StatisticsService statisticsService;
    private final RedisLoginSessionService redisLoginSessionService;

    private static void requireAuth(String authorization) {
        if (authorization == null || authorization.trim().isEmpty()) {
            throw new BizException(401, "缺少 Authorization header");
        }
    }

    private static String normalizeToken(String authorization) {
        String token = authorization.trim();
        if (token.toLowerCase().startsWith("bearer ")) {
            return token.substring(7).trim();
        }
        return token;
    }

    private StatisticsRange parseRange(String range) {
        if (range == null || range.isBlank()) {
            throw new BizException(400, "range不能为空");
        }
        String r = range.trim().toLowerCase(Locale.ROOT);
        switch (r) {
            case "today":
            case "day":
                return StatisticsRange.TODAY;
            case "week":
                return StatisticsRange.WEEK;
            case "month":
                return StatisticsRange.MONTH;
            case "year":
                return StatisticsRange.YEAR;
            default:
                throw new BizException(400, "range不合法，可选：today|week|month|year");
        }
    }

    /**
     * 营业额统计（ECharts 图表）。
     */
    @Operation(summary = "营业额统计", description = "返回 ECharts xAxis/series 数据结构。")
    @ApiResponses({
            @ApiResponse(responseCode = "200", description = "查询成功"),
            @ApiResponse(responseCode = "401", description = "token无效")
    })
    @GetMapping("/revenue")
    public Result<EChartsDataResponse> revenue(
            @RequestParam(name = "range", defaultValue = "today") String range,
            @RequestHeader("Authorization") String authorization) {
        requireAuth(authorization);
        String token = normalizeToken(authorization);
        // token有效即放行（Redis session 会续期）
        redisLoginSessionService.requireSession(token);

        return Result.success(statisticsService.getRevenueECharts(parseRange(range)));
    }

    /**
     * 用户统计（ECharts 图表）。
     */
    @Operation(summary = "用户统计", description = "新增用户/活跃用户（ECharts 图表）。")
    @ApiResponses({
            @ApiResponse(responseCode = "200", description = "查询成功"),
            @ApiResponse(responseCode = "401", description = "token无效")
    })
    @GetMapping("/users")
    public Result<EChartsDataResponse> users(
            @RequestParam(name = "range", defaultValue = "today") String range,
            @RequestHeader("Authorization") String authorization) {
        requireAuth(authorization);
        String token = normalizeToken(authorization);
        redisLoginSessionService.requireSession(token);

        return Result.success(statisticsService.getUsersECharts(parseRange(range)));
    }

    /**
     * 订单统计（ECharts 图表）。
     */
    @Operation(summary = "订单统计", description = "订单量/完成率/平均客单价（ECharts 图表）。")
    @ApiResponses({
            @ApiResponse(responseCode = "200", description = "查询成功"),
            @ApiResponse(responseCode = "401", description = "token无效")
    })
    @GetMapping("/orders")
    public Result<EChartsDataResponse> orders(
            @RequestParam(name = "range", defaultValue = "today") String range,
            @RequestHeader("Authorization") String authorization) {
        requireAuth(authorization);
        String token = normalizeToken(authorization);
        redisLoginSessionService.requireSession(token);

        return Result.success(statisticsService.getOrdersECharts(parseRange(range)));
    }

    /**
     * 热门菜品 TOP10。
     */
    @Operation(summary = "热门菜品 TOP10", description = "返回 TOP10 明细 + ECharts 图表。")
    @ApiResponses({
            @ApiResponse(responseCode = "200", description = "查询成功"),
            @ApiResponse(responseCode = "401", description = "token无效")
    })
    @GetMapping("/top-dishes")
    public Result<TopDishResponse> topDishes(
            @RequestParam(name = "range", defaultValue = "today") String range,
            @RequestHeader("Authorization") String authorization) {
        requireAuth(authorization);
        String token = normalizeToken(authorization);
        redisLoginSessionService.requireSession(token);

        return Result.success(statisticsService.getTopDishes(parseRange(range)));
    }

    /**
     * 店铺评分分布。
     */
    @Operation(summary = "店铺评分分布", description = "返回评分桶分布（ECharts 图表）。")
    @ApiResponses({
            @ApiResponse(responseCode = "200", description = "查询成功"),
            @ApiResponse(responseCode = "401", description = "token无效")
    })
    @GetMapping("/shop-rating-distribution")
    public Result<ShopRatingDistributionResponse> shopRatingDistribution(
            @RequestParam(name = "range", defaultValue = "today") String range,
            @RequestHeader("Authorization") String authorization) {
        requireAuth(authorization);
        String token = normalizeToken(authorization);
        redisLoginSessionService.requireSession(token);

        return Result.success(statisticsService.getShopRatingDistribution(parseRange(range)));
    }
}

