package com.smartfood.controller;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.smartfood.common.Result;
import com.smartfood.entity.Dish;
import com.smartfood.entity.DishStatus;
import com.smartfood.entity.Shop;
import com.smartfood.exception.BizException;
import com.smartfood.mapper.DishMapper;
import com.smartfood.mapper.ShopMapper;
import com.smartfood.security.JwtUtil;
import com.smartfood.security.session.RedisLoginSessionService;
import io.jsonwebtoken.Claims;
import lombok.Data;
import lombok.RequiredArgsConstructor;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Locale;

@RestController
@RequestMapping("/merchant")
@RequiredArgsConstructor
public class MerchantPortalController {
    private final RedisLoginSessionService redisLoginSessionService;
    private final JwtUtil jwtUtil;
    private final DishMapper dishMapper;
    private final ShopMapper shopMapper;

    @GetMapping("/shop")
    public Result<Shop> currentShop(@RequestHeader("Authorization") String authorization) {
        Long shopId = currentMerchantShopId(authorization);
        Shop shop = shopMapper.selectById(shopId);
        if (shop == null) throw new BizException(404, "店铺不存在");
        return Result.success(shop);
    }

    @PutMapping("/shop")
    public Result<Void> updateShop(@RequestHeader("Authorization") String authorization, @RequestBody Shop request) {
        Long shopId = currentMerchantShopId(authorization);
        Shop shop = shopMapper.selectById(shopId);
        if (shop == null) throw new BizException(404, "店铺不存在");
        if (StringUtils.hasText(request.getName())) shop.setName(request.getName());
        if (StringUtils.hasText(request.getAddress())) shop.setAddress(request.getAddress());
        if (request.getBusinessStatus() != null) shop.setBusinessStatus(request.getBusinessStatus());
        if (request.getDeliveryFee() != null) shop.setDeliveryFee(request.getDeliveryFee());
        if (request.getMinOrderAmount() != null) shop.setMinOrderAmount(request.getMinOrderAmount());
        if (StringUtils.hasText(request.getOpenTime())) shop.setOpenTime(request.getOpenTime());
        if (StringUtils.hasText(request.getCloseTime())) shop.setCloseTime(request.getCloseTime());
        shop.setUpdateTime(LocalDateTime.now());
        shopMapper.updateById(shop);
        return Result.success();
    }

    @GetMapping("/dishes")
    public Result<List<Dish>> listDishes(@RequestHeader("Authorization") String authorization) {
        Long shopId = currentMerchantShopId(authorization);
        QueryWrapper<Dish> qw = new QueryWrapper<Dish>().eq("shop_id", shopId).orderByDesc("sales_volume").orderByDesc("id");
        return Result.success(dishMapper.selectList(qw));
    }

    @PostMapping("/dishes")
    public Result<Long> createDish(@RequestHeader("Authorization") String authorization, @RequestBody Dish request) {
        Long shopId = currentMerchantShopId(authorization);
        if (!StringUtils.hasText(request.getName()) || request.getPrice() == null || request.getStockQuantity() == null) {
            throw new BizException(400, "参数非法");
        }
        Dish dish = Dish.builder()
                .shopId(shopId)
                .name(request.getName())
                .price(request.getPrice())
                .image(request.getImage())
                .description(request.getDescription())
                .status(request.getStatus() == null ? DishStatus.ON_SALE : request.getStatus())
                .stockQuantity(request.getStockQuantity())
                .salesVolume(request.getSalesVolume() == null ? 0 : request.getSalesVolume())
                .specType(request.getSpecType())
                .specData(request.getSpecData())
                .tags(request.getTags())
                .build();
        dish.setCreateTime(LocalDateTime.now());
        dish.setUpdateTime(LocalDateTime.now());
        dishMapper.insert(dish);
        return Result.success(dish.getId());
    }

    @PutMapping("/dishes/{id}")
    public Result<Void> updateDish(@RequestHeader("Authorization") String authorization,
                                   @PathVariable("id") Long id,
                                   @RequestBody Dish request) {
        Long shopId = currentMerchantShopId(authorization);
        Dish dish = dishMapper.selectById(id);
        if (dish == null || !shopId.equals(dish.getShopId())) throw new BizException(404, "菜品不存在");
        if (StringUtils.hasText(request.getName())) dish.setName(request.getName());
        if (request.getPrice() != null) dish.setPrice(request.getPrice());
        if (request.getStockQuantity() != null) dish.setStockQuantity(request.getStockQuantity());
        if (request.getStatus() != null) dish.setStatus(request.getStatus());
        if (request.getImage() != null) dish.setImage(request.getImage());
        if (request.getDescription() != null) dish.setDescription(request.getDescription());
        if (request.getSpecType() != null) dish.setSpecType(request.getSpecType());
        if (request.getSpecData() != null) dish.setSpecData(request.getSpecData());
        if (request.getTags() != null) dish.setTags(request.getTags());
        dish.setUpdateTime(LocalDateTime.now());
        dishMapper.updateById(dish);
        return Result.success();
    }

    @DeleteMapping("/dishes/{id}")
    public Result<Void> deleteDish(@RequestHeader("Authorization") String authorization,
                                   @PathVariable("id") Long id) {
        Long shopId = currentMerchantShopId(authorization);
        Dish dish = dishMapper.selectById(id);
        if (dish == null || !shopId.equals(dish.getShopId())) throw new BizException(404, "菜品不存在");
        dishMapper.deleteById(id);
        return Result.success();
    }

    private Long currentMerchantShopId(String authorization) {
        if (!StringUtils.hasText(authorization)) throw new BizException(401, "缺少 Authorization header");
        String token = authorization.trim();
        if (token.toLowerCase(Locale.ROOT).startsWith("bearer ")) token = token.substring(7).trim();
        redisLoginSessionService.requireSession(token);
        Claims claims = jwtUtil.parseClaims(token);
        String role = claims.get("role", String.class);
        if (!"MERCHANT".equalsIgnoreCase(role)) throw new BizException(403, "角色无权限");
        Object operatorId = claims.get("operatorId");
        if (operatorId instanceof Number) return ((Number) operatorId).longValue();
        return Long.parseLong(claims.getSubject());
    }
}
