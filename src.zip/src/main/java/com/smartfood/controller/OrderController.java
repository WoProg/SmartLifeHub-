package com.smartfood.controller;

import com.smartfood.common.Result;
import com.smartfood.exception.BizException;
import com.smartfood.service.OrderService;
import com.smartfood.security.session.RedisLoginSessionService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

/**
 * 订单入口控制器。
 *
 * Day1：
 * - `POST /order/create`：从购物车选中项生成订单（雪花单号+Redis锁+事务一致性+库存扣减+清空购物车+写延迟取消队列）
 */
@Slf4j
@Tag(name = "订单", description = "订单创建与基础查询")
@RestController
@RequestMapping("/order")
@Validated
@RequiredArgsConstructor
public class OrderController {

    private final OrderService orderService;
    private final RedisLoginSessionService redisLoginSessionService;

    @Operation(summary = "创建订单", description = "读取用户购物车选中项，生成 order_no 并写入 Redis 延迟取消队列。")
    @ApiResponses({
            @ApiResponse(responseCode = "200", description = "创建成功"),
            @ApiResponse(responseCode = "401", description = "缺少/非法 token"),
            @ApiResponse(responseCode = "409", description = "订单状态/库存冲突")
    })
    @PostMapping("/create")
    public Result<Long> createOrder(
            @RequestHeader("Authorization") String authorization) {
        if (authorization == null || authorization.trim().isEmpty()) {
            throw new BizException(401, "缺少 Authorization header");
        }

        String token = authorization.trim();
        if (token.toLowerCase().startsWith("bearer ")) {
            token = token.substring(7).trim();
        }

        // Redis 分布式 Session 校验 + 滑动续期
        long userId = redisLoginSessionService.requireSession(token).getId();
        long orderNo = orderService.createOrderFromCart(userId);
        return Result.success(orderNo);
    }
}

