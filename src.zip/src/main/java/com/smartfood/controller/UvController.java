package com.smartfood.controller;

import com.smartfood.common.Result;
import com.smartfood.dto.uv.UvNewOldResponse;
import com.smartfood.exception.BizException;
import com.smartfood.security.session.RedisLoginSessionService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.data.redis.core.HyperLogLogOperations;
import org.springframework.web.bind.annotation.*;

import javax.validation.constraints.NotNull;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

/**
 * UV 统计接口（HyperLogLog）。
 */
@Slf4j
@Tag(name = "UV统计", description = "基于Redis HyperLogLog的UV统计")
@RestController
@RequestMapping("/stats/uv")
@RequiredArgsConstructor
public class UvController {

    private static final DateTimeFormatter DAY_FMT = DateTimeFormatter.ofPattern("yyyyMMdd");
    private static final int DEFAULT_LIMIT_DAYS = 31;

    private final StringRedisTemplate stringRedisTemplate;
    private final RedisLoginSessionService redisLoginSessionService;

    private void requireAuth(String authorization) {
        if (authorization == null || authorization.trim().isEmpty()) {
            throw new BizException(401, "缺少 Authorization header");
        }
        String token = normalizeToken(authorization);
        redisLoginSessionService.requireSession(token);
    }

    private String normalizeToken(String authorization) {
        String token = authorization.trim();
        if (token.toLowerCase().startsWith("bearer ")) {
            return token.substring(7).trim();
        }
        return token;
    }

    @Operation(summary = "查询每日UV")
    @GetMapping("/daily/{yyyyMMdd}")
    public Result<Long> daily(
            @PathVariable("yyyyMMdd") @NotNull String yyyyMMdd,
            @RequestHeader("Authorization") String authorization) {
        requireAuth(authorization);
        HyperLogLogOperations<String, String> ops = stringRedisTemplate.opsForHyperLogLog();

        String key = uvKey(yyyyMMdd);
        Long cnt = ops.size(key);
        return Result.success(cnt == null ? 0L : cnt);
    }

    @Operation(summary = "按页面查询每日UV")
    @GetMapping("/daily/{yyyyMMdd}/page/{page}")
    public Result<Long> dailyByPage(
            @PathVariable("yyyyMMdd") @NotNull String yyyyMMdd,
            @PathVariable("page") @NotNull String page,
            @RequestHeader("Authorization") String authorization) {
        requireAuth(authorization);
        HyperLogLogOperations<String, String> ops = stringRedisTemplate.opsForHyperLogLog();

        String key = uvKey(yyyyMMdd) + ":page:" + page;
        Long cnt = ops.size(key);
        return Result.success(cnt == null ? 0L : cnt);
    }

    @Operation(summary = "查询每日新老UV")
    @GetMapping("/daily/{yyyyMMdd}/new-old")
    public Result<UvNewOldResponse> newOld(
            @PathVariable("yyyyMMdd") @NotNull String yyyyMMdd,
            @RequestHeader("Authorization") String authorization) {
        requireAuth(authorization);
        HyperLogLogOperations<String, String> ops = stringRedisTemplate.opsForHyperLogLog();

        String baseKey = uvKey(yyyyMMdd);
        Long newUv = ops.size(baseKey + ":new");
        Long oldUv = ops.size(baseKey + ":old");

        return Result.success(UvNewOldResponse.builder()
                .newUv(newUv == null ? 0L : newUv)
                .oldUv(oldUv == null ? 0L : oldUv)
                .build());
    }

    @Operation(summary = "合并多日UV")
    @GetMapping("/merge")
    public Result<Long> merge(
            @RequestParam("from") String from,
            @RequestParam("to") String to,
            @RequestHeader("Authorization") String authorization) {
        requireAuth(authorization);

        LocalDate fromDate = LocalDate.parse(from, DAY_FMT);
        LocalDate toDate = LocalDate.parse(to, DAY_FMT);
        if (toDate.isBefore(fromDate)) {
            throw new BizException(400, "`to` must be >= `from`");
        }
        long days = toDate.toEpochDay() - fromDate.toEpochDay() + 1;
        if (days > DEFAULT_LIMIT_DAYS) {
            throw new BizException(400, "合并区间过大，最多支持 " + DEFAULT_LIMIT_DAYS + " 天");
        }

        List<String> sourceKeys = new ArrayList<>();
        LocalDate d = fromDate;
        while (!d.isAfter(toDate)) {
            sourceKeys.add(uvKey(d.format(DAY_FMT)));
            d = d.plusDays(1);
        }

        String destKey = "uv:merge:" + from + ":" + to;
        HyperLogLogOperations<String, String> ops = stringRedisTemplate.opsForHyperLogLog();
        ops.union(destKey, sourceKeys.toArray(new String[0]));
        Long cnt = ops.size(destKey);

        // TTL 7 days
        try {
            stringRedisTemplate.expire(destKey, java.time.Duration.ofDays(7));
        } catch (Exception ignored) {
        }

        return Result.success(cnt == null ? 0L : cnt);
    }

    private String uvKey(String yyyyMMdd) {
        return "uv:" + yyyyMMdd;
    }
}

