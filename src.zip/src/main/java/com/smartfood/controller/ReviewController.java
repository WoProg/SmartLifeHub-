package com.smartfood.controller;

import com.smartfood.common.Result;
import com.smartfood.entity.Order;
import com.smartfood.entity.OrderStatus;
import com.smartfood.entity.ReportRecord;
import com.smartfood.entity.Review;
import com.smartfood.exception.BizException;
import com.smartfood.mapper.OrderMapper;
import com.smartfood.mapper.ReportRecordMapper;
import com.smartfood.mapper.ReviewMapper;
import com.smartfood.security.session.RedisLoginSessionService;
import lombok.Data;
import lombok.RequiredArgsConstructor;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Locale;

@RestController
@RequiredArgsConstructor
public class ReviewController {
    private final RedisLoginSessionService redisLoginSessionService;
    private final OrderMapper orderMapper;
    private final ReviewMapper reviewMapper;
    private final ReportRecordMapper reportRecordMapper;

    @PostMapping("/review")
    public Result<Long> publish(@RequestHeader("Authorization") String authorization, @RequestBody PublishReviewRequest request) {
        Long userId = currentUserId(authorization);
        if (request == null || request.orderNo == null || request.rating == null) throw new BizException(400, "参数非法");
        Order order = orderMapper.selectById(request.orderNo);
        if (order == null || !userId.equals(order.getUserId())) throw new BizException(404, "订单不存在");
        if (order.getStatus() != OrderStatus.COMPLETED) throw new BizException(409, "仅已完成订单可评价");

        Review review = Review.builder()
                .orderNo(request.orderNo)
                .userId(userId)
                .shopId(order.getShopId())
                .dishId(request.dishId)
                .rating(request.rating)
                .content(request.content)
                .images(request.images)
                .status(0)
                .likeCount(0)
                .build();
        review.setCreateTime(LocalDateTime.now());
        review.setUpdateTime(LocalDateTime.now());
        reviewMapper.insert(review);
        return Result.success(review.getId());
    }

    @GetMapping("/review/shop/{shopId}")
    public Result<List<Review>> listByShop(@PathVariable("shopId") Long shopId,
                                           @RequestParam(name = "limit", defaultValue = "50") Integer limit) {
        return Result.success(reviewMapper.listApprovedByShop(shopId, Math.max(1, Math.min(limit, 200))));
    }

    @PostMapping("/review/{id}/like")
    public Result<Void> like(@RequestHeader("Authorization") String authorization, @PathVariable("id") Long id) {
        currentUserId(authorization);
        reviewMapper.updateLikeCount(id, 1);
        return Result.success();
    }

    @DeleteMapping("/review/{id}/like")
    public Result<Void> unlike(@RequestHeader("Authorization") String authorization, @PathVariable("id") Long id) {
        currentUserId(authorization);
        reviewMapper.updateLikeCount(id, -1);
        return Result.success();
    }

    @PostMapping("/report")
    public Result<Void> report(@RequestHeader("Authorization") String authorization, @RequestBody ReportRequest request) {
        Long userId = currentUserId(authorization);
        if (request == null || !StringUtils.hasText(request.targetType) || request.targetId == null || !StringUtils.hasText(request.reason)) {
            throw new BizException(400, "参数非法");
        }
        ReportRecord record = ReportRecord.builder()
                .reporterUserId(userId)
                .targetType(request.targetType.toUpperCase(Locale.ROOT))
                .targetId(request.targetId)
                .reason(request.reason)
                .status(0)
                .build();
        record.setCreateTime(LocalDateTime.now());
        record.setUpdateTime(LocalDateTime.now());
        reportRecordMapper.insert(record);
        return Result.success();
    }

    private Long currentUserId(String authorization) {
        if (!StringUtils.hasText(authorization)) throw new BizException(401, "缺少 Authorization header");
        String token = authorization.trim();
        if (token.toLowerCase(Locale.ROOT).startsWith("bearer ")) token = token.substring(7).trim();
        return redisLoginSessionService.requireSession(token).getId();
    }

    @Data
    public static class PublishReviewRequest {
        public Long orderNo;
        public Long dishId;
        public Integer rating;
        public String content;
        public String images;
    }

    @Data
    public static class ReportRequest {
        public String targetType;
        public Long targetId;
        public String reason;
    }
}
