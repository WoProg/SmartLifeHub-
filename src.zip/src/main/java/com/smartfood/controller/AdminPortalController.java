package com.smartfood.controller;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.smartfood.common.Result;
import com.smartfood.entity.Order;
import com.smartfood.entity.OrderStatus;
import com.smartfood.entity.Shop;
import com.smartfood.entity.ShopStatus;
import com.smartfood.entity.User;
import com.smartfood.entity.UserStatus;
import com.smartfood.exception.BizException;
import com.smartfood.mapper.OrderMapper;
import com.smartfood.mapper.ShopMapper;
import com.smartfood.mapper.UserMapper;
import com.smartfood.security.JwtUtil;
import com.smartfood.security.session.RedisLoginSessionService;
import io.jsonwebtoken.Claims;
import lombok.Data;
import lombok.RequiredArgsConstructor;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.*;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Locale;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/admin")
@RequiredArgsConstructor
public class AdminPortalController {

    private final JwtUtil jwtUtil;
    private final RedisLoginSessionService redisLoginSessionService;
    private final UserMapper userMapper;
    private final ShopMapper shopMapper;
    private final OrderMapper orderMapper;
    private final BCryptPasswordEncoder passwordEncoder = new BCryptPasswordEncoder();

    @PostMapping("/login")
    public Result<AdminLoginResponse> login(@RequestBody AdminLoginRequest request) {
        if (request == null || !StringUtils.hasText(request.getUsername()) || !StringUtils.hasText(request.getPassword())) {
            throw new BizException(400, "用户名和密码不能为空");
        }
        String username = request.getUsername().trim();
        String password = request.getPassword();

        Long operatorId;
        String role;
        String displayName;

        if ("admin".equalsIgnoreCase(username)) {
            if (!"admin123".equals(password)) {
                throw new BizException(401, "账号或密码错误");
            }
            operatorId = 900000000001L;
            role = "ADMIN";
            displayName = "平台管理员";
        } else if (username.toLowerCase(Locale.ROOT).startsWith("merchant_")) {
            String suffix = username.substring("merchant_".length());
            Long shopId;
            try {
                shopId = Long.valueOf(suffix);
            } catch (Exception ex) {
                throw new BizException(400, "商家账号格式应为 merchant_{shopId}");
            }
            Shop shop = shopMapper.selectById(shopId);
            if (shop == null) {
                throw new BizException(404, "商家店铺不存在");
            }
            if (!"merchant123".equals(password)) {
                throw new BizException(401, "账号或密码错误");
            }
            operatorId = shopId;
            role = "MERCHANT";
            displayName = "商家-" + shop.getName();
        } else {
            User user = userMapper.selectByPhone(username);
            if (user == null) {
                throw new BizException(401, "账号或密码错误");
            }
            if (!passwordEncoder.matches(password, user.getPassword())) {
                throw new BizException(401, "账号或密码错误");
            }
            operatorId = user.getId();
            role = "USER";
            displayName = StringUtils.hasText(user.getNickname()) ? user.getNickname() : user.getPhone();
        }

        String token = jwtUtil.generateTokenWithRole(operatorId, role);
        User sessionUser = User.builder()
                .id(operatorId)
                .phone(username)
                .nickname(displayName)
                .status(UserStatus.NORMAL)
                .userLevel(0)
                .build();
        redisLoginSessionService.saveSession(token, sessionUser);

        AdminLoginResponse response = new AdminLoginResponse();
        response.setToken(token);
        response.setUsername(displayName);
        response.setAvatar("");
        response.setRoles(List.of(role));
        return Result.success(response);
    }

    @GetMapping("/users")
    public Result<PageResult<UserItemResponse>> users(
            @RequestHeader("Authorization") String authorization,
            @RequestParam(name = "page", defaultValue = "1") long page,
            @RequestParam(name = "size", defaultValue = "20") long size,
            @RequestParam(name = "keyword", required = false) String keyword,
            @RequestParam(name = "status", required = false) String status) {
        requireRole(authorization, "ADMIN");

        QueryWrapper<User> qw = new QueryWrapper<>();
        if (StringUtils.hasText(keyword)) {
            qw.and(w -> w.like("phone", keyword).or().like("nickname", keyword));
        }
        if (StringUtils.hasText(status)) {
            if ("BANNED".equalsIgnoreCase(status) || "DISABLED".equalsIgnoreCase(status)) {
                qw.eq("status", UserStatus.DISABLED.ordinal());
            } else if ("NORMAL".equalsIgnoreCase(status)) {
                qw.eq("status", UserStatus.NORMAL.ordinal());
            }
        }
        qw.orderByDesc("create_time");

        Page<User> result = userMapper.selectPage(new Page<>(page, size), qw);
        List<UserItemResponse> records = result.getRecords().stream().map(this::toUserItem).collect(Collectors.toList());
        return Result.success(PageResult.of(records, result.getTotal(), result.getCurrent(), result.getSize()));
    }

    @PostMapping("/users/{id}/toggle-status")
    public Result<Void> toggleUserStatus(
            @RequestHeader("Authorization") String authorization,
            @PathVariable("id") Long id) {
        requireRole(authorization, "ADMIN");
        User user = userMapper.selectById(id);
        if (user == null) {
            throw new BizException(404, "用户不存在");
        }
        user.setStatus(user.getStatus() == UserStatus.DISABLED ? UserStatus.NORMAL : UserStatus.DISABLED);
        user.setUpdateTime(LocalDateTime.now());
        userMapper.updateById(user);
        return Result.success();
    }

    @GetMapping("/shops")
    public Result<PageResult<ShopItemResponse>> shops(
            @RequestHeader("Authorization") String authorization,
            @RequestParam(name = "page", defaultValue = "1") long page,
            @RequestParam(name = "size", defaultValue = "20") long size,
            @RequestParam(name = "keyword", required = false) String keyword) {
        requireRole(authorization, "ADMIN", "MERCHANT");
        QueryWrapper<Shop> qw = new QueryWrapper<>();
        if (StringUtils.hasText(keyword)) {
            qw.like("name", keyword);
        }
        qw.orderByDesc("sales_count");
        Page<Shop> result = shopMapper.selectPage(new Page<>(page, size), qw);
        List<ShopItemResponse> records = result.getRecords().stream().map(this::toShopItem).collect(Collectors.toList());
        return Result.success(PageResult.of(records, result.getTotal(), result.getCurrent(), result.getSize()));
    }

    @GetMapping("/orders")
    public Result<PageResult<OrderItemResponse>> orders(
            @RequestHeader("Authorization") String authorization,
            @RequestParam(name = "page", defaultValue = "1") long page,
            @RequestParam(name = "size", defaultValue = "20") long size,
            @RequestParam(name = "status", required = false) String status) {
        String role = requireRole(authorization, "ADMIN", "MERCHANT");
        Long operatorId = parseOperatorId(authorization);

        QueryWrapper<Order> qw = new QueryWrapper<>();
        if ("MERCHANT".equalsIgnoreCase(role)) {
            qw.eq("shop_id", operatorId);
        }
        if (StringUtils.hasText(status)) {
            OrderStatus orderStatus = parseOrderStatus(status);
            if (orderStatus != null) {
                qw.eq("status", orderStatus.ordinal());
            }
        }
        qw.orderByDesc("create_time");

        Page<Order> result = orderMapper.selectPage(new Page<>(page, size), qw);
        List<OrderItemResponse> records = result.getRecords().stream().map(this::toOrderItem).collect(Collectors.toList());
        return Result.success(PageResult.of(records, result.getTotal(), result.getCurrent(), result.getSize()));
    }

    @GetMapping("/stats/overview")
    public Result<OverviewResponse> overview(@RequestHeader("Authorization") String authorization) {
        requireRole(authorization, "ADMIN", "MERCHANT");

        long users = userMapper.selectCount(new QueryWrapper<>());
        long shops = shopMapper.selectCount(new QueryWrapper<>());
        List<Order> orders = orderMapper.selectList(new QueryWrapper<>());

        long totalOrders = orders.size();
        BigDecimal gmv = orders.stream()
                .map(Order::getTotalAmount)
                .filter(v -> v != null)
                .reduce(BigDecimal.ZERO, BigDecimal::add);

        OverviewResponse response = new OverviewResponse();
        response.setTotalUsers(users);
        response.setTotalShops(shops);
        response.setTotalOrders(totalOrders);
        response.setGmv(gmv);
        return Result.success(response);
    }

    private String requireRole(String authorization, String... roles) {
        String token = normalizeToken(authorization);
        redisLoginSessionService.requireSession(token);
        Claims claims = jwtUtil.parseClaims(token);
        String role = claims.get("role", String.class);
        if (!StringUtils.hasText(role)) {
            role = "USER";
        }
        for (String allowed : roles) {
            if (allowed.equalsIgnoreCase(role)) {
                return role;
            }
        }
        throw new BizException(403, "角色无权限");
    }

    private Long parseOperatorId(String authorization) {
        Claims claims = jwtUtil.parseClaims(normalizeToken(authorization));
        Object operatorId = claims.get("operatorId");
        if (operatorId instanceof Number) {
            return ((Number) operatorId).longValue();
        }
        return Long.parseLong(claims.getSubject());
    }

    private String normalizeToken(String authorization) {
        if (!StringUtils.hasText(authorization)) {
            throw new BizException(401, "缺少 Authorization header");
        }
        String token = authorization.trim();
        if (token.toLowerCase(Locale.ROOT).startsWith("bearer ")) {
            token = token.substring(7).trim();
        }
        if (!StringUtils.hasText(token)) {
            throw new BizException(401, "token无效");
        }
        return token;
    }

    private UserItemResponse toUserItem(User user) {
        UserItemResponse r = new UserItemResponse();
        r.setId(user.getId());
        r.setNickname(user.getNickname());
        r.setPhone(user.getPhone());
        r.setStatus(user.getStatus() == UserStatus.DISABLED ? "BANNED" : "NORMAL");
        r.setLevel(user.getUserLevel());
        r.setCreateTime(user.getCreateTime());
        r.setLastLogin(user.getLastLoginTime());
        return r;
    }

    private ShopItemResponse toShopItem(Shop shop) {
        ShopItemResponse r = new ShopItemResponse();
        r.setId(shop.getId());
        r.setName(shop.getName());
        r.setAddress(shop.getAddress());
        r.setScore(shop.getRating());
        r.setOrderCount(shop.getSalesCount());
        r.setStatus(shop.getBusinessStatus() == ShopStatus.OPEN ? "营业中" : "休息中");
        return r;
    }

    private OrderItemResponse toOrderItem(Order order) {
        OrderItemResponse r = new OrderItemResponse();
        r.setOrderNo(order.getOrderNo());
        r.setUserId(order.getUserId());
        r.setShopId(order.getShopId());
        r.setAmount(order.getTotalAmount());
        r.setStatus(mapOrderStatusLabel(order.getStatus()));
        r.setTime(order.getCreateTime());
        return r;
    }

    private String mapOrderStatusLabel(OrderStatus status) {
        if (status == null) return "未知";
        switch (status) {
            case PENDING_PAYMENT:
                return "待付款";
            case PENDING_ACCEPT:
                return "待接单";
            case MAKING:
                return "制作中";
            case PENDING_DELIVERY:
                return "待配送";
            case DELIVERING:
                return "配送中";
            case COMPLETED:
                return "已完成";
            case CANCELLED:
                return "已取消";
            default:
                return "未知";
        }
    }

    private OrderStatus parseOrderStatus(String status) {
        String v = status.trim().toLowerCase(Locale.ROOT);
        switch (v) {
            case "待付款":
            case "pending_payment":
                return OrderStatus.PENDING_PAYMENT;
            case "待接单":
            case "pending_accept":
                return OrderStatus.PENDING_ACCEPT;
            case "制作中":
            case "making":
                return OrderStatus.MAKING;
            case "待配送":
            case "pending_delivery":
                return OrderStatus.PENDING_DELIVERY;
            case "配送中":
            case "delivering":
                return OrderStatus.DELIVERING;
            case "已完成":
            case "completed":
                return OrderStatus.COMPLETED;
            case "已取消":
            case "cancelled":
                return OrderStatus.CANCELLED;
            default:
                return null;
        }
    }

    @Data
    public static class AdminLoginRequest {
        private String username;
        private String password;
    }

    @Data
    public static class AdminLoginResponse {
        private String token;
        private String username;
        private String avatar;
        private List<String> roles;
    }

    @Data
    public static class UserItemResponse {
        private Long id;
        private String nickname;
        private String phone;
        private String status;
        private Integer level;
        private LocalDateTime createTime;
        private LocalDateTime lastLogin;
    }

    @Data
    public static class ShopItemResponse {
        private Long id;
        private String name;
        private String address;
        private BigDecimal score;
        private Integer orderCount;
        private String status;
    }

    @Data
    public static class OrderItemResponse {
        private Long orderNo;
        private Long userId;
        private Long shopId;
        private BigDecimal amount;
        private String status;
        private LocalDateTime time;
    }

    @Data
    public static class OverviewResponse {
        private Long totalUsers;
        private Long totalShops;
        private Long totalOrders;
        private BigDecimal gmv;
    }

    @Data
    public static class PageResult<T> {
        private List<T> records;
        private long total;
        private long current;
        private long size;

        public static <T> PageResult<T> of(List<T> records, long total, long current, long size) {
            PageResult<T> r = new PageResult<>();
            r.setRecords(records);
            r.setTotal(total);
            r.setCurrent(current);
            r.setSize(size);
            return r;
        }
    }
}
