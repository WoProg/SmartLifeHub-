package com.smartfood.controller;

import com.smartfood.common.Result;
import com.smartfood.exception.BizException;
import com.smartfood.service.OrderStateMachineService;
import com.smartfood.security.JwtUtil;
import com.smartfood.security.session.RedisLoginSessionService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.tags.Tag;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import io.jsonwebtoken.Claims;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

/**
 * 订单状态机控制器。
 *
 * Day1 实现目标：
 * - 提供商家/骑手/用户的状态变更接口
 * - 基于 JWT 的 role 做角色权限校验
 * - 由 OrderStateMachineService 完成状态前置校验与操作日志写入
 */
@Slf4j
@Tag(name = "订单状态机", description = "商家接单/制作/配送、骑手配送、用户取消/确认收货")
@RestController
@RequestMapping("/order")
@Validated
@RequiredArgsConstructor
public class OrderStateMachineController {

    private final OrderStateMachineService stateMachineService;
    private final JwtUtil jwtUtil;
    private final RedisLoginSessionService redisLoginSessionService;

    /**
     * 商家接单：待付款 -> 待接单（需支付状态已支付）
     */
    @Operation(summary = "商家接单", description = "待付款且已支付后，商家可把订单推进到待接单。")
    @ApiResponses({
            @ApiResponse(responseCode = "200", description = "操作成功"),
            @ApiResponse(responseCode = "403", description = "角色无权限"),
            @ApiResponse(responseCode = "409", description = "订单状态不允许")
    })
    @PostMapping("/{orderNo}/merchant/accept")
    public Result<Void> merchantAccept(
            @Parameter(description = "订单号", example = "1217752501201407033233368018")
            @PathVariable("orderNo") Long orderNo,
            @RequestHeader("Authorization") String authorization) {
        OperatorContext ctx = parseOperator(authorization);
        requireRole(ctx, "MERCHANT");
        stateMachineService.merchantAccept(orderNo, ctx.getOperatorId(), ctx.getOperatorId());
        return Result.success();
    }

    /**
     * 商家开始制作：待接单 -> 制作中
     */
    @PostMapping("/{orderNo}/merchant/start-make")
    public Result<Void> merchantStartMake(
            @PathVariable("orderNo") Long orderNo,
            @RequestHeader("Authorization") String authorization) {
        OperatorContext ctx = parseOperator(authorization);
        requireRole(ctx, "MERCHANT");
        stateMachineService.merchantStartMake(orderNo, ctx.getOperatorId(), ctx.getOperatorId());
        return Result.success();
    }

    /**
     * 商家开始配送准备：制作中 -> 待配送
     */
    @PostMapping("/{orderNo}/merchant/start-delivery")
    public Result<Void> merchantStartDelivery(
            @PathVariable("orderNo") Long orderNo,
            @RequestHeader("Authorization") String authorization) {
        OperatorContext ctx = parseOperator(authorization);
        requireRole(ctx, "MERCHANT");
        stateMachineService.merchantStartDelivery(orderNo, ctx.getOperatorId(), ctx.getOperatorId());
        return Result.success();
    }

    /**
     * 骑手开始配送：待配送 -> 配送中
     */
    @PostMapping("/{orderNo}/rider/start-delivery")
    public Result<Void> riderStartDelivery(
            @PathVariable("orderNo") Long orderNo,
            @RequestHeader("Authorization") String authorization) {
        OperatorContext ctx = parseOperator(authorization);
        requireRole(ctx, "RIDER");
        stateMachineService.riderStartDelivery(orderNo, ctx.getOperatorId());
        return Result.success();
    }

    /**
     * 用户取消：仅允许待付款且未支付订单取消
     */
    @PostMapping("/{orderNo}/cancel")
    public Result<Void> cancelByUser(
            @PathVariable("orderNo") Long orderNo,
            @RequestHeader("Authorization") String authorization) {
        OperatorContext ctx = parseOperator(authorization);
        requireRole(ctx, "USER");
        stateMachineService.cancelByUser(orderNo, ctx.getOperatorId());
        return Result.success();
    }

    /**
     * 用户确认收货：配送中 -> 已完成
     */
    @PostMapping("/{orderNo}/confirm-receipt")
    public Result<Void> confirmReceipt(
            @PathVariable("orderNo") Long orderNo,
            @RequestHeader("Authorization") String authorization) {
        OperatorContext ctx = parseOperator(authorization);
        requireRole(ctx, "USER");
        stateMachineService.confirmReceipt(orderNo, ctx.getOperatorId());
        return Result.success();
    }

    /**
     * 从 Authorization 头解析操作人信息。
     */
    private OperatorContext parseOperator(String authorization) {
        if (authorization == null || authorization.trim().isEmpty()) {
            throw new BizException(401, "缺少 Authorization header");
        }
        String token = authorization.trim();
        if (token.toLowerCase().startsWith("bearer ")) {
            token = token.substring(7).trim();
        }

        // Redis 分布式 Session 校验 + 滑动续期
        redisLoginSessionService.requireSession(token);

        Claims claims = jwtUtil.parseClaims(token);
        String role = claims.get("role", String.class);
        // Day1 兼容：如果 token 没带 role，则默认当作 USER
        if (role == null || role.trim().isEmpty()) {
            role = "USER";
        }

        Object operatorIdObj = claims.get("operatorId");
        Long operatorId;
        if (operatorIdObj instanceof Number) {
            operatorId = ((Number) operatorIdObj).longValue();
        } else {
            // 回退：用 subject 当作 operatorId
            operatorId = Long.parseLong(claims.getSubject());
        }

        return new OperatorContext(role, operatorId);
    }

    /**
     * 校验角色。
     */
    private void requireRole(OperatorContext ctx, String expectRole) {
        if (!expectRole.equalsIgnoreCase(ctx.role)) {
            throw new BizException(403, "角色无权限");
        }
    }

    /**
     * 简单的操作人上下文。
     */
    private static class OperatorContext {
        private final String role;
        private final Long operatorId;

        private OperatorContext(String role, Long operatorId) {
            this.role = role;
            this.operatorId = operatorId;
        }

        public String getRole() {
            return role;
        }

        public Long getOperatorId() {
            return operatorId;
        }
    }
}

