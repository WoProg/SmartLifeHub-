package com.smartfood.controller;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.smartfood.common.Result;
import com.smartfood.entity.*;
import com.smartfood.exception.BizException;
import com.smartfood.mapper.*;
import com.smartfood.security.session.RedisLoginSessionService;
import lombok.Data;
import lombok.RequiredArgsConstructor;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.*;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.*;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/app")
@RequiredArgsConstructor
public class ConsumerPortalController {

    private final RedisLoginSessionService redisLoginSessionService;
    private final AddressMapper addressMapper;
    private final CartMapper cartMapper;
    private final DishMapper dishMapper;
    private final ShopMapper shopMapper;
    private final OrderMapper orderMapper;
    private final OrderDetailMapper orderDetailMapper;

    @GetMapping("/address")
    public Result<List<AddressItem>> addressList(@RequestHeader("Authorization") String authorization) {
        Long userId = currentUserId(authorization);
        List<AddressItem> list = addressMapper.selectByUserId(userId).stream().map(this::toAddressItem).collect(Collectors.toList());
        return Result.success(list);
    }

    @PostMapping("/address")
    public Result<Void> addAddress(@RequestHeader("Authorization") String authorization,
                                   @RequestBody AddressSaveRequest request) {
        Long userId = currentUserId(authorization);
        validateAddress(request);
        AddressMapper.AddressRow row = toAddressRow(request, userId, null);
        if (row.isDefault != null && row.isDefault == 1) {
            addressMapper.clearDefault(userId);
        }
        addressMapper.insertAddress(row);
        return Result.success();
    }

    @PutMapping("/address/{id}")
    public Result<Void> updateAddress(@RequestHeader("Authorization") String authorization,
                                      @PathVariable("id") Long id,
                                      @RequestBody AddressSaveRequest request) {
        Long userId = currentUserId(authorization);
        validateAddress(request);
        Address exist = addressMapper.selectByIdAndUserId(id, userId);
        if (exist == null) throw new BizException(404, "地址不存在");
        AddressMapper.AddressRow row = toAddressRow(request, userId, id);
        if (row.isDefault != null && row.isDefault == 1) {
            addressMapper.clearDefault(userId);
        }
        addressMapper.updateAddress(row);
        return Result.success();
    }

    @DeleteMapping("/address/{id}")
    public Result<Void> deleteAddress(@RequestHeader("Authorization") String authorization,
                                      @PathVariable("id") Long id) {
        Long userId = currentUserId(authorization);
        addressMapper.deleteByIdAndUserId(id, userId);
        return Result.success();
    }

    @PostMapping("/address/{id}/default")
    public Result<Void> setDefaultAddress(@RequestHeader("Authorization") String authorization,
                                          @PathVariable("id") Long id) {
        Long userId = currentUserId(authorization);
        Address exist = addressMapper.selectByIdAndUserId(id, userId);
        if (exist == null) throw new BizException(404, "地址不存在");
        addressMapper.clearDefault(userId);
        AddressMapper.AddressRow row = new AddressMapper.AddressRow();
        row.id = id;
        row.userId = userId;
        row.receiver = exist.getReceiver();
        row.receiverPhone = exist.getReceiverPhone();
        row.province = exist.getProvince();
        row.city = exist.getCity();
        row.detailAddress = exist.getDetailAddress();
        row.isDefault = 1;
        addressMapper.updateAddress(row);
        return Result.success();
    }

    @GetMapping("/cart")
    public Result<List<CartItemResponse>> cartList(@RequestHeader("Authorization") String authorization) {
        Long userId = currentUserId(authorization);
        List<CartItem> items = cartMapper.selectByUserId(userId);
        Map<Long, Dish> dishMap = dishesByIds(items.stream().map(CartItem::getDishId).collect(Collectors.toList()));
        List<CartItemResponse> list = items.stream().map(i -> toCartItem(i, dishMap.get(i.getDishId()))).collect(Collectors.toList());
        return Result.success(list);
    }

    @PostMapping("/cart")
    public Result<Void> addCart(@RequestHeader("Authorization") String authorization,
                                @RequestBody CartAddRequest request) {
        Long userId = currentUserId(authorization);
        if (request == null || request.getDishId() == null || request.getQuantity() == null || request.getQuantity() <= 0) {
            throw new BizException(400, "参数非法");
        }
        Dish dish = dishMapper.selectById(request.getDishId());
        if (dish == null) throw new BizException(404, "菜品不存在");
        String specKey = StringUtils.hasText(request.getSpecKey()) ? request.getSpecKey() : "default";
        String specJson = StringUtils.hasText(request.getSpecJson()) ? request.getSpecJson() : "{}";
        CartItem exist = cartMapper.selectByUserDishSpec(userId, request.getDishId(), specKey);
        if (exist == null) {
            CartItem item = CartItem.builder()
                    .userId(userId)
                    .dishId(request.getDishId())
                    .quantity(request.getQuantity())
                    .specKey(specKey)
                    .specJson(specJson)
                    .isSelected(1)
                    .build();
            cartMapper.insertCartItem(item);
        } else {
            cartMapper.increaseQuantity(exist.getId(), request.getQuantity());
        }
        return Result.success();
    }

    @PutMapping("/cart/{id}/quantity")
    public Result<Void> updateCartQuantity(@RequestHeader("Authorization") String authorization,
                                           @PathVariable("id") Long id,
                                           @RequestBody CartUpdateQuantityRequest request) {
        Long userId = currentUserId(authorization);
        CartItem item = cartMapper.selectById(id);
        if (item == null || !userId.equals(item.getUserId())) throw new BizException(404, "购物车项不存在");
        if (request == null || request.getQuantity() == null || request.getQuantity() <= 0) throw new BizException(400, "数量非法");
        cartMapper.updateQuantity(id, request.getQuantity());
        return Result.success();
    }

    @PutMapping("/cart/{id}/selected")
    public Result<Void> updateCartSelected(@RequestHeader("Authorization") String authorization,
                                           @PathVariable("id") Long id,
                                           @RequestBody CartUpdateSelectedRequest request) {
        Long userId = currentUserId(authorization);
        CartItem item = cartMapper.selectById(id);
        if (item == null || !userId.equals(item.getUserId())) throw new BizException(404, "购物车项不存在");
        int selected = request != null && Boolean.TRUE.equals(request.getSelected()) ? 1 : 0;
        cartMapper.updateSelected(id, selected);
        return Result.success();
    }

    @DeleteMapping("/cart/{id}")
    public Result<Void> deleteCart(@RequestHeader("Authorization") String authorization,
                                   @PathVariable("id") Long id) {
        Long userId = currentUserId(authorization);
        CartItem item = cartMapper.selectById(id);
        if (item == null || !userId.equals(item.getUserId())) throw new BizException(404, "购物车项不存在");
        cartMapper.deleteByCartId(id);
        return Result.success();
    }

    @DeleteMapping("/cart")
    public Result<Void> clearCart(@RequestHeader("Authorization") String authorization) {
        Long userId = currentUserId(authorization);
        cartMapper.clearByUserId(userId);
        return Result.success();
    }

    @GetMapping("/shops/search")
    public Result<List<ShopSearchItem>> searchShops(@RequestParam("keyword") String keyword) {
        if (!StringUtils.hasText(keyword)) return Result.success(List.of());
        QueryWrapper<Shop> qw = new QueryWrapper<>();
        qw.like("name", keyword).orderByDesc("sales_count");
        List<Shop> shops = shopMapper.selectList(qw);
        return Result.success(shops.stream().map(this::toShopSearchItem).collect(Collectors.toList()));
    }

    @GetMapping("/dishes/search")
    public Result<List<DishSearchItem>> searchDishes(@RequestParam("keyword") String keyword,
                                                     @RequestParam(name = "limit", defaultValue = "20") Integer limit) {
        if (!StringUtils.hasText(keyword)) return Result.success(List.of());
        List<Dish> dishes = dishMapper.searchByName(keyword.trim(), Math.max(1, Math.min(limit, 100)));
        Map<Long, Shop> shopMap = shopByIds(dishes.stream().map(Dish::getShopId).collect(Collectors.toList()));
        return Result.success(dishes.stream().map(d -> toDishSearchItem(d, shopMap.get(d.getShopId()))).collect(Collectors.toList()));
    }

    @GetMapping("/shops/{shopId}/dishes")
    public Result<List<DishSearchItem>> shopDishes(@PathVariable("shopId") Long shopId) {
        List<Dish> dishes = dishMapper.selectByShopId(shopId);
        Shop shop = shopMapper.selectById(shopId);
        return Result.success(dishes.stream().map(d -> toDishSearchItem(d, shop)).collect(Collectors.toList()));
    }

    @GetMapping("/orders")
    public Result<PageResult<OrderSimpleItem>> myOrders(@RequestHeader("Authorization") String authorization,
                                                         @RequestParam(name = "page", defaultValue = "1") long page,
                                                         @RequestParam(name = "size", defaultValue = "20") long size) {
        Long userId = currentUserId(authorization);
        QueryWrapper<Order> qw = new QueryWrapper<Order>().eq("user_id", userId).orderByDesc("create_time");
        Page<Order> orders = orderMapper.selectPage(new Page<>(page, size), qw);
        Map<Long, Shop> shopMap = shopByIds(orders.getRecords().stream().map(Order::getShopId).collect(Collectors.toList()));
        List<OrderSimpleItem> records = orders.getRecords().stream().map(o -> toOrderSimpleItem(o, shopMap.get(o.getShopId()))).collect(Collectors.toList());
        return Result.success(PageResult.of(records, orders.getTotal(), orders.getCurrent(), orders.getSize()));
    }

    @GetMapping("/orders/{orderNo}")
    public Result<OrderDetailResponse> orderDetail(@RequestHeader("Authorization") String authorization,
                                                   @PathVariable("orderNo") Long orderNo) {
        Long userId = currentUserId(authorization);
        Order order = orderMapper.selectById(orderNo);
        if (order == null || !userId.equals(order.getUserId())) throw new BizException(404, "订单不存在");
        List<OrderDetail> details = orderDetailMapper.selectByOrderNo(orderNo);
        Map<Long, Dish> dishMap = dishesByIds(details.stream().map(OrderDetail::getDishId).collect(Collectors.toList()));
        Shop shop = shopMapper.selectById(order.getShopId());
        OrderDetailResponse response = new OrderDetailResponse();
        response.setOrderNo(orderNo);
        response.setStatus(order.getStatus().name());
        response.setStatusLabel(orderStatusLabel(order.getStatus()));
        response.setTotalAmount(order.getTotalAmount());
        response.setShopName(shop == null ? "" : shop.getName());
        response.setCreateTime(order.getCreateTime());
        response.setPayAt(order.getPayAt());
        response.setFinishAt(order.getFinishAt());
        response.setItems(details.stream().map(d -> {
            OrderDishItem i = new OrderDishItem();
            Dish dish = dishMap.get(d.getDishId());
            i.setDishId(d.getDishId());
            i.setDishName(dish == null ? "菜品" : dish.getName());
            i.setQuantity(d.getQuantity());
            i.setUnitPrice(d.getUnitPrice());
            i.setSpecJson(d.getSpecJson());
            return i;
        }).collect(Collectors.toList()));
        return Result.success(response);
    }

    private Long currentUserId(String authorization) {
        if (!StringUtils.hasText(authorization)) throw new BizException(401, "缺少 Authorization header");
        String token = authorization.trim();
        if (token.toLowerCase(Locale.ROOT).startsWith("bearer ")) token = token.substring(7).trim();
        return redisLoginSessionService.requireSession(token).getId();
    }

    private void validateAddress(AddressSaveRequest request) {
        if (request == null || !StringUtils.hasText(request.getReceiver()) || !StringUtils.hasText(request.getReceiverPhone())
                || !StringUtils.hasText(request.getDetailAddress())) {
            throw new BizException(400, "地址参数不完整");
        }
    }

    private AddressMapper.AddressRow toAddressRow(AddressSaveRequest request, Long userId, Long id) {
        AddressMapper.AddressRow row = new AddressMapper.AddressRow();
        row.id = id;
        row.userId = userId;
        row.receiver = request.getReceiver().trim();
        row.receiverPhone = request.getReceiverPhone().trim();
        row.province = request.getProvince();
        row.city = request.getCity();
        row.detailAddress = request.getDetailAddress().trim();
        row.isDefault = Boolean.TRUE.equals(request.getDefaultAddress()) ? 1 : 0;
        return row;
    }

    private Map<Long, Dish> dishesByIds(List<Long> dishIds) {
        List<Long> ids = dishIds.stream().filter(Objects::nonNull).distinct().collect(Collectors.toList());
        if (ids.isEmpty()) return Map.of();
        return dishMapper.selectByIds(ids).stream().collect(Collectors.toMap(Dish::getId, d -> d, (a, b) -> a));
    }

    private Map<Long, Shop> shopByIds(List<Long> shopIds) {
        List<Long> ids = shopIds.stream().filter(Objects::nonNull).distinct().collect(Collectors.toList());
        if (ids.isEmpty()) return Map.of();
        QueryWrapper<Shop> qw = new QueryWrapper<>();
        qw.in("id", ids);
        return shopMapper.selectList(qw).stream().collect(Collectors.toMap(Shop::getId, s -> s, (a, b) -> a));
    }

    private AddressItem toAddressItem(Address a) {
        AddressItem r = new AddressItem();
        r.setId(a.getId());
        r.setReceiver(a.getReceiver());
        r.setReceiverPhone(a.getReceiverPhone());
        r.setProvince(a.getProvince());
        r.setCity(a.getCity());
        r.setDetailAddress(a.getDetailAddress());
        r.setDefaultAddress(a.getIsDefault() != null && a.getIsDefault() == 1);
        return r;
    }

    private CartItemResponse toCartItem(CartItem i, Dish d) {
        CartItemResponse r = new CartItemResponse();
        r.setId(i.getId());
        r.setDishId(i.getDishId());
        r.setDishName(d == null ? "" : d.getName());
        r.setDishImage(d == null ? "" : d.getImage());
        r.setUnitPrice(d == null ? BigDecimal.ZERO : d.getPrice());
        r.setQuantity(i.getQuantity());
        r.setSelected(i.getIsSelected() != null && i.getIsSelected() == 1);
        r.setSpecKey(i.getSpecKey());
        r.setSpecJson(i.getSpecJson());
        return r;
    }

    private ShopSearchItem toShopSearchItem(Shop s) {
        ShopSearchItem r = new ShopSearchItem();
        r.setId(s.getId());
        r.setName(s.getName());
        r.setAddress(s.getAddress());
        r.setRating(s.getRating());
        r.setSalesCount(s.getSalesCount());
        r.setDeliveryFee(s.getDeliveryFee());
        r.setMinOrderAmount(s.getMinOrderAmount());
        r.setStatus(s.getBusinessStatus() == ShopStatus.OPEN ? "营业中" : "打烊");
        return r;
    }

    private DishSearchItem toDishSearchItem(Dish d, Shop shop) {
        DishSearchItem r = new DishSearchItem();
        r.setId(d.getId());
        r.setShopId(d.getShopId());
        r.setShopName(shop == null ? "" : shop.getName());
        r.setName(d.getName());
        r.setPrice(d.getPrice());
        r.setImage(d.getImage());
        r.setDescription(d.getDescription());
        r.setSalesVolume(d.getSalesVolume());
        r.setStock(d.getStockQuantity());
        r.setStatus(d.getStatus() == DishStatus.ON_SALE ? "在售" : "停售");
        return r;
    }

    private OrderSimpleItem toOrderSimpleItem(Order o, Shop shop) {
        OrderSimpleItem r = new OrderSimpleItem();
        r.setOrderNo(o.getOrderNo());
        r.setShopId(o.getShopId());
        r.setShopName(shop == null ? "" : shop.getName());
        r.setAmount(o.getTotalAmount());
        r.setStatus(o.getStatus().name());
        r.setStatusLabel(orderStatusLabel(o.getStatus()));
        r.setCreateTime(o.getCreateTime());
        return r;
    }

    private String orderStatusLabel(OrderStatus status) {
        if (status == null) return "未知";
        switch (status) {
            case PENDING_PAYMENT: return "待支付";
            case PENDING_ACCEPT: return "待接单";
            case MAKING: return "制作中";
            case PENDING_DELIVERY: return "待配送";
            case DELIVERING: return "配送中";
            case COMPLETED: return "已完成";
            case CANCELLED: return "已取消";
            default: return "未知";
        }
    }

    @Data
    public static class AddressSaveRequest {
        private String receiver;
        private String receiverPhone;
        private String province;
        private String city;
        private String detailAddress;
        private Boolean defaultAddress;
    }

    @Data
    public static class AddressItem {
        private Long id;
        private String receiver;
        private String receiverPhone;
        private String province;
        private String city;
        private String detailAddress;
        private Boolean defaultAddress;
    }

    @Data
    public static class CartAddRequest {
        private Long dishId;
        private Integer quantity;
        private String specKey;
        private String specJson;
    }

    @Data
    public static class CartUpdateQuantityRequest {
        private Integer quantity;
    }

    @Data
    public static class CartUpdateSelectedRequest {
        private Boolean selected;
    }

    @Data
    public static class CartItemResponse {
        private Long id;
        private Long dishId;
        private String dishName;
        private String dishImage;
        private BigDecimal unitPrice;
        private Integer quantity;
        private Boolean selected;
        private String specKey;
        private String specJson;
    }

    @Data
    public static class ShopSearchItem {
        private Long id;
        private String name;
        private String address;
        private BigDecimal rating;
        private Integer salesCount;
        private BigDecimal deliveryFee;
        private BigDecimal minOrderAmount;
        private String status;
    }

    @Data
    public static class DishSearchItem {
        private Long id;
        private Long shopId;
        private String shopName;
        private String name;
        private BigDecimal price;
        private String image;
        private String description;
        private Integer salesVolume;
        private Integer stock;
        private String status;
    }

    @Data
    public static class OrderSimpleItem {
        private Long orderNo;
        private Long shopId;
        private String shopName;
        private BigDecimal amount;
        private String status;
        private String statusLabel;
        private LocalDateTime createTime;
    }

    @Data
    public static class OrderDetailResponse {
        private Long orderNo;
        private String status;
        private String statusLabel;
        private String shopName;
        private BigDecimal totalAmount;
        private LocalDateTime createTime;
        private LocalDateTime payAt;
        private LocalDateTime finishAt;
        private List<OrderDishItem> items;
    }

    @Data
    public static class OrderDishItem {
        private Long dishId;
        private String dishName;
        private Integer quantity;
        private BigDecimal unitPrice;
        private String specJson;
    }

    @Data
    public static class PageResult<T> {
        private List<T> records;
        private long total;
        private long current;
        private long size;

        public static <T> PageResult<T> of(List<T> records, long total, long current, long size) {
            PageResult<T> r = new PageResult<>();
            r.setRecords(records);
            r.setTotal(total);
            r.setCurrent(current);
            r.setSize(size);
            return r;
        }
    }
}
