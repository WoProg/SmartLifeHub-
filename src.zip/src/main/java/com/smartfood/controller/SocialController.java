package com.smartfood.controller;

import com.smartfood.common.Result;
import com.smartfood.dto.UserResponse;
import com.smartfood.exception.BizException;
import com.smartfood.security.session.RedisLoginSessionService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import javax.validation.constraints.NotNull;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

/**
 * 点赞/关注/Feed（推模式）Redis 实现：
 * - Like: like:note:{noteId} Set<userId>
 * - Follow: follow:user:{userId} Set<followeeId>
 * - Followers 反向索引：followers:user:{followeeId} Set<followerId>（用于推模式快速获粉丝）
 * - Feed: feed:user:{userId} ZSet<noteId, score=时间戳>
 *
 * 说明：当前项目没有 Note 内容表，因此 Feed 接口只返回 noteId 列表。
 */
@Slf4j
@Tag(name = "社交互动", description = "点赞、关注、共同关注与Feed流")
@Validated
@RestController
@RequestMapping("/social")
@RequiredArgsConstructor
public class SocialController {

    private static final String LIKE_KEY_PREFIX = "like:note:";
    private static final String FOLLOW_KEY_PREFIX = "follow:user:";
    private static final String FOLLOWERS_KEY_PREFIX = "followers:user:";
    private static final String FEED_KEY_PREFIX = "feed:user:";

    private final StringRedisTemplate stringRedisTemplate;
    private final RedisLoginSessionService redisLoginSessionService;

    @Operation(summary = "点赞内容")
    @PostMapping("/like/{noteId}")
    public Result<Void> like(
            @RequestHeader("Authorization") String authorization,
            @PathVariable("noteId") @NotNull Long noteId) {
        Long userId = currentUserId(authorization);
        stringRedisTemplate.opsForSet().add(likeKey(noteId), String.valueOf(userId));
        return Result.success();
    }

    @Operation(summary = "取消点赞")
    @DeleteMapping("/like/{noteId}")
    public Result<Void> unlike(
            @RequestHeader("Authorization") String authorization,
            @PathVariable("noteId") @NotNull Long noteId) {
        Long userId = currentUserId(authorization);
        stringRedisTemplate.opsForSet().remove(likeKey(noteId), String.valueOf(userId));
        return Result.success();
    }

    @Operation(summary = "查询是否点赞")
    @GetMapping("/like/{noteId}/exists")
    public Result<Boolean> isLiked(
            @RequestHeader("Authorization") String authorization,
            @PathVariable("noteId") @NotNull Long noteId) {
        Long userId = currentUserId(authorization);
        Boolean exists = stringRedisTemplate.opsForSet().isMember(likeKey(noteId), String.valueOf(userId));
        return Result.success(Boolean.TRUE.equals(exists));
    }

    @Operation(summary = "查询点赞数量")
    @GetMapping("/like/{noteId}/count")
    public Result<Long> likeCount(
            @PathVariable("noteId") @NotNull Long noteId) {
        Long cnt = stringRedisTemplate.opsForSet().size(likeKey(noteId));
        return Result.success(cnt == null ? 0 : cnt);
    }

    @Operation(summary = "关注用户")
    @PostMapping("/follow/{followeeId}")
    public Result<Void> follow(
            @RequestHeader("Authorization") String authorization,
            @PathVariable("followeeId") @NotNull Long followeeId) {
        Long followerId = currentUserId(authorization);
        if (followerId.equals(followeeId)) {
            throw new BizException(400, "不能关注自己");
        }

        stringRedisTemplate.opsForSet().add(followKey(followerId), String.valueOf(followeeId));
        stringRedisTemplate.opsForSet().add(followersKey(followeeId), String.valueOf(followerId));
        return Result.success();
    }

    @Operation(summary = "取消关注")
    @DeleteMapping("/follow/{followeeId}")
    public Result<Void> unfollow(
            @RequestHeader("Authorization") String authorization,
            @PathVariable("followeeId") @NotNull Long followeeId) {
        Long followerId = currentUserId(authorization);
        stringRedisTemplate.opsForSet().remove(followKey(followerId), String.valueOf(followeeId));
        stringRedisTemplate.opsForSet().remove(followersKey(followeeId), String.valueOf(followerId));
        return Result.success();
    }

    @Operation(summary = "共同关注")
    @GetMapping("/follow/common/{otherUserId}")
    public Result<Set<Long>> commonFollowees(
            @RequestHeader("Authorization") String authorization,
            @PathVariable("otherUserId") @NotNull Long otherUserId) {
        Long userId = currentUserId(authorization);

        Set<String> inter = stringRedisTemplate.opsForSet()
                .intersect(followKey(userId), followKey(otherUserId));
        Set<Long> result = inter.stream().map(Long::valueOf).collect(Collectors.toSet());
        return Result.success(result);
    }

    /**
     * 发布新内容（推模式）：把 noteId 推送给所有粉丝的 Feed 时间线。
     */
    @Operation(summary = "发布内容并推送Feed")
    @PostMapping("/note/{noteId}/publish")
    public Result<Void> publishNote(
            @RequestHeader("Authorization") String authorization,
            @PathVariable("noteId") @NotNull Long noteId) {
        Long publisherId = currentUserId(authorization);

        Set<String> followers = stringRedisTemplate.opsForSet().members(followersKey(publisherId));
        if (followers == null || followers.isEmpty()) {
            return Result.success();
        }

        double score = System.currentTimeMillis() / 1000.0;
        for (String followerId : followers) {
            String feedKey = feedKey(Long.valueOf(followerId));
            stringRedisTemplate.opsForZSet().add(feedKey, String.valueOf(noteId), score);
        }
        return Result.success();
    }

    /**
     * 拉取时间线（Pull）：从 ZSet 取最新 noteId 列表。
     */
    @Operation(summary = "拉取Feed时间线")
    @GetMapping("/feed")
    public Result<List<Long>> getFeed(
            @RequestHeader("Authorization") String authorization,
            @RequestParam(name = "limit", defaultValue = "20") @NotNull Integer limit) {
        if (limit <= 0) {
            throw new BizException(400, "limit 非法");
        }

        Long userId = currentUserId(authorization);
        Set<String> noteIdSet = stringRedisTemplate.opsForZSet()
                .reverseRange(feedKey(userId), 0, limit - 1);

        List<Long> noteIds = noteIdSet == null ? List.of() :
                noteIdSet.stream().map(Long::valueOf).collect(Collectors.toList());
        return Result.success(noteIds);
    }

    private Long currentUserId(String authorization) {
        if (authorization == null || authorization.trim().isEmpty()) {
            throw new BizException(401, "缺少 Authorization header");
        }
        String token = authorization.trim();
        if (token.toLowerCase().startsWith("bearer ")) {
            token = token.substring(7).trim();
        }
        UserResponse sessionUser = redisLoginSessionService.requireSession(token);
        return sessionUser.getId();
    }

    private String likeKey(Long noteId) {
        return LIKE_KEY_PREFIX + noteId;
    }

    private String followKey(Long userId) {
        return FOLLOW_KEY_PREFIX + userId;
    }

    private String followersKey(Long userId) {
        return FOLLOWERS_KEY_PREFIX + userId;
    }

    private String feedKey(Long userId) {
        return FEED_KEY_PREFIX + userId;
    }
}

