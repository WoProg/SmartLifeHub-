package com.smartfood.controller;

import com.smartfood.config.properties.WxPayProperties;
import com.smartfood.exception.BizException;
import com.smartfood.pay.wechat.WechatPayNotifyService;
import com.wechat.pay.java.core.RSAAutoCertificateConfig;
import com.wechat.pay.java.core.notification.NotificationParser;
import com.wechat.pay.java.core.notification.RequestParam;
import com.wechat.pay.java.service.payments.model.Transaction;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.servlet.http.HttpServletRequest;
import java.util.Map;

import static java.nio.charset.StandardCharsets.UTF_8;

/**
 * 微信支付回调处理：/pay/wechat/notify
 *
 * 处理流程：
 * 1. real 模式：使用 NotificationParser 验签/解密解析 Transaction
 * 2. mock 模式：跳过验签/解密，按请求体 JSON 解析 transactionId/outTradeNo/tradeState
 * 3. 幂等：写入 wechat_payment_notification（wechat_notification_id 唯一）
 * 4. 同步：条件更新 order.pay_status/order.status
 * 5. 写操作日志：order_operation_log(event_type=PAY_SUCCESS/PAY_FAIL)
 */
@Slf4j
@RestController
@RequestMapping("/pay/wechat")
@RequiredArgsConstructor
public class WechatPayNotifyController {

    private final WxPayProperties wxPayProperties;
    private final WechatPayNotifyService notifyService;

    @PostMapping("/notify")
    public String notify(HttpServletRequest request,
                           @RequestBody(required = false) String body) {
        try {
            String mode = wxPayProperties.getMode();
            if (mode != null && "mock".equalsIgnoreCase(mode)) {
                handleMockNotify(body);
                return "success";
            }

            // real：按微信 v3 callback 头部字段读取验签所需数据
            String serial = request.getHeader("Wechatpay-Serial");
            String timestamp = request.getHeader("Wechatpay-Timestamp");
            String nonce = request.getHeader("Wechatpay-Nonce");
            String signature = request.getHeader("Wechatpay-Signature");

            if (serial == null || timestamp == null || nonce == null || signature == null) {
                throw new BizException(400, "缺少微信回调头字段");
            }
            if (body == null) {
                throw new BizException(400, "回调 body 为空");
            }

            // 构造 NotificationParser（使用 RSAAutoCertificateConfig）
            RSAAutoCertificateConfig config = new RSAAutoCertificateConfig.Builder()
                    .merchantId(wxPayProperties.getMchid())
                    .privateKeyFromPath(wxPayProperties.getPrivateKeyPath())
                    .merchantSerialNumber(wxPayProperties.getMerchantSerialNumber())
                    .apiV3Key(wxPayProperties.getApiV3Key())
                    .build();

            NotificationParser parser = new NotificationParser(config);

            // 组装解析请求
            RequestParam requestParam = new RequestParam.Builder()
                    .serialNumber(serial)
                    .timestamp(timestamp)
                    .nonce(nonce)
                    .signature(signature)
                    .signType("WECHATPAY2-SHA256-RSA2048")
                    .body(body)
                    .build();

            Transaction transaction = parser.parse(requestParam, Transaction.class);
            String outTradeNo = transaction.getOutTradeNo();
            Long orderNo = Long.parseLong(outTradeNo);
            String tradeState = transaction.getTradeState() == null ? null : transaction.getTradeState().toString();
            // 这里用 transactionId 做幂等唯一键（可稳定重试）
            String transactionId = transaction.getTransactionId();

            notifyService.handleNotification(orderNo, tradeState, transactionId, body);
            return "success";
        } catch (Exception e) {
            log.error("wechat notify error", e);
            // 微信要求：验签失败/解析失败通常返回非 200 或 fail，触发重试
            return "fail";
        }
    }

    /**
     * mock 模式：请求体建议为 JSON，例如：
     * {
     *   "orderNo": 123,
     *   "tradeState": "SUCCESS",
     *   "transactionId": "mock_tx_1"
     * }
     */
    private void handleMockNotify(String body) {
        if (body == null) {
            throw new BizException(400, "mock 通知 body 为空");
        }

        @SuppressWarnings("unchecked")
        Map<String, Object> map;
        try {
            map = com.fasterxml.jackson.databind.json.JsonMapper.builder().build()
                    .readValue(body, Map.class);
        } catch (Exception e) {
            throw new BizException(400, "mock 通知 body JSON 解析失败");
        }

        Object orderNoObj = map.get("orderNo");
        Object tradeStateObj = map.get("tradeState");
        Object transactionIdObj = map.get("transactionId");
        if (orderNoObj == null || tradeStateObj == null || transactionIdObj == null) {
            throw new BizException(400, "mock 通知缺少 orderNo/tradeState/transactionId 字段");
        }

        Long orderNo = ((Number) orderNoObj).longValue();
        String tradeState = String.valueOf(tradeStateObj);
        String transactionId = String.valueOf(transactionIdObj);

        notifyService.handleNotification(orderNo, tradeState, transactionId, body);
    }
}

