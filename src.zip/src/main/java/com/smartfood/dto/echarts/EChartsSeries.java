package com.smartfood.dto.echarts;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

/**
 * ECharts series 结构。
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class EChartsSeries {
    private String name;
    private String type; // 例如：bar/line/pie
    private List<? extends Number> data;
}

