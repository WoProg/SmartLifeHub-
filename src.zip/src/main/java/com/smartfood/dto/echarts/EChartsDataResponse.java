package com.smartfood.dto.echarts;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

/**
 * 统一的 ECharts 响应结构。
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class EChartsDataResponse {

    /**
     * x 轴类目。
     */
    private List<String> xAxis;

    /**
     * series 数组。
     */
    private List<EChartsSeries> series;
}

