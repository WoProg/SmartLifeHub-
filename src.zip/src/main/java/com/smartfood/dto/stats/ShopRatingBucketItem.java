package com.smartfood.dto.stats;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * 店铺评分分布桶。
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class ShopRatingBucketItem {
    private Integer bucket;
    private Long count;
}

