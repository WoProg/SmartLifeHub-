package com.smartfood.dto.stats;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * 热门菜品 TOP10 单项。
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class TopDishItem {
    private Long dishId;
    private String dishName;
    private Long quantity;
}

