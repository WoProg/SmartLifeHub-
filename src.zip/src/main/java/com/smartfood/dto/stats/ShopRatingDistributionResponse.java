package com.smartfood.dto.stats;

import com.smartfood.dto.echarts.EChartsDataResponse;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

/**
 * 店铺评分分布返回体：
 * - items：bucket/count 明细
 * - chart：ECharts 数据
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class ShopRatingDistributionResponse {
    private List<ShopRatingBucketItem> items;
    private EChartsDataResponse chart;
}

