package com.smartfood.dto.stats;

import com.smartfood.dto.echarts.EChartsDataResponse;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

/**
 * 热门菜品 TOP10 返回体：
 * - items：明细列表
 * - chart：ECharts 数据
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class TopDishResponse {
    private List<TopDishItem> items;
    private EChartsDataResponse chart;
}

