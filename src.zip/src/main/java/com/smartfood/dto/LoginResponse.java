package com.smartfood.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * 登录返回参数：
 * - token：JWT token
 * - user：脱敏后的用户信息
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Schema(description = "登录响应")
public class LoginResponse {

    /**
     * JWT token。
     */
    @Schema(description = "JWT token", example = "eyJhbGciOiJIUzI1NiJ9...")
    private String token;

    /**
     * 用户信息（脱敏）。
     */
    @Schema(description = "用户信息（脱敏）")
    private UserResponse user;
}

