package com.smartfood.dto.uv;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * 新老 UV 返回。
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class UvNewOldResponse {
    private Long newUv;
    private Long oldUv;
}

