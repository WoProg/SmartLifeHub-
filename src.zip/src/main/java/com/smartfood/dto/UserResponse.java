package com.smartfood.dto;

import com.smartfood.entity.User;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import io.swagger.v3.oas.annotations.media.Schema;

import java.time.LocalDate;
import java.time.LocalDateTime;

/**
 * 用户信息响应 DTO（脱敏，不返回密码）。
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Schema(description = "用户信息响应")
public class UserResponse {

    @Schema(description = "用户 id", example = "1")
    private Long id;

    @Schema(description = "手机号", example = "13812345678")
    private String phone;

    @Schema(description = "昵称", example = "张三")
    private String nickname;

    @Schema(description = "头像地址", example = "https://xxx.com/avatar.png")
    private String avatar;

    /**
     * 性别 code：0/1/2（UNKNOWN/MALE/FEMALE）
     */
    @Schema(description = "性别 code：0/1/2", example = "1")
    private Integer gender;

    @Schema(description = "生日", example = "1998-01-01")
    private LocalDate birthDay;

    /**
     * 用户状态 code：0/1（NORMAL/DISABLED）
     */
    @Schema(description = "用户状态 code：0/1", example = "0")
    private Integer status;

    @Schema(description = "用户等级", example = "0")
    private Integer userLevel;

    @Schema(description = "最近登录时间")
    private LocalDateTime lastLoginTime;

    @Schema(description = "创建时间")
    private LocalDateTime createTime;

    @Schema(description = "更新时间")
    private LocalDateTime updateTime;

    /**
     * 从实体转换为响应对象（脱敏：不返回密码）。
     *
     * @param user User 实体
     * @return UserResponse
     */
    public static UserResponse fromUser(User user) {
        if (user == null) {
            return null;
        }

        return UserResponse.builder()
                .id(user.getId())
                .phone(user.getPhone())
                .nickname(user.getNickname())
                .avatar(user.getAvatar())
                .gender(user.getGender() == null ? null : user.getGender().ordinal())
                .birthDay(user.getBirthDay())
                .status(user.getStatus() == null ? null : user.getStatus().ordinal())
                .userLevel(user.getUserLevel())
                .lastLoginTime(user.getLastLoginTime())
                .createTime(user.getCreateTime())
                .updateTime(user.getUpdateTime())
                .build();
    }
}

