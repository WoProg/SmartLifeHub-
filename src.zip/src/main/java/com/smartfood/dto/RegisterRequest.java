package com.smartfood.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

import javax.validation.constraints.*;
import java.time.LocalDate;

/**
 * 用户注册请求参数。
 */
@Data
@Schema(description = "用户注册请求参数")
public class RegisterRequest {

    /**
     * 手机号：用于注册与登录。
     * 约定：11 位大陆手机号（你可后续按地区扩展）。
     */
    @NotBlank(message = "手机号不能为空")
    @Pattern(regexp = "^1[3-9]\\d{9}$", message = "手机号格式不正确")
    @Schema(description = "手机号（必填，11位）", example = "13812345678")
    private String phone;

    /**
     * 密码：建议至少 6 位。
     */
    @NotBlank(message = "密码不能为空")
    @Size(min = 6, max = 50, message = "密码长度需在 6~50 之间")
    @Schema(description = "密码（必填）", example = "123456")
    private String password;

    /**
     * 昵称：前端展示用。
     */
    @NotBlank(message = "昵称不能为空")
    @Size(max = 50, message = "昵称最多 50 字符")
    @Schema(description = "昵称（必填）", example = "张三")
    private String nickname;

    /**
     * 头像地址（可选）。
     */
    @Schema(description = "头像地址（可选）", example = "https://xxx.com/avatar.png")
    private String avatar;

    /**
     * 性别 code（可选）：
     * - 0：UNKNOWN
     * - 1：MALE
     * - 2：FEMALE
     */
    @Min(value = 0, message = "性别code最小为0")
    @Max(value = 2, message = "性别code最大为2")
    @Schema(description = "性别 code（可选，0/1/2）", example = "1")
    private Integer gender;

    /**
     * 生日（可选）。
     * 注意：Day1 仅校验“不得晚于今天”（可按需要调整）。
     */
    @PastOrPresent(message = "生日不能晚于今天")
    @Schema(description = "生日（可选，YYYY-MM-DD）", example = "1998-01-01")
    private LocalDate birthDay;
}

