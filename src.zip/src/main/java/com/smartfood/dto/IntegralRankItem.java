package com.smartfood.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * 积分排行榜单项。
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class IntegralRankItem {
    private Long userId;
    private Double points;
}

