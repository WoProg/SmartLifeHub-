package com.smartfood.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * 附近店铺查询返回对象（距离用于前端展示）。
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class NearbyShopResponse {
    private Long shopId;
    /**
     * 距离（单位：km，便于展示；也可扩展为米）
     */
    private Double distanceKm;

    private ShopResponse shop;
}

