package com.smartfood.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

/**
 * 本月签到情况。
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class SignMonthResponse {
    private String yyyyMM;
    private int continuousDays;
    /**
     * 本月已签到的日期列表（1..当月天数）。
     */
    private List<Integer> signedDays;
}

