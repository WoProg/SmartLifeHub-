package com.smartfood.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Positive;
import java.math.BigDecimal;

/**
 * 店铺信息更新请求参数（用于演示：更新后删除 Redis 缓存）。
 */
@Data
@Schema(description = "店铺信息更新请求参数")
public class UpdateShopRequest {

    @NotBlank(message = "店铺名称不能为空")
    private String name;

    @NotBlank(message = "店铺地址不能为空")
    private String address;

    /**
     * ShopType ordinal code。
     */
    @NotNull(message = "店铺类型不能为空")
    private Integer shopType;

    @NotNull(message = "经度不能为空")
    private BigDecimal longitude;

    @NotNull(message = "纬度不能为空")
    private BigDecimal latitude;

    /**
     * ShopStatus ordinal code。
     */
    @NotNull(message = "营业状态不能为空")
    private Integer businessStatus;

    @NotNull(message = "评分不能为空")
    private BigDecimal rating;

    @NotNull(message = "配送费不能为空")
    private BigDecimal deliveryFee;

    @NotNull(message = "最低起送价不能为空")
    private BigDecimal minOrderAmount;

    private String openTime;
    private String closeTime;

    @NotNull(message = "销量统计不能为空")
    @Positive(message = "销量必须为正数")
    private Integer salesCount;
}

