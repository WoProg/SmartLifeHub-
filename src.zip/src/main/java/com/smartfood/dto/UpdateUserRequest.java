package com.smartfood.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.PastOrPresent;
import javax.validation.constraints.Size;
import javax.validation.constraints.NotNull;
import java.time.LocalDate;

/**
 * 用户信息更新请求参数。
 *
 * 安全策略（Day1）：
 * - 不允许通过该接口修改手机号、密码
 * - 仅允许更新昵称、头像、性别、生日等非敏感信息
 */
@Data
@Schema(description = "用户信息更新请求参数")
public class UpdateUserRequest {

    /**
     * 用户 id（必填）。
     */
    @NotNull(message = "用户 id不能为空")
    @Min(value = 1, message = "用户 id 非法")
    @Schema(description = "用户 id", example = "1")
    private Long id;

    /**
     * 昵称（可选）。
     */
    @Size(max = 50, message = "昵称最多 50 字符")
    @Schema(description = "昵称（可选）", example = "王五")
    private String nickname;

    /**
     * 头像地址（可选）。
     */
    @Schema(description = "头像地址（可选）", example = "https://xxx.com/new.png")
    private String avatar;

    /**
     * 性别 code（可选）。
     * 0=UNKNOWN, 1=MALE, 2=FEMALE
     */
    @Min(value = 0, message = "性别code最小为0")
    @Max(value = 2, message = "性别code最大为2")
    @Schema(description = "性别 code（可选，0/1/2）", example = "2")
    private Integer gender;

    /**
     * 生日（可选）。
     */
    @PastOrPresent(message = "生日不能晚于今天")
    @Schema(description = "生日（可选，YYYY-MM-DD）", example = "1999-05-01")
    private LocalDate birthDay;
}

