package com.smartfood.dto;

import com.smartfood.entity.Shop;
import com.smartfood.entity.ShopStatus;
import com.smartfood.entity.ShopType;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import io.swagger.v3.oas.annotations.media.Schema;

import java.math.BigDecimal;

/**
 * 店铺信息响应 DTO（缓存与接口返回用）。
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Schema(description = "店铺信息响应")
public class ShopResponse {

    private Long id;
    private String name;

    /**
     * 店铺类型 code：与 ShopType ordinal 对齐。
     */
    private Integer shopType;

    private String address;
    private BigDecimal longitude;
    private BigDecimal latitude;

    /**
     * 营业状态 code：与 ShopStatus ordinal 对齐。
     */
    private Integer businessStatus;

    private BigDecimal rating;
    private BigDecimal deliveryFee;
    private BigDecimal minOrderAmount;

    private String openTime;
    private String closeTime;

    private Integer salesCount;

    public static ShopResponse fromShop(Shop shop) {
        if (shop == null) {
            return null;
        }

        ShopStatus business = shop.getBusinessStatus();
        ShopType type = shop.getShopType();

        return ShopResponse.builder()
                .id(shop.getId())
                .name(shop.getName())
                .shopType(type == null ? null : type.ordinal())
                .address(shop.getAddress())
                .longitude(shop.getLongitude())
                .latitude(shop.getLatitude())
                .businessStatus(business == null ? null : business.ordinal())
                .rating(shop.getRating())
                .deliveryFee(shop.getDeliveryFee())
                .minOrderAmount(shop.getMinOrderAmount())
                .openTime(shop.getOpenTime())
                .closeTime(shop.getCloseTime())
                .salesCount(shop.getSalesCount())
                .build();
    }
}

