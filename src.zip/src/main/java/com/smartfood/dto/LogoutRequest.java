package com.smartfood.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

import javax.validation.constraints.NotBlank;

/**
 * 退出登录请求参数。
 *
 * Day1 做法：
 * - 前端/客户端把 token 传给后端
 * - 后端校验 token 是否有效并返回“退出成功”
 *
 * 后续你可以接入 Redis 黑名单或鉴权过滤器真正让 token 失效。
 */
@Data
@Schema(description = "退出登录请求参数")
public class LogoutRequest {

    /**
     * token（可直接传 Bearer 后缀内容或完整 Bearer 字符串）。
     */
    @NotBlank(message = "token不能为空")
    @Schema(description = "token", example = "eyJhbGciOiJIUzI1NiJ9...")
    private String token;
}

