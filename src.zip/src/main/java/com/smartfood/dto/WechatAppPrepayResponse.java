package com.smartfood.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * APP 微信支付预支付响应（用于前端调起支付）。
 *
 * 对齐 wechatpay-java 的 PrepayWithRequestPaymentResponse 字段：
 * prepay_id / appid / partnerid / package / noncestr / timestamp / sign
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Schema(description = "微信 APP 支付预支付参数")
public class WechatAppPrepayResponse {

    @Schema(description = "预支付交易会话标识 prepay_id", example = "wx_mock_prepay_123456")
    private String prepayId;

    @Schema(description = "公众账号 appid", example = "wx1234567890abcdef")
    private String appid;

    @Schema(description = "商户号 partnerid / mchid", example = "1900000109")
    private String partnerId;

    @Schema(description = "扩展字段 package（通常为 Sign=WXPay）", example = "Sign=WXPay")
    private String packageValue;

    @Schema(description = "随机串 nonce_str", example = "nonce_str")
    private String nonceStr;

    @Schema(description = "时间戳 time_stamp（字符串）", example = "1700000000")
    private String timeStamp;

    @Schema(description = "签名 sign（V3 APP 调起参数签名）", example = "mock_sign")
    private String sign;
}

