package com.smartfood.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * 签到返回参数。
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class SignResponse {
    /**
     * 连续签到天数。
     */
    private int continuousDays;

    /**
     * 本次签到新增积分。
     */
    private int pointsAdded;

    /**
     * 当前用户累计积分。
     */
    private long totalPoints;
}

