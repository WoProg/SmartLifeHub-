package com.smartfood.service;

/**
 * 订单状态机服务。
 *
 * 负责所有“状态变更”的前置校验与幂等控制，确保并发/重复请求不会把订单推进到非法状态。
 */
public interface OrderStateMachineService {

    /**
     * 商家接单：待付款 -> 待接单
     *
     * 前置条件：
     * - 订单状态为待付款
     * - 支付状态已支付
     * - order.shop_id 必须与 merchantShopId 一致
     *
     * 权限要求：
     * - 调用方角色必须为 MERCHANT
     */
    void merchantAccept(Long orderNo, Long merchantShopId, Long merchantOperatorId);

    /**
     * 商家开始制作：待接单 -> 制作中
     */
    void merchantStartMake(Long orderNo, Long merchantShopId, Long merchantOperatorId);

    /**
     * 商家开始配送准备：制作中 -> 待配送
     */
    void merchantStartDelivery(Long orderNo, Long merchantShopId, Long merchantOperatorId);

    /**
     * 骑手开始配送：待配送 -> 配送中
     */
    void riderStartDelivery(Long orderNo, Long riderOperatorId);

    /**
     * 用户确认收货：配送中 -> 已完成
     * 权限要求：一般应要求用户身份，但 Day1 可先不绑定 userId（以便先跑通主链路）。
     */
    void confirmReceipt(Long orderNo, Long userOperatorId);

    /**
     * 用户取消订单：仅允许待付款且未支付时取消
     */
    void cancelByUser(Long orderNo, Long userOperatorId);
}

