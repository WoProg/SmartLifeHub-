package com.smartfood.service;

import com.smartfood.dto.echarts.EChartsDataResponse;
import com.smartfood.dto.stats.ShopRatingDistributionResponse;
import com.smartfood.dto.stats.TopDishResponse;
import com.smartfood.statistics.StatisticsRange;

/**
 * 数据统计服务：读 Redis 缓存 + 未命中回源聚合。
 */
public interface StatisticsService {

    EChartsDataResponse getRevenueECharts(StatisticsRange range);

    EChartsDataResponse getUsersECharts(StatisticsRange range);

    EChartsDataResponse getOrdersECharts(StatisticsRange range);

    TopDishResponse getTopDishes(StatisticsRange range);

    ShopRatingDistributionResponse getShopRatingDistribution(StatisticsRange range);
}

