package com.smartfood.service.impl;

import com.smartfood.dto.ShopResponse;
import com.smartfood.dto.UpdateShopRequest;
import com.smartfood.entity.Shop;
import com.smartfood.exception.BizException;
import com.smartfood.lock.RedisLockService;
import com.smartfood.geo.ShopGeoService;
import com.smartfood.mapper.ShopMapper;
import com.smartfood.service.ShopService;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.RequiredArgsConstructor;
import org.springframework.data.redis.RedisConnectionFailureException;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.stereotype.Service;

import javax.annotation.PostConstruct;
import java.time.Duration;
import java.util.List;
import java.util.UUID;

/**
 * 店铺缓存实现：
 * - 空对象缓存防穿透
 * - 互斥锁防击穿
 * - 热门店铺预热
 * - Redis 挂掉降级查库
 */
@Service
@RequiredArgsConstructor
public class ShopServiceImpl implements ShopService {

    private static final Duration SHOP_CACHE_TTL = Duration.ofMinutes(30);

    // 防穿透：空对象占位符 TTL 可短一些
    private static final Duration SHOP_NULL_TTL = Duration.ofMinutes(2);

    private static final String SHOP_KEY_PREFIX = "shop:";
    private static final String SHOP_LOCK_PREFIX = "lock:shop:";

    private static final int DEFAULT_PREHEAT_LIMIT = 5;

    private final ShopMapper shopMapper;
    private final StringRedisTemplate stringRedisTemplate;
    private final ObjectMapper objectMapper;
    private final RedisLockService redisLockService;
    private final ShopGeoService shopGeoService;

    @PostConstruct
    public void preheatPopularShops() {
        try {
            List<Shop> shops = shopMapper.selectPopularShops(DEFAULT_PREHEAT_LIMIT);
            for (Shop shop : shops) {
                cacheShop(shop);
                shopGeoService.addShopPoint(shop.getId(), shop.getLongitude(), shop.getLatitude());
            }
        } catch (Exception ignored) {
            // 预热失败不影响主功能（后续用“Redis挂掉降级查库”兜底）
        }
    }

    @Override
    public ShopResponse getById(Long id) {
        if (id == null || id <= 0) {
            throw new BizException(400, "店铺 id 非法");
        }

        String redisKey = shopKey(id);
        String json = null;
        try {
            json = stringRedisTemplate.opsForValue().get(redisKey);
            if (json != null) {
                if (isNullPlaceholder(json)) {
                    return null;
                }
                return readShopResponse(json);
            }

            // 空对象未命中（即 redisKey 不存在）：加互斥锁防击穿
            String lockKey = SHOP_LOCK_PREFIX + id;
            String token = UUID.randomUUID().toString();
            boolean locked = redisLockService.tryLock(lockKey, token, Duration.ofSeconds(10));
            if (!locked) {
                // 获取不到锁：短暂等待后再查一次
                Thread.sleep(50);
                String retryJson = stringRedisTemplate.opsForValue().get(redisKey);
                if (retryJson != null && !isNullPlaceholder(retryJson)) {
                    return readShopResponse(retryJson);
                }
                return null;
            }

            try {
                // 双重检查
                String jsonAgain = stringRedisTemplate.opsForValue().get(redisKey);
                if (jsonAgain != null) {
                    if (isNullPlaceholder(jsonAgain)) {
                        return null;
                    }
                    return readShopResponse(jsonAgain);
                }

                // 回源数据库
                Shop shop = shopMapper.selectByShopId(id);
                if (shop == null) {
                    // 缓存空对象防穿透
                    stringRedisTemplate.opsForValue().set(redisKey, "1", SHOP_NULL_TTL);
                    return null;
                }

                cacheShop(shop);
                return ShopResponse.fromShop(shop);
            } finally {
                redisLockService.unlock(lockKey, token);
            }
        } catch (RedisConnectionFailureException e) {
            // Redis 挂掉降级查库
            Shop shop = shopMapper.selectByShopId(id);
            return ShopResponse.fromShop(shop);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            return null;
        }
    }

    @Override
    public void updateShop(Long id, UpdateShopRequest request) {
        if (id == null || id <= 0) {
            throw new BizException(400, "店铺 id 非法");
        }
        if (request == null) {
            throw new BizException(400, "更新参数不能为空");
        }

        int updated = shopMapper.updateShopById(
                id,
                request.getName(),
                request.getAddress(),
                request.getShopType(),
                request.getLongitude(),
                request.getLatitude(),
                request.getBusinessStatus(),
                request.getRating(),
                request.getDeliveryFee(),
                request.getMinOrderAmount(),
                request.getOpenTime(),
                request.getCloseTime(),
                request.getSalesCount()
        );

        if (updated != 1) {
            throw new BizException(404, "店铺不存在或未更新");
        }

        // 删除缓存：确保下次查询回源数据库
        try {
            stringRedisTemplate.delete(redisKey(id));
        } catch (RedisConnectionFailureException e) {
            // Redis 不可用：忽略，最终一致性由缓存 TTL 兜底
        }

        // 同步 GEO：更新坐标索引
        if (request.getLongitude() != null && request.getLatitude() != null) {
            shopGeoService.addShopPoint(id, request.getLongitude(), request.getLatitude());
        }
    }

    private void cacheShop(Shop shop) {
        if (shop == null) {
            return;
        }

        try {
            ShopResponse response = ShopResponse.fromShop(shop);
            String json = objectMapper.writeValueAsString(response);
            stringRedisTemplate.opsForValue().set(redisKey(shop.getId()), json, SHOP_CACHE_TTL);
        } catch (JsonProcessingException e) {
            // 序列化失败不影响主流程
        } catch (RedisConnectionFailureException e) {
            // Redis 不可用时不缓存
        }
    }

    private ShopResponse readShopResponse(String json) {
        try {
            return objectMapper.readValue(json, ShopResponse.class);
        } catch (Exception e) {
            throw new BizException(500, "店铺缓存数据反序列化失败");
        }
    }

    private boolean isNullPlaceholder(String json) {
        return "1".equals(json);
    }

    private String redisKey(Long id) {
        return SHOP_KEY_PREFIX + id;
    }

    private String shopKey(Long id) {
        return redisKey(id);
    }
}

