package com.smartfood.service.impl;

import com.smartfood.dto.IntegralRankItem;
import com.smartfood.dto.IntegralRankResponse;
import com.smartfood.dto.SignMonthResponse;
import com.smartfood.dto.SignResponse;
import com.smartfood.exception.BizException;
import com.smartfood.service.SignService;
import lombok.RequiredArgsConstructor;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

/**
 * 使用 Redis 位图实现：
 * - 签到：SETBIT
 * - 连续签到计算：从当日往回 GETBIT 直到遇到 0
 * - 积分：签到积分=连续签到天数，写入 points:{userId} 并更新 integral:rank
 */
@Service
@RequiredArgsConstructor
public class SignServiceImpl implements SignService {

    private static final String SIGN_KEY_PREFIX = "sign:";
    private static final String POINTS_KEY_PREFIX = "points:";
    private static final String INTEGRAL_RANK_KEY = "integral:rank";

    private final StringRedisTemplate stringRedisTemplate;

    @Override
    public SignResponse sign(Long userId) {
        if (userId == null || userId <= 0) {
            throw new BizException(400, "userId 非法");
        }

        LocalDate now = LocalDate.now();
        String yyyyMM = now.format(DateTimeFormatter.ofPattern("yyyyMM"));
        int dayOfMonth = now.getDayOfMonth();

        String signKey = signKey(userId, yyyyMM);
        long offset = dayOfMonth - 1L;

        Boolean already = stringRedisTemplate.opsForValue().getBit(signKey, offset);
        if (Boolean.TRUE.equals(already)) {
            int continuousDays = calcContinuousDaysFromEnd(signKey, dayOfMonth);
            long totalPoints = getPoints(userId);
            return SignResponse.builder()
                    .continuousDays(continuousDays)
                    .pointsAdded(0)
                    .totalPoints(totalPoints)
                    .build();
        }

        // SETBIT 当日为 1
        stringRedisTemplate.opsForValue().setBit(signKey, offset, true);

        int continuousDays = calcContinuousDaysFromEnd(signKey, dayOfMonth);

        // 签到得积分：第一天 1 分，连续递增（continuousDays 本身就是递增结果）
        int pointsAdded = continuousDays;
        long totalPoints = stringRedisTemplate.opsForValue().increment(pointsKey(userId), pointsAdded);

        // 积分排行榜（ZSET）
        stringRedisTemplate.opsForZSet().add(
                INTEGRAL_RANK_KEY,
                String.valueOf(userId),
                (double) totalPoints
        );

        return SignResponse.builder()
                .continuousDays(continuousDays)
                .pointsAdded(pointsAdded)
                .totalPoints(totalPoints)
                .build();
    }

    @Override
    public SignMonthResponse getMonthSign(Long userId) {
        if (userId == null || userId <= 0) {
            throw new BizException(400, "userId 非法");
        }

        LocalDate now = LocalDate.now();
        String yyyyMM = now.format(DateTimeFormatter.ofPattern("yyyyMM"));
        int dayOfMonth = now.getDayOfMonth();

        String signKey = signKey(userId, yyyyMM);

        List<Integer> signedDays = new ArrayList<>();
        for (int day = 1; day <= dayOfMonth; day++) {
            long offset = day - 1L;
            Boolean bit = stringRedisTemplate.opsForValue().getBit(signKey, offset);
            if (Boolean.TRUE.equals(bit)) {
                signedDays.add(day);
            }
        }

        int continuousDays = calcContinuousDaysFromEnd(signKey, dayOfMonth);
        return SignMonthResponse.builder()
                .yyyyMM(yyyyMM)
                .continuousDays(continuousDays)
                .signedDays(signedDays)
                .build();
    }

    @Override
    public IntegralRankResponse getIntegralRank(int limit) {
        if (limit <= 0) {
            throw new BizException(400, "limit 非法");
        }

        var tuples = stringRedisTemplate.opsForZSet().reverseRangeWithScores(INTEGRAL_RANK_KEY, 0, limit - 1);
        List<IntegralRankItem> items = new ArrayList<>();
        if (tuples != null) {
            for (var t : tuples) {
                Long rankUserId = Long.valueOf(t.getValue());
                double points = t.getScore();
                items.add(IntegralRankItem.builder()
                        .userId(rankUserId)
                        .points(points)
                        .build());
            }
        }

        return IntegralRankResponse.builder()
                .items(items)
                .build();
    }

    private int calcContinuousDaysFromEnd(String signKey, int dayOfMonth) {
        int count = 0;
        for (int day = dayOfMonth; day >= 1; day--) {
            long offset = day - 1L;
            Boolean bit = stringRedisTemplate.opsForValue().getBit(signKey, offset);
            if (Boolean.TRUE.equals(bit)) {
                count++;
            } else {
                break;
            }
        }
        return count;
    }

    private long getPoints(Long userId) {
        String val = stringRedisTemplate.opsForValue().get(pointsKey(userId));
        if (val == null || val.isBlank()) {
            return 0L;
        }
        return Long.parseLong(val);
    }

    private String signKey(Long userId, String yyyyMM) {
        return SIGN_KEY_PREFIX + userId + ":" + yyyyMM;
    }

    private String pointsKey(Long userId) {
        return POINTS_KEY_PREFIX + userId;
    }
}

