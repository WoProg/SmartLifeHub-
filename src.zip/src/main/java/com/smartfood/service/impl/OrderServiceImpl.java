package com.smartfood.service.impl;

import com.smartfood.config.properties.OrderCancelTimeoutProperties;
import com.smartfood.dto.LoginResponse;
import com.smartfood.entity.*;
import com.smartfood.exception.BizException;
import com.smartfood.id.SnowflakeIdWorker;
import com.smartfood.lock.RedisLockService;
import com.smartfood.mapper.CartMapper;
import com.smartfood.mapper.DishMapper;
import com.smartfood.mapper.OrderDetailMapper;
import com.smartfood.mapper.OrderMapper;
import com.smartfood.service.OrderService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.CollectionUtils;

import java.math.BigDecimal;
import java.time.Instant;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.*;
import java.util.stream.Collectors;

/**
 * OrderServiceImpl：实现下单主流程。
 *
 * Day1 要点（严格对齐你的描述）：
 * - @Transactional 保证订单/明细/库存/购物车清空的一致性
 * - Redis 分布式锁防止重复提交
 * - 校验库存与价格（通过条件扣库存避免并发超卖）
 * - 订单超时取消：写 Redis 延迟队列（纯 Redis）
 */
@Slf4j
@Service
@RequiredArgsConstructor
public class OrderServiceImpl implements OrderService {

    private final OrderMapper orderMapper;
    private final OrderDetailMapper orderDetailMapper;
    private final CartMapper cartMapper;
    private final DishMapper dishMapper;
    private final SnowflakeIdWorker snowflakeIdWorker;
    private final RedisLockService redisLockService;
    private final StringRedisTemplate stringRedisTemplate;
    private final OrderCancelTimeoutProperties orderCancelTimeoutProperties;

    /**
     * Redis 延迟队列 key（待取消 due）。
     */
    private static final String CANCEL_DUE_ZSET = "orders:cancel:due";
    /**
     * Redis 延迟队列 key（处理中 processing）。
     */
    private static final String CANCEL_PROCESSING_ZSET = "orders:cancel:processing";
    /**
     * Redis 租约 Hash（用于避免 worker crash 后多次处理）。
     */
    private static final String CANCEL_LEASE_HASH = "orders:cancel:lease";
    /**
     * Redis Meta Hash（记录每个 orderNo 的 cancelAtMs，便于重入）。
     */
    private static final String CANCEL_META_HASH = "orders:cancel:meta";

    @Override
    @Transactional
    public long createOrderFromCart(Long userId) {
        if (userId == null || userId <= 0) {
            throw new BizException(400, "用户 id 非法");
        }

        // 1) 分布式锁：防止同一用户重复下单
        String lockKey = "lock:order:submit:" + userId;
        String token = UUID.randomUUID().toString();
        // 锁 TTL：给事务/网络留足余量（15 分钟超时取消不影响这里）
        boolean locked = redisLockService.tryLock(lockKey, token, java.time.Duration.ofSeconds(30));
        if (!locked) {
            throw new BizException(429, "订单正在创建中，请勿重复提交");
        }

        try {
            // 2) 从购物车读取选中项
            List<CartItem> selectedItems = cartMapper.selectSelectedByUserId(userId);
            if (CollectionUtils.isEmpty(selectedItems)) {
                throw new BizException(400, "购物车为空或没有选中商品");
            }

            // 3) 组装菜品 id 集合（批量查询价格/库存/状态）
            List<Long> dishIds = selectedItems.stream()
                    .map(CartItem::getDishId)
                    .distinct()
                    .collect(Collectors.toList());

            // 4) 批量查询菜品（校验上架状态与价格）
            List<Dish> dishes = dishMapper.selectByIds(dishIds);
            Map<Long, Dish> dishMap = dishes.stream()
                    .collect(Collectors.toMap(Dish::getId, d -> d, (a, b) -> a));

            // 5) 计算订单金额并校验每个条目
            LocalDateTime now = LocalDateTime.now();
            long nowMs = System.currentTimeMillis();
            long cancelAtMs = nowMs + orderCancelTimeoutProperties.getMinutes() * 60_000L;
            LocalDateTime cancelAt = LocalDateTime.ofInstant(Instant.ofEpochMilli(cancelAtMs), ZoneId.systemDefault());

            BigDecimal totalAmount = BigDecimal.ZERO;
            // 用于后续扣库存（需要 dishId -> quantity）
            Map<Long, Integer> totalQtyByDishId = new HashMap<>();

            for (CartItem item : selectedItems) {
                Dish dish = dishMap.get(item.getDishId());
                if (dish == null) {
                    throw new BizException(400, "菜品不存在：dishId=" + item.getDishId());
                }
                if (dish.getStatus() != DishStatus.ON_SALE) {
                    throw new BizException(409, "菜品已下架或不可购买：dishId=" + dish.getId());
                }
                if (dish.getPrice() == null) {
                    throw new BizException(500, "菜品价格异常：dishId=" + dish.getId());
                }

                BigDecimal lineAmount = dish.getPrice().multiply(BigDecimal.valueOf(item.getQuantity()));
                totalAmount = totalAmount.add(lineAmount);

                // 汇总数量，方便后续批量扣减（这里先简单累加）
                totalQtyByDishId.merge(item.getDishId(), item.getQuantity(), Integer::sum);
            }

            if (totalAmount.compareTo(BigDecimal.ZERO) <= 0) {
                throw new BizException(400, "订单金额异常");
            }

            // 6) 生成订单号（雪花算法）
            long orderNo = snowflakeIdWorker.nextId();

            // 7) 从菜品推断店铺 id（Day1 假设同一用户选中项属于同一家店）
            // 由于 Dish 表存在 shopId 字段，我们可直接读取
            Long shopId = selectedItems.stream()
                    .findFirst()
                    .map(CartItem::getDishId)
                    .map(dishMap::get)
                    .map(Dish::getShopId)
                    .orElseThrow(() -> new BizException(500, "无法推断店铺信息"));

            // 8) 写入订单主表
            Order order = Order.builder()
                    .orderNo(orderNo)
                    .userId(userId)
                    .shopId(shopId)
                    .totalAmount(totalAmount)
                    .status(OrderStatus.PENDING_PAYMENT)
                    .payMethod(PayMethod.WECHAT_APP)
                    .payStatus(PayStatus.NOT_PAID)
                    .wechatOutTradeNo(String.valueOf(orderNo))
                    .cancelAt(cancelAt)
                    .build();
            order.setCreateTime(now);
            order.setUpdateTime(now);
            orderMapper.insert(order);

            // 9) 写入订单明细
            for (CartItem item : selectedItems) {
                Dish dish = dishMap.get(item.getDishId());
                OrderDetail detail = OrderDetail.builder()
                        .orderNo(orderNo)
                        .dishId(item.getDishId())
                        .quantity(item.getQuantity())
                        .unitPrice(dish.getPrice())
                        .specJson(item.getSpecJson())
                        .build();
                detail.setCreateTime(now);
                detail.setUpdateTime(now);
                orderDetailMapper.insert(detail);
            }

            // 10) 条件扣减库存（防并发超卖）
            for (Map.Entry<Long, Integer> entry : totalQtyByDishId.entrySet()) {
                Long dishId = entry.getKey();
                Integer qty = entry.getValue();
                int updated = dishMapper.deductStock(dishId, qty, DishStatus.ON_SALE.ordinal());
                if (updated != 1) {
                    throw new BizException(409, "库存扣减失败，可能库存不足或已下架：dishId=" + dishId);
                }
            }

            // 11) 清空购物车选中项
            cartMapper.clearSelectedByUserId(userId);

            // 12) 写入 Redis 延迟取消队列（订单超时自动取消）
            // 这里不放入 transaction 的强一致闭包，因为 Redis 不在同一事务中；
            // 一般按“业务可以接受最终一致”处理。
            String orderNoStr = String.valueOf(orderNo);
            stringRedisTemplate.opsForZSet().add(CANCEL_DUE_ZSET, orderNoStr, cancelAtMs);
            // 元数据：记录 cancelAtMs 方便重入
            stringRedisTemplate.opsForHash().put(CANCEL_META_HASH, orderNoStr, String.valueOf(cancelAtMs));

            // 由于这是“新订单”，确保 processing/lease 里没有遗留（如果后续实现可重入，会需要）
            stringRedisTemplate.opsForZSet().remove(CANCEL_PROCESSING_ZSET, orderNoStr);
            stringRedisTemplate.opsForHash().delete(CANCEL_LEASE_HASH, orderNoStr);

            // 13) 返回订单号（后续跳转支付）
            log.info("订单创建成功：orderNo={}, userId={}, shopId={}, totalAmount={}", orderNo, userId, shopId, totalAmount);
            return orderNo;
        } finally {
            // 释放锁
            boolean unlocked = redisLockService.unlock(lockKey, token);
            if (!unlocked) {
                // 不影响业务结果，只记录日志
                log.warn("释放订单提交锁失败：lockKey={}, token={}", lockKey, token);
            }
        }
    }
}

