package com.smartfood.service.impl;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.smartfood.dto.echarts.EChartsDataResponse;
import com.smartfood.dto.echarts.EChartsSeries;
import com.smartfood.dto.stats.ShopRatingBucketItem;
import com.smartfood.dto.stats.ShopRatingDistributionResponse;
import com.smartfood.dto.stats.TopDishItem;
import com.smartfood.dto.stats.TopDishResponse;
import com.smartfood.entity.OrderStatus;
import com.smartfood.entity.PayStatus;
import com.smartfood.entity.Shop;
import com.smartfood.id.SnowflakeIdWorker;
import com.smartfood.mapper.DishMapper;
import com.smartfood.mapper.ShopMapper;
import com.smartfood.statistics.StatisticsRange;
import com.smartfood.service.StatisticsService;
import com.smartfood.exception.BizException;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.data.redis.RedisConnectionFailureException;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.stereotype.Service;
import org.springframework.util.StopWatch;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.sql.ResultSet;
import java.time.Duration;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.time.temporal.TemporalAdjusters;
import java.util.ArrayList;
import java.util.EnumMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import org.springframework.jdbc.core.RowMapper;

import javax.annotation.PostConstruct;

/**
 * 统计聚合实现：
 * - 每日基础数据缓存到 Redis（stat:daily:{yyyyMMdd}）
 * - 对外按 range 构建 ECharts，并对 range 结果做二级缓存
 * - top dishes / rating distribution 直接按 range 计算并缓存
 */
@Service
@RequiredArgsConstructor
@Slf4j
public class StatisticsServiceImpl implements StatisticsService {

    private static final DateTimeFormatter DAY_FMT = DateTimeFormatter.ofPattern("yyyyMMdd");
    private static final DateTimeFormatter DAY_LABEL_FMT = DateTimeFormatter.ofPattern("MM-dd");
    private static final DateTimeFormatter MONTH_LABEL_FMT = DateTimeFormatter.ofPattern("MM");

    // Redis daily: stat:daily:{yyyyMMdd}
    private static final String DAILY_KEY_PREFIX = "stat:daily:";
    private static final Duration DAILY_TTL = Duration.ofDays(10);

    // Redis range: stat:range:{metric}:{rangeKey}
    private static final String RANGE_KEY_PREFIX = "stat:range:";
    private static final Duration RANGE_TTL = Duration.ofDays(3);

    private static final String TOP_DISH_KEY_PREFIX = "stat:top-dishes:";
    private static final Duration TOP_DISH_TTL = Duration.ofDays(3);

    private static final String SHOP_RATING_KEY_PREFIX = "stat:shop-rating-dist:";
    private static final Duration SHOP_RATING_TTL = Duration.ofDays(3);

    private final JdbcTemplate jdbcTemplate;
    private final StringRedisTemplate stringRedisTemplate;
    private final ObjectMapper objectMapper;
    private final DishMapper dishMapper;
    private final ShopMapper shopMapper;

    @Override
    public EChartsDataResponse getRevenueECharts(StatisticsRange range) {
        StopWatch sw = new StopWatch("getRevenueECharts");
        sw.start();
        String rangeKey = toRangeKey(range);
        String redisKey = RANGE_KEY_PREFIX + "revenue:" + rangeKey;
        EChartsDataResponse cached = readCachedECharts(redisKey, EChartsDataResponse.class);
        if (cached != null) {
            sw.stop();
            log.info("getRevenueECharts cached: range={}, costMs={}", range, sw.getTotalTimeMillis());
            return cached;
        }

        RangeWindow window = rangeWindow(range);
        List<String> xAxis = new ArrayList<>();
        List<Number> data = new ArrayList<>();

        if (range == StatisticsRange.YEAR) {
            for (int month = 1; month <= 12; month++) {
                LocalDate monthStart = window.start.withDayOfMonth(1).withMonth(month);
                if (monthStart.isBefore(window.start) || monthStart.isAfter(window.endExclusive.minusDays(1))) {
                    continue;
                }
                LocalDate monthEndExclusive = monthStart.plusMonths(1);

                BigDecimal sum = BigDecimal.ZERO;
                LocalDate d = monthStart;
                while (!d.isEqual(monthEndExclusive) && d.isBefore(window.endExclusive)) {
                    DailyStat ds = getOrComputeDaily(d);
                    sum = sum.add(ds.revenue);
                    d = d.plusDays(1);
                }
                xAxis.add(monthStart.format(MONTH_LABEL_FMT));
                data.add(sum.doubleValue());
            }
        } else {
            LocalDate d = window.start;
            while (d.isBefore(window.endExclusive)) {
                DailyStat ds = getOrComputeDaily(d);
                xAxis.add(d.format(DAY_LABEL_FMT));
                data.add(ds.revenue.doubleValue());
                d = d.plusDays(1);
            }
        }

        EChartsDataResponse resp = EChartsDataResponse.builder()
                .xAxis(xAxis)
                .series(List.of(
                        EChartsSeries.builder()
                                .name("营业额")
                                .type("line")
                                .data(data)
                                .build()
                ))
                .build();

        writeCache(redisKey, resp, RANGE_TTL);
        sw.stop();
        log.info("getRevenueECharts computed: range={}, costMs={}", range, sw.getTotalTimeMillis());
        return resp;
    }

    @Override
    public EChartsDataResponse getUsersECharts(StatisticsRange range) {
        StopWatch sw = new StopWatch("getUsersECharts");
        sw.start();
        String rangeKey = toRangeKey(range);
        String redisKey = RANGE_KEY_PREFIX + "users:" + rangeKey;
        EChartsDataResponse cached = readCachedECharts(redisKey, EChartsDataResponse.class);
        if (cached != null) {
            sw.stop();
            log.info("getUsersECharts cached: range={}, costMs={}", range, sw.getTotalTimeMillis());
            return cached;
        }

        RangeWindow window = rangeWindow(range);
        List<String> xAxis = new ArrayList<>();
        List<Number> newUsers = new ArrayList<>();
        List<Number> activeUsers = new ArrayList<>();

        if (range == StatisticsRange.YEAR) {
            for (int month = 1; month <= 12; month++) {
                LocalDate monthStart = window.start.withDayOfMonth(1).withMonth(month);
                if (monthStart.isBefore(window.start) || monthStart.isAfter(window.endExclusive.minusDays(1))) {
                    continue;
                }
                LocalDate monthEndExclusive = monthStart.plusMonths(1);

                long newSum = 0;
                long activeSum = 0;
                LocalDate d = monthStart;
                while (!d.isEqual(monthEndExclusive) && d.isBefore(window.endExclusive)) {
                    DailyStat ds = getOrComputeDaily(d);
                    newSum += ds.newUsers;
                    // activeUsers 是“当天活跃去重的近口径”，无法严格做跨天去重合并，这里按天汇总展示趋势。
                    activeSum += ds.activeUsers;
                    d = d.plusDays(1);
                }
                xAxis.add(monthStart.format(MONTH_LABEL_FMT));
                newUsers.add(newSum);
                activeUsers.add(activeSum);
            }
        } else {
            LocalDate d = window.start;
            while (d.isBefore(window.endExclusive)) {
                DailyStat ds = getOrComputeDaily(d);
                xAxis.add(d.format(DAY_LABEL_FMT));
                newUsers.add(ds.newUsers);
                activeUsers.add(ds.activeUsers);
                d = d.plusDays(1);
            }
        }

        EChartsDataResponse resp = EChartsDataResponse.builder()
                .xAxis(xAxis)
                .series(List.of(
                        EChartsSeries.builder().name("新增用户").type("bar").data(newUsers).build(),
                        EChartsSeries.builder().name("活跃用户").type("bar").data(activeUsers).build()
                ))
                .build();

        writeCache(redisKey, resp, RANGE_TTL);
        sw.stop();
        log.info("getUsersECharts computed: range={}, costMs={}", range, sw.getTotalTimeMillis());
        return resp;
    }

    @Override
    public EChartsDataResponse getOrdersECharts(StatisticsRange range) {
        StopWatch sw = new StopWatch("getOrdersECharts");
        sw.start();
        String rangeKey = toRangeKey(range);
        String redisKey = RANGE_KEY_PREFIX + "orders:" + rangeKey;
        EChartsDataResponse cached = readCachedECharts(redisKey, EChartsDataResponse.class);
        if (cached != null) {
            sw.stop();
            log.info("getOrdersECharts cached: range={}, costMs={}", range, sw.getTotalTimeMillis());
            return cached;
        }

        RangeWindow window = rangeWindow(range);
        List<String> xAxis = new ArrayList<>();
        List<Number> totalOrders = new ArrayList<>();
        List<Number> completedOrders = new ArrayList<>();
        List<Number> completionRates = new ArrayList<>();
        List<Number> avgTickets = new ArrayList<>();

        if (range == StatisticsRange.YEAR) {
            for (int month = 1; month <= 12; month++) {
                LocalDate monthStart = window.start.withDayOfMonth(1).withMonth(month);
                if (monthStart.isBefore(window.start) || monthStart.isAfter(window.endExclusive.minusDays(1))) {
                    continue;
                }
                LocalDate monthEndExclusive = monthStart.plusMonths(1);

                long totalSum = 0;
                long completedSum = 0;
                BigDecimal revenueSum = BigDecimal.ZERO;
                LocalDate d = monthStart;
                while (!d.isEqual(monthEndExclusive) && d.isBefore(window.endExclusive)) {
                    DailyStat ds = getOrComputeDaily(d);
                    totalSum += ds.totalOrders;
                    completedSum += ds.completedOrders;
                    revenueSum = revenueSum.add(ds.revenue);
                    d = d.plusDays(1);
                }

                double completionRate = totalSum == 0 ? 0d : (completedSum * 100d / totalSum);
                BigDecimal avg = completedSum == 0 ? BigDecimal.ZERO : revenueSum.divide(BigDecimal.valueOf(completedSum), 2, RoundingMode.HALF_UP);

                xAxis.add(monthStart.format(MONTH_LABEL_FMT));
                totalOrders.add(totalSum);
                completedOrders.add(completedSum);
                completionRates.add(completionRate);
                avgTickets.add(avg.doubleValue());
            }
        } else {
            LocalDate d = window.start;
            while (d.isBefore(window.endExclusive)) {
                DailyStat ds = getOrComputeDaily(d);
                xAxis.add(d.format(DAY_LABEL_FMT));
                totalOrders.add(ds.totalOrders);
                completedOrders.add(ds.completedOrders);
                completionRates.add(ds.totalOrders == 0 ? 0d : (ds.completedOrders * 100d / ds.totalOrders));
                avgTickets.add(ds.completedOrders == 0 ? 0d : ds.revenue.divide(BigDecimal.valueOf(ds.completedOrders), 2, RoundingMode.HALF_UP).doubleValue());
                d = d.plusDays(1);
            }
        }

        EChartsDataResponse resp = EChartsDataResponse.builder()
                .xAxis(xAxis)
                .series(List.of(
                        EChartsSeries.builder().name("订单量").type("bar").data(totalOrders).build(),
                        EChartsSeries.builder().name("完成订单").type("bar").data(completedOrders).build(),
                        EChartsSeries.builder().name("完成率(%)").type("line").data(completionRates).build(),
                        EChartsSeries.builder().name("平均客单价").type("line").data(avgTickets).build()
                ))
                .build();

        writeCache(redisKey, resp, RANGE_TTL);
        sw.stop();
        log.info("getOrdersECharts computed: range={}, costMs={}", range, sw.getTotalTimeMillis());
        return resp;
    }

    @Override
    public TopDishResponse getTopDishes(StatisticsRange range) {
        StopWatch sw = new StopWatch("getTopDishes");
        sw.start();
        String rangeKey = toRangeKey(range);
        String redisKey = TOP_DISH_KEY_PREFIX + rangeKey;
        TopDishResponse cached = readCached(redisKey, TopDishResponse.class);
        if (cached != null) {
            sw.stop();
            log.info("getTopDishes cached: range={}, costMs={}", range, sw.getTotalTimeMillis());
            return cached;
        }

        RangeWindow window = rangeWindow(range);
        LocalDateTime start = window.start.atStartOfDay();
        LocalDateTime end = window.endExclusive.atStartOfDay();

        // 主查询：按 finish_at 统计完成且已支付订单里的菜品销量
        List<TopDishRow> rows = jdbcTemplate.query(
                "SELECT od.dish_id AS dish_id, d.name AS dish_name, SUM(od.quantity) AS qty " +
                        "FROM order_detail od " +
                        "JOIN `order` o ON od.order_no = o.order_no " +
                        "JOIN dish d ON od.dish_id = d.id " +
                        "WHERE o.status = ? AND o.pay_status = ? AND o.finish_at >= ? AND o.finish_at < ? " +
                        "GROUP BY od.dish_id, d.name " +
                        "ORDER BY qty DESC " +
                        "LIMIT 10",
                new Object[]{OrderStatus.COMPLETED.ordinal(), PayStatus.PAID.ordinal(), start, end},
                new RowMapper<TopDishRow>() {
                    @Override
                    public TopDishRow mapRow(ResultSet rs, int rowNum) throws java.sql.SQLException {
                        return new TopDishRow(
                                rs.getLong("dish_id"),
                                rs.getString("dish_name"),
                                rs.getLong("qty")
                        );
                    }
                }
        );

        List<TopDishItem> items = new ArrayList<>();
        List<String> xAxis = new ArrayList<>();
        List<Number> qtys = new ArrayList<>();
        for (TopDishRow r : rows) {
            items.add(TopDishItem.builder()
                    .dishId(r.dishId)
                    .dishName(r.dishName)
                    .quantity(r.qty)
                    .build());
            xAxis.add(r.dishName);
            qtys.add(r.qty);
        }

        EChartsDataResponse chart = EChartsDataResponse.builder()
                .xAxis(xAxis)
                .series(List.of(EChartsSeries.builder()
                        .name("销量")
                        .type("bar")
                        .data(qtys)
                        .build()))
                .build();

        TopDishResponse resp = TopDishResponse.builder()
                .items(items)
                .chart(chart)
                .build();

        writeCache(redisKey, resp, TOP_DISH_TTL);
        sw.stop();
        log.info("getTopDishes computed: range={}, costMs={}", range, sw.getTotalTimeMillis());
        return resp;
    }

    @Override
    public ShopRatingDistributionResponse getShopRatingDistribution(StatisticsRange range) {
        StopWatch sw = new StopWatch("getShopRatingDistribution");
        sw.start();
        // 当前 shop.rating 没有时间维度，这里按当前分布返回；仍按 rangeKey 做缓存以满足接口一致性。
        String rangeKey = toRangeKey(range);
        String redisKey = SHOP_RATING_KEY_PREFIX + rangeKey;
        ShopRatingDistributionResponse cached = readCached(redisKey, ShopRatingDistributionResponse.class);
        if (cached != null) {
            sw.stop();
            log.info("getShopRatingDistribution cached: range={}, costMs={}", range, sw.getTotalTimeMillis());
            return cached;
        }

        List<ShopRatingBucketItem> items = new ArrayList<>();
        List<Long> counts = new ArrayList<>();
        List<String> xAxis = new ArrayList<>();

        Map<Integer, Long> bucketToCnt = jdbcTemplate.query(
                "SELECT CAST(LEAST(5, GREATEST(0, ROUND(rating))) AS SIGNED) AS bucket, COUNT(*) AS cnt " +
                        "FROM shop GROUP BY bucket ORDER BY bucket",
                new Object[]{},
                new RowMapper<Map<Integer, Long>>() {
                    @Override
                    public Map<Integer, Long> mapRow(ResultSet rs, int rowNum) throws java.sql.SQLException {
                        return Map.of(rs.getInt("bucket"), rs.getLong("cnt"));
                    }
                }
        ).stream().reduce(new LinkedHashMap<>(), (acc, m) -> {
            acc.putAll(m);
            return acc;
        }, (a, b) -> a);

        for (int i = 0; i <= 5; i++) {
            long cnt = bucketToCnt.getOrDefault(i, 0L);
            items.add(ShopRatingBucketItem.builder().bucket(i).count(cnt).build());
            xAxis.add(String.valueOf(i));
            counts.add(cnt);
        }

        EChartsDataResponse chart = EChartsDataResponse.builder()
                .xAxis(xAxis)
                .series(List.of(EChartsSeries.builder()
                        .name("店铺数量")
                        .type("bar")
                        .data(counts)
                        .build()))
                .build();

        ShopRatingDistributionResponse resp = ShopRatingDistributionResponse.builder()
                .items(items)
                .chart(chart)
                .build();

        writeCache(redisKey, resp, SHOP_RATING_TTL);
        sw.stop();
        log.info("getShopRatingDistribution computed: range={}, costMs={}", range, sw.getTotalTimeMillis());
        return resp;
    }

    /**
     * 每日基础统计（含营业额/用户/订单等）。
     */
    public DailyStat computeDaily(LocalDate date) {
        LocalDateTime start = date.atStartOfDay();
        LocalDateTime end = date.plusDays(1).atStartOfDay();

        // 营业额/完成订单：finish_at + 状态
        BigDecimal revenue = jdbcTemplate.queryForObject(
                "SELECT COALESCE(SUM(total_amount),0) " +
                        "FROM `order` " +
                        "WHERE status = ? AND pay_status = ? AND finish_at >= ? AND finish_at < ?",
                new Object[]{OrderStatus.COMPLETED.ordinal(), PayStatus.PAID.ordinal(), start, end},
                BigDecimal.class
        );
        Long completedOrders = jdbcTemplate.queryForObject(
                "SELECT COUNT(*) FROM `order` " +
                        "WHERE status = ? AND pay_status = ? AND finish_at >= ? AND finish_at < ?",
                new Object[]{OrderStatus.COMPLETED.ordinal(), PayStatus.PAID.ordinal(), start, end},
                Long.class
        );

        // 订单量：按 create_time 统计
        Long totalOrders = jdbcTemplate.queryForObject(
                "SELECT COUNT(*) FROM `order` " +
                        "WHERE create_time >= ? AND create_time < ?",
                new Object[]{start, end},
                Long.class
        );

        // 新增用户
        Long newUsers = jdbcTemplate.queryForObject(
                "SELECT COUNT(*) FROM `user` " +
                        "WHERE create_time >= ? AND create_time < ?",
                new Object[]{start, end},
                Long.class
        );

        // 活跃用户：近24小时口径的“登录或下单”。这里实现为：当天 last_login_time 或当天订单 create_time 作为活跃。
        // 如果你严格要“滚动24小时”，需要用 now-24h 的窗口（day 粒度会更复杂）。
        Long activeUsers = jdbcTemplate.queryForObject(
                "SELECT COUNT(DISTINCT t.user_id) FROM (" +
                        "SELECT o.user_id AS user_id FROM `order` o WHERE o.create_time >= ? AND o.create_time < ? " +
                        "UNION " +
                        "SELECT u.id AS user_id FROM `user` u WHERE u.last_login_time >= ? AND u.last_login_time < ?" +
                        ") t",
                new Object[]{start, end, start, end},
                Long.class
        );

        return new DailyStat(date, revenue, newUsers, activeUsers, totalOrders, completedOrders);
    }

    /**
     * 获取每日统计；未命中则计算并写入缓存。
     */
    private DailyStat getOrComputeDaily(LocalDate date) {
        String key = dailyKey(date);
        try {
            String json = stringRedisTemplate.opsForValue().get(key);
            if (json != null && !json.isBlank()) {
                return objectMapper.readValue(json, DailyStat.class);
            }
        } catch (Exception ignored) {
            // Redis 异常回源计算
        }

        DailyStat ds = computeDaily(date);
        writeCache(key, ds, DAILY_TTL);
        return ds;
    }

    /**
     * Scheduler/预热可调用的接口：直接计算并写入 daily。
     */
    public void computeDailyAndCache(LocalDate date) {
        DailyStat ds = computeDaily(date);
        writeCache(dailyKey(date), ds, DAILY_TTL);
    }

    private String dailyKey(LocalDate date) {
        return DAILY_KEY_PREFIX + date.format(DAY_FMT);
    }

    private RangeWindow rangeWindow(StatisticsRange range) {
        LocalDate now = LocalDate.now();
        LocalDate start;
        LocalDate endExclusive;
        switch (range) {
            case TODAY:
                start = now;
                endExclusive = now.plusDays(1);
                break;
            case WEEK:
                start = now.with(TemporalAdjusters.previousOrSame(java.time.DayOfWeek.MONDAY));
                endExclusive = start.plusDays(7);
                break;
            case MONTH:
                start = now.withDayOfMonth(1);
                endExclusive = start.plusMonths(1);
                break;
            case YEAR:
                start = now.withDayOfYear(1);
                endExclusive = start.plusYears(1);
                break;
            default:
                throw new BizException(400, "range不合法");
        }
        return new RangeWindow(start, endExclusive);
    }

    private String toRangeKey(StatisticsRange range) {
        RangeWindow w = rangeWindow(range);
        return range.name().toLowerCase(Locale.ROOT) + ":" + w.start + ":" + w.endExclusive;
    }

    private <T> T readCached(String redisKey, Class<T> clazz) {
        try {
            String json = stringRedisTemplate.opsForValue().get(redisKey);
            if (json == null || json.isBlank()) {
                return null;
            }
            return objectMapper.readValue(json, clazz);
        } catch (Exception ignored) {
            return null;
        }
    }

    private EChartsDataResponse readCachedECharts(String redisKey, Class<EChartsDataResponse> clazz) {
        return readCached(redisKey, clazz);
    }

    private void writeCache(String redisKey, Object value, Duration ttl) {
        try {
            String json = objectMapper.writeValueAsString(value);
            stringRedisTemplate.opsForValue().set(redisKey, json, ttl);
        } catch (Exception ignored) {
        }
    }

    /**
     * 每日基础统计 DTO（缓存体）。
     */
    private static class DailyStat {
        public LocalDate date;
        public BigDecimal revenue;
        public long newUsers;
        public long activeUsers;
        public long totalOrders;
        public long completedOrders;

        // Jackson 需要无参构造/可见字段，这里用 public 字段 + 构造器。
        public DailyStat() {
        }

        public DailyStat(LocalDate date, BigDecimal revenue, long newUsers, long activeUsers, long totalOrders, long completedOrders) {
            this.date = date;
            this.revenue = revenue == null ? BigDecimal.ZERO : revenue;
            this.newUsers = newUsers;
            this.activeUsers = activeUsers;
            this.totalOrders = totalOrders;
            this.completedOrders = completedOrders;
        }
    }

    private static class RangeWindow {
        private final LocalDate start;
        private final LocalDate endExclusive;

        private RangeWindow(LocalDate start, LocalDate endExclusive) {
            this.start = start;
            this.endExclusive = endExclusive;
        }
    }

    private static class TopDishRow {
        private final long dishId;
        private final String dishName;
        private final long qty;

        private TopDishRow(long dishId, String dishName, long qty) {
            this.dishId = dishId;
            this.dishName = dishName;
            this.qty = qty;
        }
    }
}

