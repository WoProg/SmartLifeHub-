package com.smartfood.service.impl;

import com.smartfood.entity.*;
import com.smartfood.exception.BizException;
import com.smartfood.order.notify.OrderNotificationService;
import com.smartfood.security.JwtUtil;
import com.smartfood.service.OrderStateMachineService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;

/**
 * OrderStateMachineServiceImpl：订单状态机的实现。
 *
 * 设计原则：
 * - 用 DB conditional update 做“前置状态校验”与幂等控制
 * - 每次状态变更成功写入 `order_operation_log`（唯一键 order_no+event_type）
 * - 并发/重复请求：
 *   - 状态不满足时更新行数为 0，抛 BizException 或直接提示“不允许”
 *   - 日志插入使用 ON DUPLICATE KEY UPDATE 保证幂等
 */
@Slf4j
@Service
@RequiredArgsConstructor
public class OrderStateMachineServiceImpl implements OrderStateMachineService {

    private final JdbcTemplate jdbcTemplate;
    private final OrderNotificationService notificationService;

    @Override
    public void merchantAccept(Long orderNo, Long merchantShopId, Long merchantOperatorId) {
        ensureOrderNo(orderNo);
        if (merchantShopId == null || merchantShopId <= 0) {
            throw new BizException(400, "商家 shopId 非法");
        }

        LocalDateTime now = LocalDateTime.now();

        int updated = jdbcTemplate.update(
                "UPDATE `order` " +
                        "SET status = ?, update_time = ? " +
                        "WHERE order_no = ? AND shop_id = ? AND status = ? AND pay_status = ?",
                OrderStatus.PENDING_ACCEPT.ordinal(),
                now,
                orderNo,
                merchantShopId,
                OrderStatus.PENDING_PAYMENT.ordinal(),
                PayStatus.PAID.ordinal()
        );

        if (updated != 1) {
            throw new BizException(409, "订单状态不允许：merchantAccept（需待付款且已支付）");
        }

        writeOperationLog(orderNo, "MERCHANT_ACCEPT", 1, merchantOperatorId,
                OrderStatus.PENDING_PAYMENT.ordinal(), OrderStatus.PENDING_ACCEPT.ordinal(),
                "商家接单");

        // Day1 通知：只做日志桩
        Long userId = queryUserId(orderNo);
        notificationService.notifyUser(userId, orderNo, "你的订单已被商家接单");
    }

    @Override
    public void merchantStartMake(Long orderNo, Long merchantShopId, Long merchantOperatorId) {
        ensureOrderNo(orderNo);
        LocalDateTime now = LocalDateTime.now();

        int updated = jdbcTemplate.update(
                "UPDATE `order` " +
                        "SET status = ?, update_time = ? " +
                        "WHERE order_no = ? AND shop_id = ? AND status = ?",
                OrderStatus.MAKING.ordinal(),
                now,
                orderNo,
                merchantShopId,
                OrderStatus.PENDING_ACCEPT.ordinal()
        );

        if (updated != 1) {
            throw new BizException(409, "订单状态不允许：merchantStartMake（需待接单）");
        }

        writeOperationLog(orderNo, "MERCHANT_START_MAKE", 1, merchantOperatorId,
                OrderStatus.PENDING_ACCEPT.ordinal(), OrderStatus.MAKING.ordinal(),
                "商家开始制作");

        Long userId = queryUserId(orderNo);
        notificationService.notifyUser(userId, orderNo, "商家开始制作啦");
    }

    @Override
    public void merchantStartDelivery(Long orderNo, Long merchantShopId, Long merchantOperatorId) {
        ensureOrderNo(orderNo);
        LocalDateTime now = LocalDateTime.now();

        int updated = jdbcTemplate.update(
                "UPDATE `order` " +
                        "SET status = ?, update_time = ? " +
                        "WHERE order_no = ? AND shop_id = ? AND status = ?",
                OrderStatus.PENDING_DELIVERY.ordinal(),
                now,
                orderNo,
                merchantShopId,
                OrderStatus.MAKING.ordinal()
        );

        if (updated != 1) {
            throw new BizException(409, "订单状态不允许：merchantStartDelivery（需制作中）");
        }

        writeOperationLog(orderNo, "MERCHANT_START_DELIVERY", 1, merchantOperatorId,
                OrderStatus.MAKING.ordinal(), OrderStatus.PENDING_DELIVERY.ordinal(),
                "商家开始配送准备");

        Long userId = queryUserId(orderNo);
        notificationService.notifyUser(userId, orderNo, "订单已进入待配送状态");
    }

    @Override
    public void riderStartDelivery(Long orderNo, Long riderOperatorId) {
        ensureOrderNo(orderNo);
        if (riderOperatorId == null || riderOperatorId <= 0) {
            throw new BizException(400, "骑手 riderOperatorId 非法");
        }

        LocalDateTime now = LocalDateTime.now();

        int updated = jdbcTemplate.update(
                "UPDATE `order` " +
                        "SET status = ?, update_time = ? " +
                        "WHERE order_no = ? AND status = ?",
                OrderStatus.DELIVERING.ordinal(),
                now,
                orderNo,
                OrderStatus.PENDING_DELIVERY.ordinal()
        );

        if (updated != 1) {
            throw new BizException(409, "订单状态不允许：riderStartDelivery（需待配送）");
        }

        writeOperationLog(orderNo, "RIDER_START_DELIVERY", 2, riderOperatorId,
                OrderStatus.PENDING_DELIVERY.ordinal(), OrderStatus.DELIVERING.ordinal(),
                "骑手开始配送");

        Long userId = queryUserId(orderNo);
        notificationService.notifyUser(userId, orderNo, "骑手开始配送，请注意查收");
    }

    @Override
    public void confirmReceipt(Long orderNo, Long userOperatorId) {
        ensureOrderNo(orderNo);
        if (userOperatorId == null || userOperatorId <= 0) {
            throw new BizException(400, "用户 userOperatorId 非法");
        }

        LocalDateTime now = LocalDateTime.now();

        int updated = jdbcTemplate.update(
                "UPDATE `order` " +
                        "SET status = ?, finish_at = ?, update_time = ? " +
                        "WHERE order_no = ? AND user_id = ? AND status = ?",
                OrderStatus.COMPLETED.ordinal(),
                now,
                now,
                orderNo,
                userOperatorId,
                OrderStatus.DELIVERING.ordinal()
        );

        if (updated != 1) {
            throw new BizException(409, "订单状态不允许：confirmReceipt（需配送中且用户匹配）");
        }

        writeOperationLog(orderNo, "CONFIRM_RECEIPT", 0, userOperatorId,
                OrderStatus.DELIVERING.ordinal(), OrderStatus.COMPLETED.ordinal(),
                "用户确认收货");

        Long userId = userOperatorId;
        Long shopId = queryShopId(orderNo);
        notificationService.notifyMerchant(shopId, orderNo, "用户已确认收货");
        notificationService.notifyUser(userId, orderNo, "感谢反馈，订单已完成");
    }

    @Override
    public void cancelByUser(Long orderNo, Long userOperatorId) {
        ensureOrderNo(orderNo);
        if (userOperatorId == null || userOperatorId <= 0) {
            throw new BizException(400, "用户 userOperatorId 非法");
        }

        LocalDateTime now = LocalDateTime.now();

        // 仅允许“待付款且未支付”的用户取消（与需求中“用户只能取消待付款订单”一致）
        int updated = jdbcTemplate.update(
                "UPDATE `order` " +
                        "SET status = ?, pay_status = ?, cancelled_at = ?, update_time = ? " +
                        "WHERE order_no = ? AND user_id = ? AND status = ? AND pay_status = ?",
                OrderStatus.CANCELLED.ordinal(),
                PayStatus.FAILED.ordinal(),
                now,
                now,
                orderNo,
                userOperatorId,
                OrderStatus.PENDING_PAYMENT.ordinal(),
                PayStatus.NOT_PAID.ordinal()
        );

        if (updated != 1) {
            throw new BizException(409, "订单状态不允许：cancelByUser（需待付款且未支付）");
        }

        writeOperationLog(orderNo, "CANCEL_BY_USER", 0, userOperatorId,
                OrderStatus.PENDING_PAYMENT.ordinal(), OrderStatus.CANCELLED.ordinal(),
                "用户取消订单");

        Long shopId = queryShopId(orderNo);
        notificationService.notifyMerchant(shopId, orderNo, "用户已取消订单");
        notificationService.notifyUser(userOperatorId, orderNo, "你的订单已取消");
    }

    /**
     * 写入订单操作日志（幂等：order_no + event_type 唯一）。
     */
    private void writeOperationLog(long orderNo,
                                    String eventType,
                                    int operatorRole,
                                    Long operatorId,
                                    int fromStatus,
                                    int toStatus,
                                    String remark) {
        jdbcTemplate.update(
                "INSERT INTO order_operation_log(" +
                        "order_no, event_type, operator_role, operator_id, " +
                        "from_status, to_status, remark, create_time, update_time" +
                        ") VALUES (?,?,?,?,?,?,?,NOW(),NOW()) " +
                        "ON DUPLICATE KEY UPDATE update_time = update_time",
                orderNo,
                eventType,
                operatorRole,
                operatorId,
                fromStatus,
                toStatus,
                remark
        );
    }

    private void ensureOrderNo(Long orderNo) {
        if (orderNo == null || orderNo <= 0) {
            throw new BizException(400, "订单号非法");
        }
    }

    /**
     * 查询订单所属用户（用于通知）。
     */
    private Long queryUserId(long orderNo) {
        return jdbcTemplate.queryForObject("SELECT user_id FROM `order` WHERE order_no = ?", Long.class, orderNo);
    }

    /**
     * 查询订单所属店铺（用于通知）。
     */
    private Long queryShopId(long orderNo) {
        return jdbcTemplate.queryForObject("SELECT shop_id FROM `order` WHERE order_no = ?", Long.class, orderNo);
    }
}

