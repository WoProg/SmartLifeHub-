package com.smartfood.service.impl;

import com.smartfood.auth.SmsCodeService;
import com.smartfood.dto.*;
import com.smartfood.entity.*;
import com.smartfood.exception.BizException;
import com.smartfood.mapper.UserMapper;
import com.smartfood.security.session.RedisLoginSessionService;
import com.smartfood.security.JwtUtil;
import com.smartfood.service.UserService;
import lombok.RequiredArgsConstructor;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.StringUtils;

/**
 * UserServiceImpl：实现用户注册、登录、查询、更新、退出登录逻辑。
 *
 * Day1 要点：
 * - 注册：手机号唯一校验 + BCrypt 加密密码 + 插入数据库
 * - 登录：手机号查找 + BCrypt 校验密码 + 更新 lastLoginTime + 签发 JWT
 * - 退出登录：校验 token 并返回成功（后续可扩展 Redis 黑名单）
 */
@Service
@RequiredArgsConstructor
public class UserServiceImpl implements UserService {

    private final UserMapper userMapper;
    private final JwtUtil jwtUtil;
    private final SmsCodeService smsCodeService;
    private final RedisLoginSessionService redisLoginSessionService;

    // BCryptPasswordEncoder 可直接 new（Day1 骨架阶段简单可用）。
    private final BCryptPasswordEncoder passwordEncoder = new BCryptPasswordEncoder();

    @Override
    @Transactional
    public UserResponse register(RegisterRequest request) {
        // 额外校验：防止绕过 Controller 校验直接调用 Service
        if (!StringUtils.hasText(request.getPhone())) {
            throw new BizException(400, "手机号不能为空");
        }
        if (!StringUtils.hasText(request.getPassword())) {
            throw new BizException(400, "密码不能为空");
        }

        // 1) 查询是否已注册
        User exist = userMapper.selectByPhone(request.getPhone());
        if (exist != null) {
            throw new BizException(409, "该手机号已注册");
        }

        // 2) 生成 BCrypt 哈希密码
        String hashedPassword = passwordEncoder.encode(request.getPassword());

        // 3) 映射用户实体
        java.time.LocalDateTime now = java.time.LocalDateTime.now();
        User user = User.builder()
                .phone(request.getPhone())
                .password(hashedPassword)
                .nickname(request.getNickname())
                .avatar(request.getAvatar())
                .gender(mapGender(request.getGender()))
                .birthDay(request.getBirthDay())
                .status(UserStatus.NORMAL)
                .userLevel(0)
                .build();

        // 由于 MyBatis-Plus 写入不会触发 JPA 的 @PrePersist，所以这里手动补齐时间字段
        user.setCreateTime(now);
        user.setUpdateTime(now);

        // 4) 写入数据库
        userMapper.insert(user);
        // insert 后 id 会由数据库回填（MyBatis-Plus 默认支持）

        return UserResponse.fromUser(user);
    }

    @Override
    @Transactional
    public LoginResponse login(LoginRequest request) {
        if (!StringUtils.hasText(request.getPhone())) {
            throw new BizException(400, "手机号不能为空");
        }
        if (!StringUtils.hasText(request.getPassword())) {
            throw new BizException(400, "密码不能为空");
        }

        // 1) 根据手机号查询用户
        User user = userMapper.selectByPhone(request.getPhone());
        if (user == null) {
            // 不区分“手机号不存在”与“密码错误”，避免信息泄露
            throw new BizException(401, "手机号或密码错误");
        }

        // 2) 校验用户状态
        if (user.getStatus() == UserStatus.DISABLED) {
            throw new BizException(403, "账号已被禁用");
        }

        // 3) 校验密码（BCrypt）
        boolean matches = passwordEncoder.matches(request.getPassword(), user.getPassword());
        if (!matches) {
            throw new BizException(401, "手机号或密码错误");
        }

        // 4) 更新 lastLoginTime（记录最近一次登录）
        user.setLastLoginTime(java.time.LocalDateTime.now());
        user.setUpdateTime(java.time.LocalDateTime.now());
        userMapper.updateById(user);

        // 5) 签发 JWT token
        String token = jwtUtil.generateToken(user.getId(), user.getPhone());

        // 6) 写入 Redis 登录会话（分布式 Session）
        redisLoginSessionService.saveSession(token, user);

        return LoginResponse.builder()
                .token(token)
                .user(UserResponse.fromUser(user))
                .build();
    }

    @Override
    public UserResponse getById(Long userId) {
        if (userId == null || userId <= 0) {
            throw new BizException(400, "用户 id 非法");
        }

        User user = userMapper.selectById(userId);
        if (user == null) {
            throw new BizException(404, "用户不存在");
        }

        return UserResponse.fromUser(user);
    }

    @Override
    @Transactional
    public UserResponse updateUser(UpdateUserRequest request) {
        if (request.getId() == null || request.getId() <= 0) {
            throw new BizException(400, "用户 id 非法");
        }

        // 1) 查询用户
        User user = userMapper.selectById(request.getId());
        if (user == null) {
            throw new BizException(404, "用户不存在");
        }

        // 2) 可更新字段（不允许修改手机号/密码，避免安全风险）
        if (StringUtils.hasText(request.getNickname())) {
            user.setNickname(request.getNickname());
        }
        if (StringUtils.hasText(request.getAvatar())) {
            user.setAvatar(request.getAvatar());
        }
        if (request.getGender() != null) {
            user.setGender(mapGender(request.getGender()));
        }
        if (request.getBirthDay() != null) {
            user.setBirthDay(request.getBirthDay());
        }

        // 3) 写回数据库
        user.setUpdateTime(java.time.LocalDateTime.now());
        userMapper.updateById(user);

        return UserResponse.fromUser(user);
    }

    @Override
    @Transactional
    public void logout(String token) {
        if (!StringUtils.hasText(token)) {
            throw new BizException(400, "token不能为空");
        }

        // 允许传入 "Bearer xxx" 形式，做简单兼容
        String realToken = token;
        if (realToken.toLowerCase().startsWith("bearer ")) {
            realToken = realToken.substring(7).trim();
        }

        // Day1：仅做 token 合法性校验，未接入真正的鉴权过滤器
        if (!jwtUtil.isTokenValid(realToken)) {
            throw new BizException(401, "token无效或已过期");
        }

        // 删除 Redis 会话：支持多服务共享登录态
        redisLoginSessionService.deleteSession(realToken);
    }

    @Override
    public void sendSmsCode(String phone) {
        smsCodeService.sendCode(phone);
    }

    @Override
    @Transactional
    public LoginResponse loginBySmsCode(SmsLoginRequest request) {
        if (request == null) {
            throw new BizException(400, "参数不能为空");
        }

        String phone = request.getPhone();
        String code = request.getCode();

        // 1) Redis 校验验证码（包含防轰炸/限错/锁定逻辑）
        smsCodeService.verifyCode(phone, code);

        // 2) 查询用户
        User user = userMapper.selectByPhone(phone);
        if (user == null) {
            // Day1 数据模型：User.password 为 NOT NULL，因此不做“首次短信免密码注册”；要求先完成注册
            throw new BizException(404, "手机号未注册");
        }
        if (user.getStatus() == UserStatus.DISABLED) {
            throw new BizException(403, "账号已被禁用");
        }

        // 3) 更新 lastLoginTime
        user.setLastLoginTime(java.time.LocalDateTime.now());
        user.setUpdateTime(java.time.LocalDateTime.now());
        userMapper.updateById(user);

        // 4) 签发 token + 写入 Redis 会话
        String token = jwtUtil.generateToken(user.getId(), user.getPhone());
        redisLoginSessionService.saveSession(token, user);

        return LoginResponse.builder()
                .token(token)
                .user(UserResponse.fromUser(user))
                .build();
    }

    /**
     * 将性别 code 映射为枚举。
     *
     * @param genderCode 性别 code：0/1/2
     * @return {@link Gender} 枚举
     */
    private Gender mapGender(Integer genderCode) {
        if (genderCode == null) {
            return Gender.UNKNOWN;
        }
        if (genderCode < 0 || genderCode >= Gender.values().length) {
            throw new BizException(400, "性别参数非法");
        }
        // Gender 的 ordinal 与 code 保持一致（Day1 简化映射逻辑）
        return Gender.values()[genderCode];
    }
}

