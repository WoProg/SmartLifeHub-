package com.smartfood.service;

import com.smartfood.dto.ShopResponse;
import com.smartfood.dto.UpdateShopRequest;

/**
 * 店铺业务接口。
 */
public interface ShopService {

    /**
     * 按 id 查询店铺（Redis 缓存）。
     */
    ShopResponse getById(Long id);

    /**
     * 更新店铺信息（更新成功后删除 Redis 缓存）。
     */
    void updateShop(Long id, UpdateShopRequest request);
}

