package com.smartfood.service;

import com.smartfood.dto.LoginRequest;
import com.smartfood.dto.LoginResponse;
import com.smartfood.dto.RegisterRequest;
import com.smartfood.dto.UpdateUserRequest;
import com.smartfood.dto.UserResponse;
import com.smartfood.dto.SmsLoginRequest;

import javax.validation.Valid;

/**
 * 用户业务接口层。
 *
 * Day1 目标：为“注册/登录/查询/更新/退出登录”提供可扩展的方法定义。
 */
public interface UserService {

    /**
     * 用户注册。
     *
     * @param request 注册参数（手机号、密码、昵称等）
     * @return 注册后的用户信息（脱敏，不返回密码）
     */
    UserResponse register(@Valid RegisterRequest request);

    /**
     * 用户登录。
     *
     * 登录成功后生成 JWT token 返回给前端。
     *
     * @param request 登录参数（手机号、密码）
     * @return token + 用户信息
     */
    LoginResponse login(@Valid LoginRequest request);

    /**
     * 发送短信验证码。
     */
    void sendSmsCode(String phone);

    /**
     * 提交短信验证码登录。
     */
    LoginResponse loginBySmsCode(@Valid SmsLoginRequest request);

    /**
     * 根据用户 id 查询用户信息。
     *
     * @param userId 用户主键
     * @return 用户信息（脱敏）
     */
    UserResponse getById(Long userId);

    /**
     * 更新用户信息。
     *
     * 通常允许修改昵称、头像、性别、生日等字段（不建议允许修改手机号）。
     *
     * @param request 更新参数
     * @return 更新后的用户信息（脱敏）
     */
    UserResponse updateUser(@Valid UpdateUserRequest request);

    /**
     * 退出登录。
     *
     * Day1 骨架阶段说明：
     * - 由于尚未接入“鉴权过滤器”，这里仅做 token 校验并返回退出成功；
     * - 后续可结合 Redis token 黑名单实现真正的登出失效。
     *
     * @param token 客户端传入的 token（建议不带 Bearer 前缀）
     */
    void logout(String token);
}

