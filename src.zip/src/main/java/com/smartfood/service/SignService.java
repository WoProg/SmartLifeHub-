package com.smartfood.service;

import com.smartfood.dto.IntegralRankResponse;
import com.smartfood.dto.SignMonthResponse;
import com.smartfood.dto.SignResponse;

/**
 * 签到与积分（Redis）。
 */
public interface SignService {

    SignResponse sign(Long userId);

    SignMonthResponse getMonthSign(Long userId);

    IntegralRankResponse getIntegralRank(int limit);
}

