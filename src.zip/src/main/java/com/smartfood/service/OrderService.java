package com.smartfood.service;

/**
 * 订单业务接口。
 *
 * Day1/Day2 下单入口主要是：从购物车创建订单。
 */
public interface OrderService {

    /**
     * 从购物车创建订单。
     *
     * 业务流程（Day1）：
     * 1. 读取用户购物车中 is_selected=1 的条目
     * 2. 校验每个菜品的上架状态、价格与库存是否满足
     * 3. 生成订单（使用 Redis 分布式锁防止重复提交）
     * 4. 写入 order / order_detail
     * 5. 清空购物车选中项
     * 6. 将订单写入 Redis 延迟队列，支持超时取消
     *
     * @param userId 用户 id
     * @return 订单号 orderNo
     */
    long createOrderFromCart(Long userId);
}

