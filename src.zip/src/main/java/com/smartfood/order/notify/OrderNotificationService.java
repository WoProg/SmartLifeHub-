package com.smartfood.order.notify;

import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

/**
 * 通知相关方的“通知桩”（Day1）。
 *
 * 目前实现：
 * - 仅记录日志，后续可接入 WebSocket/短信/站内信等渠道
 */
@Slf4j
@Service
public class OrderNotificationService {

    /**
     * 通知用户。
     *
     * @param userId 用户 id
     * @param orderNo 订单号
     * @param message 通知内容
     */
    public void notifyUser(Long userId, long orderNo, String message) {
        log.info("通知用户 userId={}, orderNo={}, message={}", userId, orderNo, message);
    }

    /**
     * 通知商家。
     *
     * @param shopId 商家店铺 id（本项目商家身份=shop）
     * @param orderNo 订单号
     * @param message 通知内容
     */
    public void notifyMerchant(Long shopId, long orderNo, String message) {
        log.info("通知商家 shopId={}, orderNo={}, message={}", shopId, orderNo, message);
    }

    /**
     * 通知骑手。
     *
     * @param riderId 骑手 id
     * @param orderNo 订单号
     * @param message 通知内容
     */
    public void notifyRider(Long riderId, long orderNo, String message) {
        log.info("通知骑手 riderId={}, orderNo={}, message={}", riderId, orderNo, message);
    }
}

