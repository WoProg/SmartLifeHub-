package com.smartfood.order.worker;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.data.redis.RedisConnectionFailureException;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.data.redis.core.script.DefaultRedisScript;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import java.time.LocalDateTime;
import java.util.List;

/**
 * 订单超时取消 Worker（纯 Redis 延迟队列）。
 *
 * 实现要点（严格对齐需求）：
 * - Lua claimDue：从 `orders:cancel:due` 里取出 score<=now 的 orderNo，并原子加入 processing + 写 lease
 * - DB conditional update：仅当订单仍是“待付款且未支付”时才更新为“已取消”
 * - 写操作日志：order_operation_log(event_type=CANCEL_TIMEOUT)
 * - Lua lease finalize：只有当 lease token 匹配时才从 processing 移除，避免并发误删
 * - lease 过期重入：将超时 processing 订单重新放回 due（用于 worker crash 场景）
 */
@Slf4j
@Component
@RequiredArgsConstructor
public class CancelOrderWorker {

    private final StringRedisTemplate stringRedisTemplate;
    private final JdbcTemplate jdbcTemplate;

    // Redis 延迟取消 key（与 OrderServiceImpl 保持一致）
    private static final String CANCEL_DUE_ZSET = "orders:cancel:due";
    private static final String CANCEL_PROCESSING_ZSET = "orders:cancel:processing";
    private static final String CANCEL_LEASE_HASH = "orders:cancel:lease";
    private static final String CANCEL_META_HASH = "orders:cancel:meta";

    /**
     * 租约时长（毫秒）。
     * - 只要超过“本次取消处理的最大耗时”，即可保证正常情况下不会并发 finalize。
     */
    private static final long LEASE_MS = 60_000L;

    /**
     * 每次最多处理的订单数（避免一次处理过多造成 DB 压力）。
     */
    private static final int BATCH_SIZE = 50;
    private volatile boolean redisUnavailableLogged;

    /**
     * 本 worker 的唯一身份（用于 lease token 构造）。
     */
    private final String workerId = String.valueOf(System.identityHashCode(this));

    /**
     * 定时执行：固定延迟（毫秒）。
     */
    @Scheduled(fixedDelayString = "${app.order.cancel-worker.fixed-delay-ms:1000}")
    public void tick() {
        try {
            long nowMs = System.currentTimeMillis();

            // 1) 先把 processing 中租约过期的订单重新放回 due（避免 crash 后永远不处理）
            requeueExpired(nowMs);

            // 2) claim due 订单：ZSET due 中 <= now 的 orderNo
            List<String> orderIds = claimDue(nowMs, BATCH_SIZE);
            if (orderIds == null || orderIds.isEmpty()) {
                return;
            }

            // 3) 对每个 orderNo 执行 DB 条件取消 + 写操作日志 + lease finalize
            LocalDateTime now = LocalDateTime.now();
            for (String orderNoStr : orderIds) {
                long orderNo = Long.parseLong(orderNoStr);

                // DB conditional update（只在仍为待付款且未支付时取消）
                // 与 OrderStatus/PayStatus 枚举 ordinal 一致：
                // OrderStatus.PENDING_PAYMENT.ordinal() = 0
                // PayStatus.NOT_PAID.ordinal() = 0
                int fromStatus = 0;
                int fromPayStatus = 0;
                int cancelledStatus = 6; // OrderStatus.CANCELLED.ordinal()
                int failedPayStatus = 2; // PayStatus.FAILED.ordinal()

                int updated = jdbcTemplate.update(
                        "UPDATE `order` " +
                                "SET status = ?, pay_status = ?, cancelled_at = ?, update_time = ? " +
                                "WHERE order_no = ? AND status = ? AND pay_status = ?",
                        cancelledStatus,
                        failedPayStatus,
                        now,
                        now,
                        orderNo,
                        fromStatus,
                        fromPayStatus
                );

                if (updated == 1) {
                    // 写操作日志（幂等：order_no + event_type 唯一）
                    jdbcTemplate.update(
                            "INSERT INTO order_operation_log(" +
                                    "order_no, event_type, operator_role, operator_id, " +
                                    "from_status, to_status, remark, create_time, update_time" +
                                    ") VALUES (?,?,?,?,?,?,?,NOW(),NOW()) " +
                                    "ON DUPLICATE KEY UPDATE update_time = update_time",
                            orderNo,
                            "CANCEL_TIMEOUT",
                            0,
                            null,
                            fromStatus,
                            cancelledStatus,
                            "订单超时取消（redis 延迟队列触发）"
                    );

                    log.info("订单超时取消成功：orderNo={}", orderNo);
                } else {
                    // 可能发生：已支付/已取消/状态已推进（不再重复处理）
                    log.info("订单超时取消跳过（未满足条件）：orderNo={}, updated={}", orderNo, updated);
                }

                // finalize：只有当 lease token 匹配才从 processing 移除
                String leaseToken = workerId + ":" + orderNoStr;
                finalizeLease(orderNoStr, leaseToken);
            }
        } catch (RedisConnectionFailureException e) {
            if (!redisUnavailableLogged) {
                log.warn("CancelOrderWorker skipped: Redis unavailable");
                redisUnavailableLogged = true;
            }
        } catch (Exception e) {
            log.error("CancelOrderWorker tick error", e);
        }
    }

    /**
     * processing lease 过期重入：把 due 之前 claimDue 失败/worker crash 未 finalize 的订单重新放回 due。
     *
     * @param nowMs 当前时间戳（毫秒）
     */
    private void requeueExpired(long nowMs) {
        String lua = "" +
                "local processingZset = KEYS[1] \n" +
                "local dueZset = KEYS[2] \n" +
                "local leaseHash = KEYS[3] \n" +
                "local metaHash = KEYS[4] \n" +
                "local nowMs = tonumber(ARGV[1]) \n" +
                "local maxBatch = tonumber(ARGV[2]) \n" +
                "local ids = redis.call('ZRANGEBYSCORE', processingZset, '-inf', nowMs, 'LIMIT', 0, maxBatch) \n" +
                "if (#ids == 0) then return {} end \n" +
                "for _, id in ipairs(ids) do \n" +
                "  redis.call('ZREM', processingZset, id) \n" +
                "  redis.call('HDEL', leaseHash, id) \n" +
                "  local cancelAtMs = redis.call('HGET', metaHash, id) \n" +
                "  if cancelAtMs then \n" +
                "    redis.call('ZADD', dueZset, tonumber(cancelAtMs), id) \n" +
                "  else \n" +
                "    redis.call('ZADD', dueZset, nowMs, id) \n" +
                "  end \n" +
                "end \n" +
                "return ids";

        DefaultRedisScript<List> script = new DefaultRedisScript<>(lua, List.class);
        // maxBatch 直接复用
        List<?> ids = stringRedisTemplate.execute(
                script,
                List.of(CANCEL_PROCESSING_ZSET, CANCEL_DUE_ZSET, CANCEL_LEASE_HASH, CANCEL_META_HASH),
                String.valueOf(nowMs),
                String.valueOf(BATCH_SIZE)
        );
        if (ids != null && !ids.isEmpty()) {
            log.debug("requeueExpired: {} orders", ids.size());
        }
    }

    /**
     * claimDue：从 due 中 claim 到期订单并加入 processing + 写 lease。
     *
     * @param nowMs 当前时间戳（毫秒）
     * @param maxBatch 最大批次数
     * @return orderIds（字符串形式）
     */
    private List<String> claimDue(long nowMs, int maxBatch) {
        String lua = "" +
                "local dueZset = KEYS[1] \n" +
                "local processingZset = KEYS[2] \n" +
                "local leaseHash = KEYS[3] \n" +
                "local nowMs = tonumber(ARGV[1]) \n" +
                "local maxBatch = tonumber(ARGV[2]) \n" +
                "local workerId = ARGV[3] \n" +
                "local leaseMs = tonumber(ARGV[4]) \n" +
                "local ids = redis.call('ZRANGEBYSCORE', dueZset, '-inf', nowMs, 'LIMIT', 0, maxBatch) \n" +
                "if (#ids == 0) then return {} end \n" +
                "for i, id in ipairs(ids) do \n" +
                "  redis.call('ZREM', dueZset, id) \n" +
                "  local leaseToken = workerId .. ':' .. id \n" +
                "  redis.call('HSET', leaseHash, id, leaseToken) \n" +
                "  redis.call('ZADD', processingZset, nowMs + leaseMs, id) \n" +
                "end \n" +
                "return ids";

        DefaultRedisScript<List> script = new DefaultRedisScript<>(lua, List.class);
        Object result = stringRedisTemplate.execute(
                script,
                List.of(CANCEL_DUE_ZSET, CANCEL_PROCESSING_ZSET, CANCEL_LEASE_HASH),
                String.valueOf(nowMs),
                String.valueOf(maxBatch),
                workerId,
                String.valueOf(LEASE_MS)
        );

        if (result == null) {
            return List.of();
        }

        // Spring/Redis 可能把 List 元素当作不同类型；统一转 String
        List<?> raw = (List<?>) result;
        return raw.stream().map(String::valueOf).toList();
    }

    /**
     * lease finalize：只有当前 lease token 匹配，才从 processing 移除并清 lease。
     *
     * @param orderNoStr order_no 字符串
     * @param leaseToken 预期 token
     */
    private void finalizeLease(String orderNoStr, String leaseToken) {
        String lua = "" +
                "local processingZset = KEYS[1] \n" +
                "local leaseHash = KEYS[2] \n" +
                "local orderId = ARGV[1] \n" +
                "local expectedToken = ARGV[2] \n" +
                "local currentToken = redis.call('HGET', leaseHash, orderId) \n" +
                "if currentToken == expectedToken then \n" +
                "  redis.call('ZREM', processingZset, orderId) \n" +
                "  redis.call('HDEL', leaseHash, orderId) \n" +
                "  return 1 \n" +
                "else \n" +
                "  return 0 \n" +
                "end";

        DefaultRedisScript<Long> script = new DefaultRedisScript<>(lua, Long.class);
        Long ok = stringRedisTemplate.execute(
                script,
                List.of(CANCEL_PROCESSING_ZSET, CANCEL_LEASE_HASH),
                orderNoStr,
                leaseToken
        );
        if (ok == null || ok == 0) {
            log.debug("finalizeLease failed: orderNo={}, leaseToken={}", orderNoStr, leaseToken);
        }
    }
}

