package com.smartfood.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.smartfood.entity.Shop;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.Update;

import java.util.List;

/**
 * 店铺数据访问层（MyBatis-Plus）。
 *
 * 为了避免 JPA 注解与 MyBatis-Plus 推断差异，关键查询使用显式 SQL。
 */
@Mapper
public interface ShopMapper extends BaseMapper<Shop> {

    @Select("SELECT * FROM shop WHERE id = #{id} LIMIT 1")
    Shop selectByShopId(@Param("id") Long id);

    @Select("SELECT * FROM shop ORDER BY sales_count DESC LIMIT #{limit}")
    List<Shop> selectPopularShops(@Param("limit") int limit);

    @Update("UPDATE shop SET " +
            "name = #{name}, " +
            "address = #{address}, " +
            "shop_type = #{shopType}, " +
            "longitude = #{longitude}, " +
            "latitude = #{latitude}, " +
            "business_status = #{businessStatus}, " +
            "rating = #{rating}, " +
            "delivery_fee = #{deliveryFee}, " +
            "min_order_amount = #{minOrderAmount}, " +
            "open_time = #{openTime}, " +
            "close_time = #{closeTime}, " +
            "sales_count = #{salesCount} " +
            "WHERE id = #{id}")
    int updateShopById(
            @Param("id") Long id,
            @Param("name") String name,
            @Param("address") String address,
            @Param("shopType") Integer shopType,
            @Param("longitude") java.math.BigDecimal longitude,
            @Param("latitude") java.math.BigDecimal latitude,
            @Param("businessStatus") Integer businessStatus,
            @Param("rating") java.math.BigDecimal rating,
            @Param("deliveryFee") java.math.BigDecimal deliveryFee,
            @Param("minOrderAmount") java.math.BigDecimal minOrderAmount,
            @Param("openTime") String openTime,
            @Param("closeTime") String closeTime,
            @Param("salesCount") Integer salesCount
    );
}

