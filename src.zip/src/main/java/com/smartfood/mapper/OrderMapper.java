package com.smartfood.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.smartfood.entity.Order;
import org.apache.ibatis.annotations.Mapper;

/**
 * 订单数据访问层（MyBatis-Plus）。
 *
 * Day1/Day2 主要用于：
 * - 写入订单（createOrder）
 * - 条件更新订单状态（状态机/超时取消/支付回调）
 * - 按 orderNo 查询订单
 */
@Mapper
public interface OrderMapper extends BaseMapper<Order> {
}

