package com.smartfood.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.smartfood.entity.Notice;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;

import java.util.List;

@Mapper
public interface NoticeMapper extends BaseMapper<Notice> {
    @Select("SELECT * FROM notice WHERE enabled = 1 AND type = #{type} ORDER BY update_time DESC LIMIT #{limit}")
    List<Notice> listEnabledByType(@Param("type") String type, @Param("limit") Integer limit);
}
