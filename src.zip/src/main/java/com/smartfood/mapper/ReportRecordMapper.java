package com.smartfood.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.smartfood.entity.ReportRecord;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.Update;

import java.util.List;

@Mapper
public interface ReportRecordMapper extends BaseMapper<ReportRecord> {
    @Select("SELECT * FROM report_record WHERE status = #{status} ORDER BY create_time DESC LIMIT #{limit}")
    List<ReportRecord> listByStatus(@Param("status") Integer status, @Param("limit") Integer limit);

    @Update("UPDATE report_record SET status = #{status}, update_time = NOW() WHERE id = #{id}")
    int updateStatus(@Param("id") Long id, @Param("status") Integer status);
}
