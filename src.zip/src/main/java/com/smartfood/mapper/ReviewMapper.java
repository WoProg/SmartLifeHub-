package com.smartfood.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.smartfood.entity.Review;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.Update;

import java.util.List;

@Mapper
public interface ReviewMapper extends BaseMapper<Review> {
    @Select("SELECT * FROM review WHERE shop_id = #{shopId} AND status = 1 ORDER BY create_time DESC LIMIT #{limit}")
    List<Review> listApprovedByShop(@Param("shopId") Long shopId, @Param("limit") Integer limit);

    @Select("SELECT * FROM review WHERE status = #{status} ORDER BY create_time DESC LIMIT #{limit}")
    List<Review> listByStatus(@Param("status") Integer status, @Param("limit") Integer limit);

    @Update("UPDATE review SET status = #{status}, update_time = NOW() WHERE id = #{id}")
    int updateStatus(@Param("id") Long id, @Param("status") Integer status);

    @Update("UPDATE review SET like_count = like_count + #{delta}, update_time = NOW() WHERE id = #{id}")
    int updateLikeCount(@Param("id") Long id, @Param("delta") Integer delta);
}
