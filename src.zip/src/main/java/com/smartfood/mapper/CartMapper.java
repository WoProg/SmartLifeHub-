package com.smartfood.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.smartfood.entity.CartItem;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.Update;
import org.apache.ibatis.annotations.Delete;

import java.util.List;

/**
 * 购物车数据访问层（MyBatis-Plus）。
 *
 * Day1/Day2 下单场景：
 * - 从购物车读取用户选中的条目（is_selected=1）
 * - 下单成功后清空选中条目（is_selected=0）
 */
@Mapper
public interface CartMapper extends BaseMapper<CartItem> {

    /**
     * 查询用户选中的购物车条目。
     *
     * @param userId 用户 id
     * @return 选中的购物车条目列表
     */
    @Select("SELECT * FROM cart WHERE user_id = #{userId} AND is_selected = 1")
    List<CartItem> selectSelectedByUserId(@Param("userId") Long userId);

    /**
     * 清空用户选中条目（下单成功后执行）。
     *
     * @param userId 用户 id
     * @return 影响行数
     */
    @Update("UPDATE cart SET is_selected = 0 WHERE user_id = #{userId} AND is_selected = 1")
    int clearSelectedByUserId(@Param("userId") Long userId);

    @Select("SELECT * FROM cart WHERE user_id = #{userId} ORDER BY update_time DESC")
    List<CartItem> selectByUserId(@Param("userId") Long userId);

    @Select("SELECT * FROM cart WHERE user_id = #{userId} AND dish_id = #{dishId} AND spec_key = #{specKey} LIMIT 1")
    CartItem selectByUserDishSpec(@Param("userId") Long userId,
                                  @Param("dishId") Long dishId,
                                  @Param("specKey") String specKey);

    @Update("UPDATE cart SET quantity = quantity + #{delta}, is_selected = 1, update_time = NOW() WHERE id = #{id}")
    int increaseQuantity(@Param("id") Long id, @Param("delta") Integer delta);

    @Update("UPDATE cart SET quantity = #{quantity}, update_time = NOW() WHERE id = #{id}")
    int updateQuantity(@Param("id") Long id, @Param("quantity") Integer quantity);

    @Update("UPDATE cart SET is_selected = #{selected}, update_time = NOW() WHERE id = #{id}")
    int updateSelected(@Param("id") Long id, @Param("selected") Integer selected);

    @Delete("DELETE FROM cart WHERE id = #{id}")
    int deleteByCartId(@Param("id") Long id);

    @Delete("DELETE FROM cart WHERE user_id = #{userId}")
    int clearByUserId(@Param("userId") Long userId);

    @Insert("INSERT INTO cart(user_id, dish_id, quantity, spec_key, spec_json, is_selected, create_time, update_time) " +
            "VALUES(#{userId}, #{dishId}, #{quantity}, #{specKey}, #{specJson}, #{isSelected}, NOW(), NOW())")
    int insertCartItem(CartItem item);
}

