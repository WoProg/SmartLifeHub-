package com.smartfood.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.smartfood.entity.Address;
import org.apache.ibatis.annotations.*;

import java.util.List;

@Mapper
public interface AddressMapper extends BaseMapper<Address> {

    @Select("SELECT * FROM address WHERE user_id = #{userId} ORDER BY is_default DESC, update_time DESC")
    List<Address> selectByUserId(@Param("userId") Long userId);

    @Select("SELECT * FROM address WHERE id = #{id} AND user_id = #{userId} LIMIT 1")
    Address selectByIdAndUserId(@Param("id") Long id, @Param("userId") Long userId);

    @Update("UPDATE address SET is_default = 0, update_time = NOW() WHERE user_id = #{userId}")
    int clearDefault(@Param("userId") Long userId);

    @Delete("DELETE FROM address WHERE id = #{id} AND user_id = #{userId}")
    int deleteByIdAndUserId(@Param("id") Long id, @Param("userId") Long userId);

    @Insert("INSERT INTO address(user_id, receiver, receiver_phone, province, city, detail_address, is_default, create_time, update_time) " +
            "VALUES(#{userId}, #{receiver}, #{receiverPhone}, #{province}, #{city}, #{detailAddress}, #{isDefault}, NOW(), NOW())")
    int insertAddress(AddressRow row);

    @Update("UPDATE address SET receiver = #{receiver}, receiver_phone = #{receiverPhone}, province = #{province}, city = #{city}, " +
            "detail_address = #{detailAddress}, is_default = #{isDefault}, update_time = NOW() WHERE id = #{id} AND user_id = #{userId}")
    int updateAddress(AddressRow row);

    class AddressRow {
        public Long id;
        public Long userId;
        public String receiver;
        public String receiverPhone;
        public String province;
        public String city;
        public String detailAddress;
        public Integer isDefault;
    }
}
