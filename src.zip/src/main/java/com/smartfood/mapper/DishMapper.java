package com.smartfood.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.smartfood.entity.Dish;
import com.smartfood.entity.DishStatus;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.Update;

import java.util.List;

/**
 * 菜品数据访问层（MyBatis-Plus）。
 *
 * Day1/Day2 下单场景需要做两件事：
 * - 校验菜品是否上架、价格是否有效
 * - 条件扣减库存（并发安全，防止超卖）
 */
@Mapper
public interface DishMapper extends BaseMapper<Dish> {

    /**
     * 批量查询指定菜品。
     *
     * @param ids 菜品 id 列表
     * @return 菜品列表（不存在的 id 不会返回）
     */
    @Select({
            "<script>",
            "SELECT * FROM dish WHERE id IN",
            "<foreach collection='ids' item='id' open='(' separator=',' close=')'>",
            "#{id}",
            "</foreach>",
            " </script>"
    })
    List<Dish> selectByIds(@Param("ids") List<Long> ids);

    /**
     * 条件扣减库存：当库存足够且菜品处于上架状态时扣减成功。
     *
     * @param dishId 菜品 id
     * @param quantity 需要扣减的数量
     * @param onSaleStatus 上架状态（DishStatus.ON_SALE 对应值）
     * @return 影响行数：成功返回 1，失败返回 0
     */
    @Update("UPDATE dish SET " +
            "stock_quantity = stock_quantity - #{quantity}, " +
            "sales_volume = sales_volume + #{quantity} " +
            "WHERE id = #{dishId} " +
            "AND stock_quantity >= #{quantity} " +
            "AND status = #{onSaleStatus}")
    int deductStock(@Param("dishId") Long dishId,
                    @Param("quantity") Integer quantity,
                    @Param("onSaleStatus") int onSaleStatus);

    @Select("SELECT * FROM dish WHERE shop_id = #{shopId} ORDER BY sales_volume DESC, id DESC")
    List<Dish> selectByShopId(@Param("shopId") Long shopId);

    @Select("SELECT * FROM dish WHERE name LIKE CONCAT('%', #{keyword}, '%') ORDER BY sales_volume DESC LIMIT #{limit}")
    List<Dish> searchByName(@Param("keyword") String keyword, @Param("limit") Integer limit);
}

