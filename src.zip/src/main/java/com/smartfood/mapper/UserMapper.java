package com.smartfood.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.smartfood.entity.User;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;

/**
 * User 数据访问层（MyBatis-Plus）。
 *
 * Day1 只实现“注册/登录/查询/更新”所需的基础查询：
 * - 根据手机号查询用户（登录校验使用）
 */
@Mapper
public interface UserMapper extends BaseMapper<User> {

    /**
     * 根据手机号查询用户。
     *
     * @param phone 手机号（唯一）
     * @return 用户实体；不存在返回 null
     */
    @Select("SELECT * FROM `user` WHERE phone = #{phone} LIMIT 1")
    User selectByPhone(@Param("phone") String phone);
}

