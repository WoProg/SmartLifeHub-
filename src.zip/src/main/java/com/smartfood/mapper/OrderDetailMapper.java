package com.smartfood.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.smartfood.entity.OrderDetail;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Select;

import java.util.List;

/**
 * 订单明细数据访问层（MyBatis-Plus）。
 *
 * 主要用于创建订单时批量写入订单明细。
 */
@Mapper
public interface OrderDetailMapper extends BaseMapper<OrderDetail> {

    @Select("SELECT * FROM order_detail WHERE order_no = #{orderNo} ORDER BY id ASC")
    List<OrderDetail> selectByOrderNo(@Param("orderNo") Long orderNo);
}

