package com.smartfood.auth;

import com.smartfood.exception.BizException;
import lombok.RequiredArgsConstructor;
import org.springframework.data.redis.RedisConnectionFailureException;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.stereotype.Service;

import java.security.SecureRandom;
import java.time.Duration;

/**
 * 短信验证码服务（Redis 实现）。
 *
 * key: login:code:{phone} -> 6位验证码（TTL 5分钟）
 * - 防轰炸：同手机号 60 秒内只能发一次
 * - 错误次数限制：输错 5 次锁定 10 分钟
 */
@Service
@RequiredArgsConstructor
public class SmsCodeService {

    private static final SecureRandom RANDOM = new SecureRandom();

    private static final Duration CODE_TTL = Duration.ofMinutes(5);
    private static final Duration SEND_LOCK_TTL = Duration.ofSeconds(60);
    private static final Duration FAIL_LOCK_TTL = Duration.ofMinutes(10);

    private static final int MAX_FAILS = 5;

    private final StringRedisTemplate stringRedisTemplate;

    public void sendCode(String phone) {
        if (phone == null || phone.isBlank()) {
            throw new BizException(400, "手机号不能为空");
        }

        String sendLockKey = "login:code:sent:" + phone;
        try {
            Boolean ok = stringRedisTemplate.opsForValue().setIfAbsent(
                    sendLockKey, "1", SEND_LOCK_TTL
            );
            if (!Boolean.TRUE.equals(ok)) {
                throw new BizException(429, "60秒内只能发送一次验证码，请稍后再试");
            }

            String code = String.valueOf(100000 + RANDOM.nextInt(900000));
            String codeKey = "login:code:" + phone;
            stringRedisTemplate.opsForValue().set(codeKey, code, CODE_TTL);
        } catch (RedisConnectionFailureException e) {
            throw new BizException(503, "Redis连接失败，无法发送验证码");
        }
    }

    public void verifyCode(String phone, String code) {
        if (phone == null || phone.isBlank()) {
            throw new BizException(400, "手机号不能为空");
        }
        if (code == null || code.isBlank()) {
            throw new BizException(400, "验证码不能为空");
        }

        String lockKey = "login:code:lock:" + phone;
        String failKey = "login:code:fail:" + phone;
        String codeKey = "login:code:" + phone;

        try {
            String lockVal = stringRedisTemplate.opsForValue().get(lockKey);
            if (lockVal != null && !lockVal.isBlank()) {
                throw new BizException(423, "验证码错误次数过多，已锁定10分钟");
            }

            String stored = stringRedisTemplate.opsForValue().get(codeKey);
            if (stored == null || stored.isBlank()) {
                throw new BizException(400, "验证码已过期，请重新发送");
            }

            if (!stored.equals(code)) {
                Long fails = stringRedisTemplate.opsForValue().increment(failKey);
                // 给 failKey 一个过期，避免无限增长
                if (fails != null && fails == 1L) {
                    stringRedisTemplate.expire(failKey, FAIL_LOCK_TTL);
                }

                long currentFails = fails == null ? 0L : fails;
                if (currentFails >= MAX_FAILS) {
                    stringRedisTemplate.opsForValue().set(lockKey, "1", FAIL_LOCK_TTL);
                    throw new BizException(423, "验证码错误次数过多，已锁定10分钟");
                }

                long remaining = MAX_FAILS - currentFails;
                if (remaining < 0) {
                    remaining = 0;
                }
                throw new BizException(401, "验证码错误，还剩 " + remaining + " 次机会");
            }

            // 验证成功：清理 Redis 状态
            stringRedisTemplate.delete(codeKey);
            stringRedisTemplate.delete(failKey);
            stringRedisTemplate.delete(lockKey);
        } catch (BizException ex) {
            throw ex;
        } catch (RedisConnectionFailureException e) {
            throw new BizException(503, "Redis连接失败，无法校验验证码");
        } catch (Exception e) {
            throw new BizException(500, "验证码校验失败");
        }
    }
}

