package com.smartfood.security.session;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.smartfood.dto.UserResponse;
import com.smartfood.entity.User;
import com.smartfood.exception.BizException;
import lombok.RequiredArgsConstructor;
import org.springframework.data.redis.RedisConnectionFailureException;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.stereotype.Service;

import java.time.Duration;

/**
 * Redis 登录会话服务：把 token -> 用户信息 映射写入 Redis。
 *
 * key: login:user:{token}
 * value: UserResponse JSON
 *
 * 支持：
 * - 校验 token 是否存在于 Redis（分布式 Session）
 * - 滑动续期：每次校验成功刷新 TTL（7 天）
 */
@Service
@RequiredArgsConstructor
public class RedisLoginSessionService {

    private static final String SESSION_KEY_PREFIX = "login:user:";

    // 需求：token 有效期 7 天，支持续期（通过每次命中时刷新 TTL 实现）
    private static final Duration SESSION_TTL = Duration.ofDays(7);

    private final StringRedisTemplate stringRedisTemplate;
    private final ObjectMapper objectMapper;

    public void saveSession(String token, User user) {
        if (token == null || token.isBlank()) {
            throw new BizException(400, "token不能为空");
        }
        if (user == null) {
            throw new BizException(500, "用户为空，无法保存会话");
        }

        try {
            UserResponse userResponse = UserResponse.fromUser(user);
            String json = objectMapper.writeValueAsString(userResponse);
            stringRedisTemplate.opsForValue().set(sessionKey(token), json, SESSION_TTL);
        } catch (JsonProcessingException e) {
            throw new BizException(500, "会话序列化失败");
        } catch (RedisConnectionFailureException e) {
            throw new BizException(503, "Redis连接失败，无法保存会话");
        }
    }

    /**
     * 校验 token 对应的 Redis 会话是否存在；存在则续期。
     */
    public UserResponse requireSession(String token) {
        if (token == null || token.isBlank()) {
            throw new BizException(401, "缺少/非法 token");
        }

        try {
            String json = stringRedisTemplate.opsForValue().get(sessionKey(token));
            if (json == null || json.isBlank()) {
                throw new BizException(401, "token无效或已过期");
            }

            // 滑动续期：刷新 TTL
            stringRedisTemplate.expire(sessionKey(token), SESSION_TTL);

            return objectMapper.readValue(json, UserResponse.class);
        } catch (BizException ex) {
            throw ex;
        } catch (Exception e) {
            // 反序列化/Redis 异常统一兜底
            throw new BizException(401, "token无效或已过期");
        }
    }

    public void deleteSession(String token) {
        if (token == null || token.isBlank()) {
            return;
        }
        try {
            stringRedisTemplate.delete(sessionKey(token));
        } catch (RedisConnectionFailureException e) {
            // logout 不应影响主流程
        }
    }

    private String sessionKey(String token) {
        return SESSION_KEY_PREFIX + token;
    }
}

