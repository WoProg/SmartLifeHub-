package com.smartfood.security;

import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.security.Keys;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import javax.crypto.SecretKey;
import java.nio.charset.StandardCharsets;
import java.util.Date;

/**
 * JWT 工具类：
 * - 登录成功时：签发 token
 * - 退出登录/校验 token 时：解析 token 得到 userId 等信息
 *
 * Day1 目标：保证“注册/登录/退出登录”接口能跑通并返回 token。
 */
@Component
public class JwtUtil {

    private static final String CLAIM_ROLE = "role";
    private static final String CLAIM_OPERATOR_ID = "operatorId";

    /**
     * JWT 密钥（HS256）。
     * 注意：生产环境请改为环境变量/配置中心，不要写死在代码库或公共仓库中。
     */
    @Value("${app.jwt.secret}")
    private String secret;

    /**
     * Token 有效期：7 天（可按需要调整）。
     */
    private static final long MILLIS_PER_DAY = 24L * 60 * 60 * 1000;

    /**
     * JWT 过期天数（用于签名/解析校验）。
     * <p>
     * 注意：Redis 会话的有效期固定为 7 天，Redis 过期才会真正踢出。
     * 为了支持“Redis 7天续期”，这里建议设置大于等于 7（默认 30 天）。
     */
    @org.springframework.beans.factory.annotation.Value("${app.jwt.expiration-days:30}")
    private long jwtExpirationDays;

    /**
     * 生成 JWT token。
     *
     * @param userId 登录用户 id（写入 token 的 subject）
     * @param phone 登录手机号（写入 token 的自定义 claim，便于后续扩展）
     * @return token 字符串
     */
    public String generateToken(Long userId, String phone) {
        Date now = new Date();
        Date exp = new Date(now.getTime() + jwtExpirationDays * MILLIS_PER_DAY);

        SecretKey key = Keys.hmacShaKeyFor(secret.getBytes(StandardCharsets.UTF_8));

        return Jwts.builder()
                .subject(String.valueOf(userId))
                .issuedAt(now)
                .expiration(exp)
                .claim("phone", phone)
                // Day1：用户 token 默认为 USER 角色，便于后续订单状态机权限校验
                .claim(CLAIM_ROLE, "USER")
                .claim(CLAIM_OPERATOR_ID, userId)
                .signWith(key)
                .compact();
    }

    /**
     * 生成带角色声明的 token（用于商家/骑手角色等）。
     *
     * @param operatorId 操作人 id（商家=shopId，骑手=riderId）
     * @param role        角色：USER/MERCHANT/RIDER
     * @return JWT token
     */
    public String generateTokenWithRole(Long operatorId, String role) {
        Date now = new Date();
        Date exp = new Date(now.getTime() + jwtExpirationDays * MILLIS_PER_DAY);
        SecretKey key = Keys.hmacShaKeyFor(secret.getBytes(StandardCharsets.UTF_8));

        return Jwts.builder()
                .subject(String.valueOf(operatorId))
                .issuedAt(now)
                .expiration(exp)
                .claim(CLAIM_ROLE, role)
                .claim(CLAIM_OPERATOR_ID, operatorId)
                .signWith(key)
                .compact();
    }

    /**
     * 解析 token 获取 Claims。
     *
     * @param token token 字符串
     * @return Claims
     */
    public Claims parseClaims(String token) {
        SecretKey key = Keys.hmacShaKeyFor(secret.getBytes(StandardCharsets.UTF_8));
        // JJWT 0.13.x：
        // - setSigningKey 返回 JwtParserBuilder
        // - 需要 build() 之后再 parseClaimsJws
        return Jwts.parser()
                .setSigningKey(key)
                .build()
                .parseClaimsJws(token)
                .getBody();
    }

    /**
     * 校验 token 是否有效（是否签名正确、是否过期等）。
     *
     * @param token token 字符串
     * @return true：有效；false：无效
     */
    public boolean isTokenValid(String token) {
        try {
            parseClaims(token);
            return true;
        } catch (Exception e) {
            return false;
        }
    }
}

