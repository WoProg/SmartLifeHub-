package com.smartfood.statistics;

import com.smartfood.service.impl.StatisticsServiceImpl;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import java.time.LocalDate;

/**
 * 定时任务：每天凌晨统计昨日基础数据写入 Redis。
 */
@Slf4j
@Component
@RequiredArgsConstructor
public class StatisticsScheduler {

    private final StatisticsServiceImpl statisticsService;

    /**
     * 预热天数：默认只算昨天。
     * 例如 preheat-days=3，则在凌晨批量写入“昨日/前天/大前天”的 daily 缓存。
     */
    @Value("${app.statistics.preheat-days:1}")
    private int preheatDays;

    /**
     * 每天 00:00:00 执行（服务器本地时区）。
     */
    @Scheduled(cron = "${app.statistics.daily-cron:0 0 0 * * ?}")
    public void dailyStatsAtMidnight() {
        try {
            int days = Math.max(preheatDays, 1);
            LocalDate now = LocalDate.now();
            for (int i = 1; i <= days; i++) {
                LocalDate date = now.minusDays(i);
                statisticsService.computeDailyAndCache(date);
            }
            log.info("dailyStatsAtMidnight ok: preheatDays={}", days);
        } catch (Exception e) {
            // 定时任务失败不影响线上查询接口：接口会按需回源计算。
            log.error("dailyStatsAtMidnight failed", e);
        }
    }
}

