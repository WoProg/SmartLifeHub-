package com.smartfood.statistics;

/**
 * 统计范围。
 */
public enum StatisticsRange {
    TODAY,
    WEEK,
    MONTH,
    YEAR
}

