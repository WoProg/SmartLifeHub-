package com.smartfood.statistics;

import com.smartfood.dto.UserResponse;
import com.smartfood.exception.BizException;
import com.smartfood.security.session.RedisLoginSessionService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.redis.RedisConnectionFailureException;
import org.springframework.stereotype.Component;
import org.springframework.data.redis.core.StringRedisTemplate;

import javax.servlet.*;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.time.Duration;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

/**
 * UV 埋点：使用 Redis HyperLogLog。
 *
 * Key：
 * - uv:{yyyyMMdd}
 * - uv:{yyyyMMdd}:page:{page}
 * - uv:{yyyyMMdd}:new / uv:{yyyyMMdd}:old（仅登录用户统计）
 * - uv:{yyyyMMdd}:path:{normalizedPath}
 */
@Slf4j
@Component
@RequiredArgsConstructor
public class UvStatisticsFilter implements Filter {

    private static final DateTimeFormatter DAY_FMT = DateTimeFormatter.ofPattern("yyyyMMdd");
    private static final Duration UV_KEY_TTL = Duration.ofDays(7);

    private final RedisLoginSessionService redisLoginSessionService;
    private final StringRedisTemplate stringRedisTemplate;

    @Override
    public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain)
            throws IOException, ServletException {
        if (!(request instanceof HttpServletRequest) || !(response instanceof HttpServletResponse)) {
            chain.doFilter(request, response);
            return;
        }

        HttpServletRequest req = (HttpServletRequest) request;

        // 重要：埋点失败不要影响主业务
        try {
            recordUv(req);
        } catch (Exception ignored) {
            // ignore
        }

        chain.doFilter(request, response);
    }

    private void recordUv(HttpServletRequest request) {
        String dayKey = LocalDate.now().format(DAY_FMT);
        String value;

        Long userId = null;
        LocalDate createDate = null;

        String authorization = request.getHeader("Authorization");
        if (authorization != null && !authorization.trim().isEmpty()) {
            String token = normalizeToken(authorization);
            try {
                UserResponse sessionUser = redisLoginSessionService.requireSession(token);
                userId = sessionUser.getId();
                if (sessionUser.getCreateTime() != null) {
                    createDate = sessionUser.getCreateTime().toLocalDate();
                }
            } catch (BizException | RedisConnectionFailureException ignored) {
                // 未登录或 Redis 不可用：按 remoteAddr 统计
            }
        }

        if (userId != null) {
            value = String.valueOf(userId);
        } else {
            // 未登录 UV：用来源 IP 做近似（HyperLogLog 对碰撞不敏感）
            value = request.getRemoteAddr();
            if (value == null || value.isBlank()) {
                value = "unknown";
            }
        }

        String baseKey = "uv:" + dayKey;

        // daily
        addHll(baseKey, value);

        // page
        String page = normalizePage(request.getRequestURI());
        addHll(baseKey + ":page:" + page, value);

        // new/old（仅登录用户）
        if (userId != null && createDate != null) {
            LocalDate newThreshold = LocalDate.now().minusDays(30);
            boolean isNew = !createDate.isBefore(newThreshold);
            if (isNew) {
                addHll(baseKey + ":new", value);
            } else {
                addHll(baseKey + ":old", value);
            }
        }

        // path
        String normalizedPath = normalizePath(request.getRequestURI());
        addHll(baseKey + ":path:" + normalizedPath, value);
    }

    private void addHll(String key, String value) {
        // HyperLogLog 只需要“唯一性近似”，不存在 TTL 需求；但为了内存控制我们仍设 TTL。
        stringRedisTemplate.opsForHyperLogLog().add(key, value);
        try {
            stringRedisTemplate.expire(key, UV_KEY_TTL);
        } catch (Exception ignored) {
            // ignore
        }
    }

    private String normalizeToken(String authorization) {
        String token = authorization.trim();
        if (token.toLowerCase().startsWith("bearer ")) {
            return token.substring(7).trim();
        }
        return token;
    }

    private String normalizePage(String requestURI) {
        if (requestURI == null || requestURI.isBlank()) {
            return "unknown";
        }
        String path = requestURI.startsWith("/") ? requestURI.substring(1) : requestURI;
        int idx = path.indexOf('/');
        if (idx > 0) {
            path = path.substring(0, idx);
        }
        if (path.isBlank()) {
            return "root";
        }
        return path;
    }

    private String normalizePath(String requestURI) {
        if (requestURI == null || requestURI.isBlank()) {
            return "unknown";
        }
        String[] parts = requestURI.split("/");
        StringBuilder sb = new StringBuilder();
        for (String p : parts) {
            if (p == null || p.isBlank()) {
                continue;
            }
            if (p.matches("\\d+")) {
                sb.append("/{id}");
            } else {
                sb.append('/').append(p);
            }
        }
        String result = sb.toString();
        return result.isBlank() ? "unknown" : result;
    }
}

