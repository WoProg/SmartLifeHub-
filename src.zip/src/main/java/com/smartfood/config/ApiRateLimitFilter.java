package com.smartfood.config;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.smartfood.common.Result;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.stereotype.Component;
import org.springframework.web.filter.OncePerRequestFilter;

import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.time.Duration;

/**
 * 基础接口防刷限流（IP 维度，滑动窗口简化版）。
 */
@Slf4j
@Component
@RequiredArgsConstructor
public class ApiRateLimitFilter extends OncePerRequestFilter {

    private static final int MAX_PER_MINUTE = 120;
    private static final Duration WINDOW = Duration.ofMinutes(1);

    private final StringRedisTemplate stringRedisTemplate;
    private final ObjectMapper objectMapper;

    @Override
    protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain filterChain)
            throws ServletException, IOException {
        String path = request.getRequestURI();
        String method = request.getMethod();

        // 仅对高风险写接口限流，读接口放开
        boolean needLimit = "POST".equalsIgnoreCase(method) || "PUT".equalsIgnoreCase(method) || "DELETE".equalsIgnoreCase(method);
        if (!needLimit) {
            filterChain.doFilter(request, response);
            return;
        }

        String ip = request.getRemoteAddr() == null ? "unknown" : request.getRemoteAddr();
        String key = "ratelimit:" + ip + ":" + path;
        Long cnt;
        try {
            cnt = stringRedisTemplate.opsForValue().increment(key);
            if (cnt != null && cnt == 1L) {
                stringRedisTemplate.expire(key, WINDOW);
            }
        } catch (Exception ex) {
            // fail-open: 限流组件依赖（Redis）不可用时，不影响主业务可用性
            log.warn("RateLimit degraded: redis unavailable, path={}", path);
            filterChain.doFilter(request, response);
            return;
        }

        if (cnt != null && cnt > MAX_PER_MINUTE) {
            response.setStatus(429);
            response.setCharacterEncoding(StandardCharsets.UTF_8.name());
            response.setContentType("application/json;charset=UTF-8");
            response.getWriter().write(objectMapper.writeValueAsString(Result.fail(429, "请求过于频繁，请稍后重试")));
            return;
        }
        filterChain.doFilter(request, response);
    }
}
