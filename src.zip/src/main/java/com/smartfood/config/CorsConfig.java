package com.smartfood.config;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.cors.CorsConfiguration;
import org.springframework.web.cors.CorsConfigurationSource;
import org.springframework.web.cors.UrlBasedCorsConfigurationSource;

import java.util.Arrays;
import java.util.stream.Collectors;

/**
 * 跨域（CORS）配置。
 *
 * Day1 目标：
 * - 保证前后端分离开发时能正常访问
 * - 预留 prod 环境改为白名单的能力（通过 `app.cors.allowed-origins` 控制）
 */
@Configuration
public class CorsConfig {

    /**
     * 允许的跨域来源。
     * 默认值为 "*"（开发阶段方便联调）。
     *
     * 你可以在 application-dev.yml / application-prod.yml 中配置：
     * - 单个域名：`https://your-frontend.com`
     * - 多个域名：`https://a.com,https://b.com`
     */
    @Value("${app.cors.allowed-origins:*}")
    private String allowedOrigins;

    @Bean
    public CorsConfigurationSource corsConfigurationSource() {
        CorsConfiguration configuration = new CorsConfiguration();

        // 允许携带 Cookie/Authorization 等凭据
        configuration.setAllowCredentials(true);

        // 设置允许的来源（开发阶段建议允许所有，生产阶段建议改成白名单）
        if ("*".equals(allowedOrigins.trim())) {
            // 用 addAllowedOriginPattern 支持通配（允许所有来源）
            configuration.addAllowedOriginPattern("*");
        } else {
            // 多域名用逗号分隔
            configuration.setAllowedOrigins(
                    Arrays.stream(allowedOrigins.split(","))
                            .map(String::trim)
                            .filter(s -> !s.isEmpty())
                            .collect(Collectors.toList())
            );
        }

        // 允许的请求头：* 表示通配
        configuration.addAllowedHeader("*");

        // 允许的请求方法：* 表示通配
        configuration.addAllowedMethod("*");

        // 预检请求（OPTIONS）缓存时间，提升性能（单位：秒）
        configuration.setMaxAge(3600L);

        // 将该 CORS 配置应用到所有接口路径
        UrlBasedCorsConfigurationSource source = new UrlBasedCorsConfigurationSource();
        source.registerCorsConfiguration("/**", configuration);
        return source;
    }
}

