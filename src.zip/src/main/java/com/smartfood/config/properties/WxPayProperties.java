package com.smartfood.config.properties;

import lombok.Data;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

/**
 * 微信支付配置（API v3）。
 *
 * Day1/Day2 设计目标：
 * - 统一把配置从 application.yml 抽取到 POJO，减少代码里硬编码
 * - 支持 mock/real 模式，便于先跑通下单/回调链路
 */
@Data
@Component
@ConfigurationProperties(prefix = "app.wxpay")
public class WxPayProperties {

    /**
     * 支付模式：mock 或 real
     * - mock：不调用微信 SDK，直接模拟支付成功/失败并触发回调逻辑桩
     * - real：调用微信沙箱/线上 SDK，要求密钥与证书配置齐全
     */
    private String mode;

    /**
     * 商户后台配置的 appid。
     */
    private String appid;

    /**
     * 商户号 mchid。
     */
    private String mchid;

    /**
     * 支付描述（统一下单时使用）。
     */
    private String description;

    /**
     * 通知地址（异步回调地址）。
     */
    private String notifyUrl;

    /**
     * API v3 Key（用于回调解密 / 请求签名等）。
     */
    private String apiV3Key;

    /**
     * 商户证书序列号（merchantSerialNumber）。
     */
    private String merchantSerialNumber;

    /**
     * 商户私钥路径（pem）。
     * real 模式需要；mock 模式可不填。
     */
    private String privateKeyPath;
}

