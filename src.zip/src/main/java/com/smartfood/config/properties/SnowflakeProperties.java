package com.smartfood.config.properties;

import lombok.Data;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

/**
 * 雪花算法（Snowflake）配置。
 *
 * 用于订单号 order_no 生成。
 */
@Data
@Component
@ConfigurationProperties(prefix = "app.snowflake")
public class SnowflakeProperties {

    /**
     * workerId：机器标识（0~31，取决于你雪花实现位数约定）。
     */
    private long workerId;

    /**
     * datacenterId：数据中心标识。
     */
    private long datacenterId;

    /**
     * epochMillis：纪元（毫秒）。
     */
    private long epochMillis;
}

