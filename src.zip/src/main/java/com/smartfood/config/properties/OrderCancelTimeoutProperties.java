package com.smartfood.config.properties;

import lombok.Data;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

/**
 * 订单超时取消配置。
 */
@Data
@Component
@ConfigurationProperties(prefix = "app.order.cancel-timeout")
public class OrderCancelTimeoutProperties {

    /**
     * 待付款超时时间（分钟）。
     */
    private long minutes;
}

