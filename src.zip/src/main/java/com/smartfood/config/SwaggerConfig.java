package com.smartfood.config;

import io.swagger.v3.oas.models.OpenAPI;
import io.swagger.v3.oas.models.info.Info;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

/**
 * Swagger（OpenAPI）基础配置。
 *
 * Day1 目标：
 * - 让启动后能在 Swagger UI 页面看到应用名称/描述等基本信息
 * - 为后续每个业务模块的 Controller 编写接口文档打基础
 *
 * 说明：
 * - 本项目使用 springdoc-openapi-ui（适配 Spring Boot 2.7.x）
 * - Swagger UI 默认地址通常为：/swagger-ui.html
 */
@Configuration
public class SwaggerConfig {

    /**
     * 定义 OpenAPI 文档的基础信息。
     *
     * @return OpenAPI 对象
     */
    @Bean
    public OpenAPI openAPI() {
        return new OpenAPI()
                .info(new Info()
                        .title("智能餐饮平台 API")
                        .version("v1.0")
                        .description("融合外卖和点评的智能餐饮平台：包含订单、支付、点评社交、营销等能力。"));
    }
}

