package com.smartfood.geo;

import com.smartfood.dto.NearbyShopResponse;
import lombok.RequiredArgsConstructor;
import org.springframework.data.geo.Circle;
import org.springframework.data.geo.Metrics;
import org.springframework.data.geo.Point;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.data.redis.connection.RedisGeoCommands;
import org.springframework.data.geo.GeoResults;
import org.springframework.data.geo.Distance;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.util.List;
import java.util.stream.Collectors;

/**
 * 店铺 GEO 索引与附近搜索。
 *
 * Redis Key:
 * - shop:geo
 */
@Service
@RequiredArgsConstructor
public class ShopGeoService {

    private static final String GEO_KEY = "shop:geo";

    private final StringRedisTemplate stringRedisTemplate;

    public void addShopPoint(Long shopId, BigDecimal longitude, BigDecimal latitude) {
        if (shopId == null || shopId <= 0 || longitude == null || latitude == null) {
            return;
        }

        Point point = new Point(longitude.doubleValue(), latitude.doubleValue());
        stringRedisTemplate.opsForGeo().add(GEO_KEY, point, shopId.toString());
    }

    /**
     * 附近店铺搜索（距离排序）。
     *
     * @param longitude 用户经度
     * @param latitude 用户纬度
     * @param radiusKm 半径（km）
     * @param limit 取回的最大数量（分页用 limit=page*size，再在服务端切片）
     */
    public List<NearbyShopResponse> searchNearby(BigDecimal longitude,
                                                   BigDecimal latitude,
                                                   double radiusKm,
                                                   int limit) {
        if (longitude == null || latitude == null) {
            return List.of();
        }
        if (limit <= 0) {
            return List.of();
        }

        Point point = new Point(longitude.doubleValue(), latitude.doubleValue());
        Distance distance = new Distance(radiusKm, Metrics.KILOMETERS);
        Circle circle = new Circle(point, distance);

        RedisGeoCommands.GeoRadiusCommandArgs args =
                RedisGeoCommands.GeoRadiusCommandArgs.newGeoRadiusArgs()
                        .includeDistance()
                        .sortAscending()
                        .limit(limit);

        GeoResults<RedisGeoCommands.GeoLocation<String>> results =
                stringRedisTemplate.opsForGeo().radius(GEO_KEY, circle, args);

        if (results == null) {
            return List.of();
        }

        return results.getContent().stream()
                .map(loc -> {
                    String name = loc.getContent().getName();
                    Long shopId = name == null ? null : Long.valueOf(name);
                    double distKm = (loc.getDistance() == null) ? 0d : loc.getDistance().getValue();
                    return NearbyShopResponse.builder()
                            .shopId(shopId)
                            .distanceKm(distKm)
                            .shop(null) // 店铺详情由 ShopService 进一步补齐（Milestone 5）
                            .build();
                })
                .collect(Collectors.toList());
    }
}

