-- 智能餐饮平台：订单/支付核心表（Day2/Day1 均可使用）
-- 说明：
-- 1) MySQL 表名 `order` 为保留关键字，因此使用反引号包裹。
-- 2) 订单号 order_no：使用雪花算法生成（Long/BigInt，直接作为主键/业务唯一号）。
-- 3) 订单状态、支付状态使用 TINYINT 存储，枚举在 Java 侧统一映射。
-- 4) 订单超时取消：字段 cancel_at 用于延迟队列触发到期取消（仅待付款订单）。

-- 建议先选择数据库
USE smart_food;

-- =========================
-- 订单主表：`order`
-- =========================
CREATE TABLE IF NOT EXISTS `order` (
  order_no           BIGINT NOT NULL COMMENT '雪花订单号（业务主键）',
  user_id            BIGINT NOT NULL COMMENT '用户 id',
  shop_id            BIGINT NOT NULL COMMENT '店铺 id',
  total_amount      DECIMAL(10,2) NOT NULL DEFAULT 0.00 COMMENT '订单总金额',

  -- 订单状态（TINYINT，对应 Java OrderStatus）
  status             TINYINT NOT NULL COMMENT '订单状态：待付款/待接单/制作中/待配送/配送中/已完成/已取消',

  -- 支付方式（TINYINT，对应 Java PayMethod）
  pay_method         TINYINT NOT NULL DEFAULT 0 COMMENT '支付方式：微信_APP/预留',

  -- 支付状态（TINYINT，对应 Java PayStatus）
  pay_status         TINYINT NOT NULL DEFAULT 0 COMMENT '支付状态：未支付/已支付/失败/退款中/已退款(预留)',

  -- 微信支付相关字段（下单/回调同步用）
  wechat_prepay_id   VARCHAR(64) NULL COMMENT '微信 prepay_id（可用于调起支付）',
  wechat_trade_no    VARCHAR(64) NULL COMMENT '微信交易号（trade_no）',
  wechat_out_trade_no VARCHAR(64) NULL COMMENT '微信侧 out_trade_no（通常与 order_no 对应）',
  pay_callback_params JSON NULL COMMENT '支付回调入参摘要/冗余字段（可选，便于排障）',

  -- 订单超时取消（仅对待付款订单启用）
  cancel_at          DATETIME NOT NULL COMMENT '订单超时取消时间点（用于延迟队列触发）',
  cancelled_at       DATETIME NULL COMMENT '取消完成时间',

  -- 关键时间点
  pay_at             DATETIME NULL COMMENT '支付完成时间',
  finish_at          DATETIME NULL COMMENT '订单完成时间',

  create_time        DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  update_time        DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',

  PRIMARY KEY (order_no),
  -- 要求：订单号唯一（主键已保证），以及 (user_id,status) 索引
  KEY idx_order_user_status (user_id, status),
  -- 超时取消 worker 可用（即便主要用 Redis 调度）
  KEY idx_order_cancel_at (cancel_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='订单主表';

-- 外键：订单关联 user/shop（明确关系）
-- 注意：如果你前面暂未建好 user/shop 表，请先按 Day1 SQL 创建，再执行本脚本。
ALTER TABLE `order`
  ADD CONSTRAINT fk_order_user
  FOREIGN KEY (user_id) REFERENCES `user`(id)
  ON DELETE RESTRICT ON UPDATE CASCADE;

ALTER TABLE `order`
  ADD CONSTRAINT fk_order_shop
  FOREIGN KEY (shop_id) REFERENCES `shop`(id)
  ON DELETE RESTRICT ON UPDATE CASCADE;

-- =========================
-- 订单明细表：order_detail
-- =========================
CREATE TABLE IF NOT EXISTS order_detail (
  id            BIGINT NOT NULL AUTO_INCREMENT COMMENT '主键',
  order_no      BIGINT NOT NULL COMMENT '订单号（外键）',
  dish_id       BIGINT NOT NULL COMMENT '菜品 id（外键）',
  quantity      INT NOT NULL DEFAULT 1 COMMENT '购买数量',
  unit_price    DECIMAL(10,2) NOT NULL DEFAULT 0.00 COMMENT '下单时单价',
  spec_json     JSON NULL COMMENT '规格信息（快照存储）',

  create_time   DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  update_time   DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',

  PRIMARY KEY (id),
  KEY idx_order_detail_order_no (order_no),
  KEY idx_order_detail_dish_id (dish_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='订单明细表';

ALTER TABLE order_detail
  ADD CONSTRAINT fk_order_detail_order
  FOREIGN KEY (order_no) REFERENCES `order`(order_no)
  ON DELETE CASCADE ON UPDATE CASCADE;

ALTER TABLE order_detail
  ADD CONSTRAINT fk_order_detail_dish
  FOREIGN KEY (dish_id) REFERENCES dish(id)
  ON DELETE RESTRICT ON UPDATE CASCADE;

-- =========================
-- 购物车表：cart
-- =========================
CREATE TABLE IF NOT EXISTS cart (
  id            BIGINT NOT NULL AUTO_INCREMENT COMMENT '主键',
  user_id       BIGINT NOT NULL COMMENT '用户 id',
  dish_id       BIGINT NOT NULL COMMENT '菜品 id',
  quantity      INT NOT NULL DEFAULT 1 COMMENT '数量',
  spec_key      VARCHAR(64) NOT NULL COMMENT '规格去重键（用于保证相同 dish+规格组合只出现一条）',
  spec_json     JSON NULL COMMENT '规格快照（便于下单时直接使用）',
  is_selected   TINYINT NOT NULL DEFAULT 0 COMMENT '是否选中：1-选中加入下单；0-未选中',

  create_time   DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  update_time   DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',

  PRIMARY KEY (id),
  UNIQUE KEY uk_cart_user_dish_spec (user_id, dish_id, spec_key),
  KEY idx_cart_user_selected (user_id, is_selected)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='购物车表';

ALTER TABLE cart
  ADD CONSTRAINT fk_cart_user
  FOREIGN KEY (user_id) REFERENCES `user`(id)
  ON DELETE CASCADE ON UPDATE CASCADE;

ALTER TABLE cart
  ADD CONSTRAINT fk_cart_dish
  FOREIGN KEY (dish_id) REFERENCES dish(id)
  ON DELETE RESTRICT ON UPDATE CASCADE;

-- =========================
-- 订单操作日志：order_operation_log
-- =========================
CREATE TABLE IF NOT EXISTS order_operation_log (
  id             BIGINT NOT NULL AUTO_INCREMENT COMMENT '主键',
  order_no       BIGINT NOT NULL COMMENT '订单号',
  event_type     VARCHAR(64) NOT NULL COMMENT '事件类型：CANCEL_TIMEOUT/PAY_SUCCESS/ACCEPT/START_MAKE/START_DELIVERY/CONFIRM_RECEIPT/CANCEL_BY_USER 等',

  -- 操作角色：0-USER 1-MERCHANT 2-RIDER（与 Java 侧枚举对应）
  operator_role  TINYINT NOT NULL COMMENT '操作角色',
  operator_id    BIGINT NULL COMMENT '操作者 id（商家=shopId、骑手=riderId、用户=userId 等可统一约定）',

  from_status    TINYINT NULL COMMENT '前置状态',
  to_status      TINYINT NULL COMMENT '目标状态',
  remark         VARCHAR(500) NULL COMMENT '备注信息（用于排查/审计）',

  create_time    DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  update_time    DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',

  PRIMARY KEY (id),
  UNIQUE KEY uk_order_event (order_no, event_type), -- 幂等：同一事件只记录一次
  KEY idx_order_operation_log_order_no (order_no)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='订单状态变更操作日志';

ALTER TABLE order_operation_log
  ADD CONSTRAINT fk_order_operation_log_order
  FOREIGN KEY (order_no) REFERENCES `order`(order_no)
  ON DELETE CASCADE ON UPDATE CASCADE;

-- =========================
-- 微信支付通知幂等表：wechat_payment_notification
-- =========================
CREATE TABLE IF NOT EXISTS wechat_payment_notification (
  id                 BIGINT NOT NULL AUTO_INCREMENT COMMENT '主键',
  order_no           BIGINT NOT NULL COMMENT '订单号（外键）',

  -- 微信通知 id：幂等关键字段（回调中 resource/out_trade_no 等字段）
  wechat_notification_id VARCHAR(64) NOT NULL COMMENT '微信通知唯一 id',

  -- trade_state / success_time 等关键字段
  trade_state        VARCHAR(32) NOT NULL COMMENT '微信 trade_state（SUCCESS/NOTPAY/CLOSED/FAIL 等）',
  success_time       DATETIME NULL COMMENT '支付成功时间（如果回调提供）',
  transaction_id     VARCHAR(64) NULL COMMENT '微信交易号',

  -- 回调原始信息摘要（可选）
  raw_body            JSON NULL COMMENT '回调 body 摘要/冗余字段（便于排障）',

  create_time        DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  update_time        DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',

  PRIMARY KEY (id),
  UNIQUE KEY uk_wechat_notification_id (wechat_notification_id), -- 回调幂等：同一通知只处理一次
  KEY idx_wechat_notification_order_no (order_no)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='微信支付通知幂等表';

ALTER TABLE wechat_payment_notification
  ADD CONSTRAINT fk_wechat_notification_order
  FOREIGN KEY (order_no) REFERENCES `order`(order_no)
  ON DELETE CASCADE ON UPDATE CASCADE;

-- =========================
-- 结束
-- =========================

